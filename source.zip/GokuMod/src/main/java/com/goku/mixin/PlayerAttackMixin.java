package com.goku.mixin;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lets Keep Sprint undo the vanilla "hit -> stop sprinting + slow down" that the local player applies after attacking. */
@Mixin(PlayerEntity.class)
public abstract class PlayerAttackMixin {
    @Unique private Vec3d gokuVel;
    @Unique private boolean gokuSprint;

    @Inject(method = "attack", at = @At("HEAD"))
    private void goku$attackHead(Entity target, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player) return;
        PlayerEntity p = (PlayerEntity) (Object) this;
        gokuVel = p.getVelocity(); gokuSprint = p.isSprinting();
    }

    @Inject(method = "attack", at = @At("TAIL"))
    private void goku$attackTail(Entity target, CallbackInfo ci) {
        if ((Object) this != MinecraftClient.getInstance().player || gokuVel == null) return;
        Modules.KEEP_SPRINT.after((PlayerEntity) (Object) this, gokuVel, gokuSprint);
        gokuVel = null;
    }
}
