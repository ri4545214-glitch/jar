package com.goku.mixin;

import com.goku.util.Lag;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hold points for Fake Lag (what we send) and Back Track (what we receive). Only active while one of those modules asks for it. */
@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {
    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void goku$send(Packet<?> packet, CallbackInfo ci) {
        if (Lag.BYPASS.get() || (!Lag.holdOut && !Lag.hasOut()) || MinecraftClient.getInstance().player == null) return;
        Lag.queueOut((ClientConnection) (Object) this, packet);
        ci.cancel();
    }

    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void goku$read(io.netty.channel.ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci) {
        if (Lag.BYPASS.get() || (!Lag.holdIn && !Lag.hasIn()) || MinecraftClient.getInstance().player == null) return;
        Lag.queueIn((ClientConnection) (Object) this, ctx, packet);
        ci.cancel();
    }
}
