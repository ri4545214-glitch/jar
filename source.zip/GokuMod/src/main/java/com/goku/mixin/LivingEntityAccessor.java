package com.goku.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {
    @Accessor("jumpingCooldown") int gokuJumpCd();
    @Accessor("jumpingCooldown") void gokuSetJumpCd(int v);
}
