package com.goku;

import com.goku.gui.ClickGui;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class GokuMod implements ClientModInitializer {
    boolean altWas, ctrlWas, shiftWas;

    /** Polled every frame and at both ends of every tick, so even a very short key tap opens the menu. Right Alt or Insert. */
    void pollOpen(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        boolean down = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(h, GLFW.GLFW_KEY_INSERT) == GLFW.GLFW_PRESS;
        if (down && !altWas && mc.currentScreen == null && mc.player != null && mc.getOverlay() == null) mc.setScreen(new ClickGui());
        altWas = down;
        boolean sh = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (sh && !shiftWas && mc.currentScreen == null && mc.player != null && mc.getOverlay() == null) mc.setScreen(new com.goku.gui.ManagerGui());
        shiftWas = sh;
    }

    @Override public void onInitializeClient() {
        // "Goku Settings" button on the pause menu opens the Settings hub
        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof net.minecraft.client.gui.screen.GameMenuScreen) {
                net.fabricmc.fabric.api.client.screen.v1.Screens.getButtons(screen).add(
                        net.minecraft.client.gui.widget.ButtonWidget.builder(net.minecraft.text.Text.literal("Goku Settings"), b -> client.setScreen(new com.goku.gui.ManagerGui(screen)))
                                .dimensions(8, 8, 110, 20).build());
            }
        });
        Config.captureDefaults();
        Config.load("default");
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            pollOpen(mc);
            if (mc.player == null || mc.world == null) return;
            for (Module m : Modules.ALL) if (m.enabled) m.onPreTick();
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            pollOpen(mc);
            Modules.CONFIG.poll();
            long h = mc.getWindow().getHandle();
            boolean ctrl = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
            if (ctrl && !ctrlWas && mc.currentScreen == null && Modules.SOUND.hotkey.b) {
                Modules.SOUND.keep.b = !Modules.SOUND.keep.b;
                if (mc.player != null) mc.player.sendMessage(net.minecraft.text.Text.literal("[Goku] Music " + (Modules.SOUND.keep.b ? "on" : "off")), true);
            }
            ctrlWas = ctrl;
            com.goku.util.Sfx.tick();
            Modules.NAVIGATOR.scanTick();
            if (mc.player == null || mc.world == null) { Modules.FREECAM.setEnabled(false); Modules.ZOOM.restore(); return; }
            for (Module m : Modules.ALL) if (m.enabled) m.onTick();
        });
        HudRenderCallback.EVENT.register((ctx, tc) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            pollOpen(mc);
            if (mc.player == null || mc.world == null) return;
            float td = tc.getTickProgress(false);
            Projector.update(mc, td);
            Esp.hudY = 4;
            for (Module m : Modules.ALL) if (m.enabled) m.onRender(ctx, td);
        });
    }
}
