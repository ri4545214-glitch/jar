package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Packet hold queues used by Fake Lag (outgoing) and Back Track (incoming). Filled by ClientConnectionMixin, drained from the client thread. */
public final class Lag {
    public static final ThreadLocal<Boolean> BYPASS = ThreadLocal.withInitial(() -> false);

    // ---- outgoing (Fake Lag)
    public static volatile boolean holdOut;
    static final ArrayDeque<Packet<?>> out = new ArrayDeque<>();
    static final ArrayDeque<Long> outTime = new ArrayDeque<>();
    public static volatile ClientConnection outConn;

    public static synchronized void queueOut(ClientConnection c, Packet<?> p) {
        outConn = c; out.add(p); outTime.add(System.currentTimeMillis());
    }

    /** Sends every held packet that is at least ageMs old (0 = all), in order. */
    public static void flushOut(long ageMs) {
        List<Packet<?>> send = new ArrayList<>();
        ClientConnection c;
        synchronized (Lag.class) {
            c = outConn;
            long now = System.currentTimeMillis();
            while (!out.isEmpty() && now - outTime.peekFirst() >= ageMs) { send.add(out.poll()); outTime.poll(); }
        }
        if (c == null || send.isEmpty()) return;
        BYPASS.set(true);
        try { for (Packet<?> p : send) c.send(p); } finally { BYPASS.set(false); }
    }

    public static synchronized boolean hasOut() { return !out.isEmpty(); }

    // ---- incoming (Back Track)
    public static volatile boolean holdIn;
    public record In(ClientConnection conn, Object ctx, Packet<?> packet, long t) {}
    static final ArrayDeque<In> in = new ArrayDeque<>();

    public static synchronized void queueIn(ClientConnection c, Object ctx, Packet<?> p) { in.add(new In(c, ctx, p, System.currentTimeMillis())); }
    public static synchronized boolean hasIn() { return !in.isEmpty(); }

    /** Delivers held incoming packets that are at least ageMs old (0 = all), in order, on the calling (client) thread. */
    public static void flushIn(long ageMs) {
        List<In> go = new ArrayList<>();
        synchronized (Lag.class) {
            long now = System.currentTimeMillis();
            while (!in.isEmpty() && now - in.peekFirst().t() >= ageMs) go.add(in.poll());
        }
        if (go.isEmpty()) return;
        BYPASS.set(true);
        try { for (In i : go) ((com.goku.mixin.ClientConnectionAccessor) (Object) i.conn()).gokuRead((io.netty.channel.ChannelHandlerContext) i.ctx(), i.packet()); } finally { BYPASS.set(false); }
    }

    public static synchronized void clear() { out.clear(); outTime.clear(); in.clear(); holdOut = false; holdIn = false; }
}
