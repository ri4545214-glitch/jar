package com.goku.util;

/** Corner-anchored HUD placement shared by the HUD mods. */
public final class Hud {
    public static final String[] CORNERS = {"Top Left", "Top Right", "Bottom Left", "Bottom Right"};

    /** Top-left pixel {x, y} of a w*h element anchored to a corner with an offset. Needs Projector.update() to have run this frame. */
    public static int[] pos(int corner, int ox, int oy, int w, int h) {
        int x = (corner & 1) == 0 ? ox : Projector.W - w - ox;
        int y = (corner & 2) == 0 ? oy : Projector.H - h - oy;
        return new int[]{x, y};
    }
}
