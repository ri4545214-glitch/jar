package com.goku.util;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Tiny NBT reader with no Minecraft dependencies (compound = Map, list = List, arrays = byte[]/int[]/long[]). */
public final class NbtLite {
    private NbtLite() {}

    public static Object read(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1: return in.readByte();
            case 2: return in.readShort();
            case 3: return in.readInt();
            case 4: return in.readLong();
            case 5: return in.readFloat();
            case 6: return in.readDouble();
            case 7: { byte[] b = new byte[in.readInt()]; in.readFully(b); return b; }
            case 8: return in.readUTF();
            case 9: {
                int t = in.readByte(), n = in.readInt();
                List<Object> l = new ArrayList<>();
                for (int i = 0; i < n; i++) l.add(read(in, t));
                return l;
            }
            case 10: {
                Map<String, Object> m = new HashMap<>();
                while (true) {
                    int t = in.readByte();
                    if (t == 0) break;
                    String k = in.readUTF();
                    m.put(k, read(in, t));
                }
                return m;
            }
            case 11: { int[] a = new int[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readInt(); return a; }
            case 12: { long[] a = new long[in.readInt()]; for (int i = 0; i < a.length; i++) a[i] = in.readLong(); return a; }
            default: throw new IOException("bad nbt tag " + type);
        }
    }

    /** Reads a (gzip or plain) NBT file and returns its root compound. */
    public static Map<String, Object> readFile(java.nio.file.Path file) throws IOException {
        byte[] all = java.nio.file.Files.readAllBytes(file);
        InputStream src = new java.io.ByteArrayInputStream(all);
        if (all.length > 2 && (all[0] & 0xFF) == 0x1F && (all[1] & 0xFF) == 0x8B) src = new GZIPInputStream(src);
        try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(src))) {
            int t = in.readByte();
            if (t != 10) throw new IOException("not an NBT file");
            in.readUTF();
            return map(read(in, 10));
        }
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> map(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }

    @SuppressWarnings("unchecked")
    public static List<Object> list(Object o) { return o instanceof List ? (List<Object>) o : null; }

    public static int num(Object o) { return o instanceof Number n ? n.intValue() : 0; }
}
