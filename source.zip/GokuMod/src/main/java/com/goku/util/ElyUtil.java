package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;

import java.util.function.Predicate;

/** Shared elytra helpers (wear / take off / height above ground). */
public final class ElyUtil {
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static boolean goodElytra(ItemStack s) { return s.isOf(Items.ELYTRA) && s.getDamage() < s.getMaxDamage() - 1; }

    public static boolean wearing() { return mc().player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA); }

    /** Player inventory index (0-35) of the first match, or -1. */
    public static int find(Predicate<ItemStack> f) {
        var inv = mc().player.getInventory();
        for (int i = 0; i < 36; i++) if (f.test(inv.getStack(i))) return i;
        return -1;
    }

    /** Swaps the chest slot with the stack at player-inventory index i (hotbar uses a single swap click, inventory uses pick up / drop). */
    public static void swapChest(int i) {
        var m = mc();
        int sync = m.player.playerScreenHandler.syncId;
        if (i < 9) m.interactionManager.clickSlot(sync, 6, i, SlotActionType.SWAP, m.player);
        else {
            int s = Inv.containerSlot(i);
            m.interactionManager.clickSlot(sync, s, 0, SlotActionType.PICKUP, m.player);
            m.interactionManager.clickSlot(sync, 6, 0, SlotActionType.PICKUP, m.player);
            m.interactionManager.clickSlot(sync, s, 0, SlotActionType.PICKUP, m.player);
        }
    }

    /** Blocks of air under the player (up to 80), plus the fraction inside the current block. */
    public static double heightAbove() {
        var m = mc();
        BlockPos p = m.player.getBlockPos();
        int n = 0;
        while (n < 80 && m.world.getBlockState(p.down(n + 1)).isAir()) n++;
        return n + (m.player.getY() - p.getY());
    }

    public static boolean gliding() { return mc().player.isGliding(); }
}
