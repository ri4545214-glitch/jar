package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.function.Predicate;

/** Chest-slot swapping (elytra <-> chestplate), gliding and height helpers. */
public final class Gear {
    public static final Predicate<ItemStack> ELYTRA = s -> s.isOf(Items.ELYTRA) && s.getDamage() < s.getMaxDamage() - 1;
    public static final Predicate<ItemStack> CHESTPLATE = s -> !s.isEmpty() && Registries.ITEM.getId(s.getItem()).getPath().endsWith("_chestplate");

    static ClientPlayerEntity p() { return MinecraftClient.getInstance().player; }

    public static boolean worn(Predicate<ItemStack> want) { return want.test(p().getEquippedStack(EquipmentSlot.CHEST)); }

    public static boolean has(Predicate<ItemStack> want) {
        var slots = p().playerScreenHandler.slots;
        for (int i = 9; i <= 44; i++) if (want.test(slots.get(i).getStack())) return true;
        return false;
    }

    /** Puts a matching item into the chest slot (one swap through the hotbar). Returns false if nothing matches. The swap takes effect once the server confirms it. */
    public static boolean equipChest(Predicate<ItemStack> want) {
        var mc = MinecraftClient.getInstance();
        var pl = p();
        if (want.test(pl.getEquippedStack(EquipmentSlot.CHEST))) return true;
        var slots = pl.playerScreenHandler.slots;
        int id = -1;
        for (int i = 9; i <= 44; i++) if (want.test(slots.get(i).getStack())) { id = i; break; }
        if (id < 0) return false;
        int sync = pl.playerScreenHandler.syncId, hb;
        if (id >= 36) hb = id - 36;
        else { hb = 8; mc.interactionManager.clickSlot(sync, id, hb, SlotActionType.SWAP, pl); }
        mc.interactionManager.clickSlot(sync, 6, hb, SlotActionType.SWAP, pl);
        return true;
    }

    /** Shift-clicks the chest slot item into the inventory. */
    public static void unequipChest() {
        var pl = p();
        MinecraftClient.getInstance().interactionManager.clickSlot(pl.playerScreenHandler.syncId, 6, 0, SlotActionType.QUICK_MOVE, pl);
    }

    public static boolean startGlide() {
        var pl = p();
        if (pl.isGliding() || pl.isOnGround() || !worn(ELYTRA)) return false;
        pl.startGliding();
        pl.networkHandler.sendPacket(new ClientCommandC2SPacket(pl, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        return true;
    }

    /** Blocks between the player and the ground below (max if none within max). */
    public static double height(double max) {
        var mc = MinecraftClient.getInstance();
        Vec3d f = mc.player.getEntityPos();
        var hit = mc.world.raycast(new RaycastContext(f, f.add(0, -max, 0), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK ? f.y - hit.getPos().y : max;
    }
}
