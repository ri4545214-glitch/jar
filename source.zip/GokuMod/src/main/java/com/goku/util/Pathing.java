package com.goku.util;

import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.function.Predicate;

/**
 * A* over the loaded world: walk, step up, drop (up to N blocks), dig down and - optionally - tunnel through safe blocks.
 * It never routes through lava / fire / cacti / berry bushes / webs, never lands in a deep drop, never mines next to liquids,
 * never mines under falling blocks, and never walks into unloaded chunks. Searches run in slices over several ticks.
 */
public final class Pathing {
    public enum Kind { WALK, UP, DROP, DIG_DOWN }

    public record Step(BlockPos pos, Kind kind, List<BlockPos> breaks) {}

    public static final class Opts {
        public boolean dig = true, water = true;
        public int maxDrop = 3, radius = 96;
    }

    public static final int PASS = 0, WATER = 1, SOLID = 2, DANGER = 3, BLOCKED = 4;
    static final Direction[] H = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    // ------------------------------------------------------------ world classification (also used by the executor)
    public static boolean dangerous(Block b) {
        return b == Blocks.LAVA || b == Blocks.FIRE || b == Blocks.SOUL_FIRE || b == Blocks.MAGMA_BLOCK || b == Blocks.CACTUS
                || b == Blocks.SWEET_BERRY_BUSH || b == Blocks.COBWEB || b == Blocks.WITHER_ROSE || b == Blocks.POWDER_SNOW
                || b == Blocks.CAMPFIRE || b == Blocks.SOUL_CAMPFIRE || b == Blocks.NETHER_PORTAL || b == Blocks.END_PORTAL
                || b == Blocks.END_GATEWAY || b == Blocks.POINTED_DRIPSTONE || b == Blocks.TNT;
    }

    public static int classify(ClientWorld w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        if (s.isAir()) return PASS;
        var f = s.getFluidState();
        if (!f.isEmpty()) return f.isIn(FluidTags.LAVA) ? DANGER : WATER;
        if (dangerous(s.getBlock())) return DANGER;
        if (s.getCollisionShape(w, p).isEmpty()) return PASS;
        if (s.isSideSolidFullSquare(w, p, Direction.UP)) return SOLID;
        return BLOCKED;
    }

    /** Can this block be mined without hurting us (no liquid next to it, nothing that falls on us, not a container/spawner)? */
    public static boolean minable(ClientWorld w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        if (s.isAir() || !s.getFluidState().isEmpty() || dangerous(s.getBlock())) return false;
        float h = s.getHardness(w, p);
        if (h < 0 || h > 12) return false;
        if (s.getBlock() instanceof BlockEntityProvider) return false;
        if (w.getBlockState(p.up()).getBlock() instanceof FallingBlock) return false;
        for (Direction d : Direction.values()) if (!w.getFluidState(p.offset(d)).isEmpty()) return false;
        return true;
    }

    // ------------------------------------------------------------ search
    static final class Node {
        final int x, y, z; Node parent; double g, f; Kind kind; List<BlockPos> breaks; boolean closed;
        Node(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
    }

    public static final class Search {
        final Opts o; final Predicate<BlockPos> goal; final double gx, gy, gz;
        final ClientWorld w = mc().world;
        final PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
        final Map<Long, Node> all = new HashMap<>();
        final Map<Long, Integer> cls = new HashMap<>();
        final int sx, sz, bottom, top;
        Node best, found; double bestH = 1e18; int expanded; boolean done;
        public static final int MAX_EXPANSIONS = 14000;

        /** goal is tested on standing (feet) positions; (gx,gy,gz) is only used to guide the search. */
        public Search(BlockPos start, Predicate<BlockPos> goal, double gx, double gy, double gz, Opts o) {
            this.o = o; this.goal = goal; this.gx = gx; this.gy = gy; this.gz = gz;
            sx = start.getX(); sz = start.getZ();
            bottom = w.getBottomY() + 2; top = w.getBottomY() + w.getHeight() - 4;
            Node n = new Node(start.getX(), start.getY(), start.getZ());
            n.f = h(n);
            open.add(n); all.put(start.asLong(), n);
        }

        double h(Node n) { double dx = n.x + 0.5 - gx, dy = n.y - gy, dz = n.z + 0.5 - gz; return Math.sqrt(dx * dx + dz * dz) + Math.abs(dy) * 1.3; }

        int c(int x, int y, int z) {
            long k = BlockPos.asLong(x, y, z);
            Integer v = cls.get(k);
            if (v == null) {
                v = w.getChunkManager().isChunkLoaded(x >> 4, z >> 4) && y >= bottom - 2 && y <= top + 2 ? classify(w, new BlockPos(x, y, z)) : BLOCKED;
                cls.put(k, v);
            }
            return v;
        }

        /** Cost to make a cell passable (0 = already open, -1 = impossible). Adds mined cells to 'br'. */
        double open(int x, int y, int z, List<BlockPos> br, boolean waterOk) {
            int k = c(x, y, z);
            if (k == PASS) return 0;
            if (k == WATER) return waterOk && o.water ? 1.5 : -1;
            if (k == DANGER || !o.dig) return -1;
            BlockPos p = new BlockPos(x, y, z);
            if (!minable(w, p)) return -1;
            br.add(p);
            return 3 + w.getBlockState(p).getHardness(w, p) * 3;
        }

        void add(Node from, int x, int y, int z, Kind kind, double cost, List<BlockPos> br) {
            if (Math.abs(x - sx) > o.radius || Math.abs(z - sz) > o.radius || y < bottom || y > top) return;
            long key = BlockPos.asLong(x, y, z);
            Node n = all.get(key);
            double g = from.g + cost;
            if (n != null && (n.closed || n.g <= g)) return;
            if (n == null) { n = new Node(x, y, z); all.put(key, n); }
            n.parent = from; n.g = g; n.kind = kind; n.breaks = br; n.f = g + h(n);
            open.add(n);
        }

        boolean support(int x, int y, int z) { return c(x, y - 1, z) == SOLID; }

        void expand(Node n) {
            int x = n.x, y = n.y, z = n.z;
            boolean inWater = c(x, y, z) == WATER;
            for (Direction d : H) {
                int tx = x + d.getOffsetX(), tz = z + d.getOffsetZ();
                // WALK
                {
                    List<BlockPos> br = new ArrayList<>(2);
                    double a = open(tx, y, tz, br, true), b = a < 0 ? -1 : open(tx, y + 1, tz, br, false);
                    if (a >= 0 && b >= 0 && (support(tx, y, tz) || c(tx, y, tz) == WATER)) add(n, tx, y, tz, Kind.WALK, 1 + a + b, br);
                }
                // UP (step up one block)
                if (!inWater || c(tx, y, tz) == SOLID) {
                    List<BlockPos> br = new ArrayList<>(3);
                    double h0 = open(x, y + 2, z, br, false);
                    double a = h0 < 0 ? -1 : open(tx, y + 1, tz, br, true), b = a < 0 ? -1 : open(tx, y + 2, tz, br, false);
                    if (a >= 0 && b >= 0 && c(tx, y, tz) == SOLID) add(n, tx, y + 1, tz, Kind.UP, 1.8 + h0 + a + b, br);
                }
                // DROP (walk off an edge, land up to maxDrop lower)
                if (c(tx, y, tz) == PASS && c(tx, y + 1, tz) == PASS && c(tx, y - 1, tz) != SOLID) {
                    for (int k = 1; k <= o.maxDrop; k++) {
                        int ky = y - k;
                        int below = c(tx, ky - 1, tz), here = c(tx, ky, tz);
                        if (here != PASS && here != WATER) break;
                        if (below == SOLID || here == WATER) { if (below != DANGER) add(n, tx, ky, tz, Kind.DROP, 1 + k * 0.8, new ArrayList<>()); break; }
                        if (below != PASS) break;
                    }
                }
            }
            // straight down: drop through air, or dig down
            if (!inWater) {
                int below = c(x, y - 1, z);
                if (below == PASS) {
                    for (int k = 1; k <= o.maxDrop; k++) {
                        int ky = y - k, b2 = c(x, ky - 1, z), here = c(x, ky, z);
                        if (here != PASS && here != WATER) break;
                        if (b2 == SOLID || here == WATER) { if (b2 != DANGER) add(n, x, ky, z, Kind.DROP, 1 + k * 0.8, new ArrayList<>()); break; }
                        if (b2 != PASS) break;
                    }
                } else if (o.dig && below != DANGER) {
                    List<BlockPos> br = new ArrayList<>(1);
                    double a = open(x, y - 1, z, br, false);
                    if (a >= 0 && c(x, y - 2, z) == SOLID) add(n, x, y - 1, z, Kind.DIG_DOWN, 1.5 + a, br);
                }
            }
        }

        /** Runs up to 'budget' expansions. Returns true when finished (found, or exhausted). */
        public boolean step(int budget) {
            if (done) return true;
            while (budget-- > 0) {
                Node n = open.poll();
                if (n == null) { done = true; return true; }
                if (n.closed) continue;
                n.closed = true; expanded++;
                if (n.parent != null && goal.test(new BlockPos(n.x, n.y, n.z))) { found = n; done = true; return true; }
                double hh = h(n);
                if (n.parent != null && hh < bestH) { bestH = hh; best = n; }
                expand(n);
                if (expanded >= MAX_EXPANSIONS) { done = true; return true; }
            }
            return false;
        }

        public boolean reached() { return found != null; }

        /** The path to the goal, or (if none) to the closest reachable point. Empty if nothing is reachable. */
        public List<Step> path() {
            Node n = found != null ? found : best;
            List<Step> out = new ArrayList<>();
            while (n != null && n.parent != null) { out.add(new Step(new BlockPos(n.x, n.y, n.z), n.kind, n.breaks)); n = n.parent; }
            Collections.reverse(out);
            return out;
        }
    }
}
