package com.goku.util;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

/** Edge-detected "trigger" buttons for modules that have no key binding of their own. Pick one in the module's Trigger setting. */
public final class Trig {
    public static final String[] NAMES = {"Middle Click", "Mouse 4", "Mouse 5", "Key V", "Key G", "Key Z", "Key X"};
    static final boolean[] was = new boolean[32];

    static boolean down(int idx) {
        long h = MinecraftClient.getInstance().getWindow().getHandle();
        return switch (idx) {
            case 0 -> GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
            case 1 -> GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_4) == GLFW.GLFW_PRESS;
            case 2 -> GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_5) == GLFW.GLFW_PRESS;
            case 3 -> GLFW.glfwGetKey(h, GLFW.GLFW_KEY_V) == GLFW.GLFW_PRESS;
            case 4 -> GLFW.glfwGetKey(h, GLFW.GLFW_KEY_G) == GLFW.GLFW_PRESS;
            case 5 -> GLFW.glfwGetKey(h, GLFW.GLFW_KEY_Z) == GLFW.GLFW_PRESS;
            default -> GLFW.glfwGetKey(h, GLFW.GLFW_KEY_X) == GLFW.GLFW_PRESS;
        };
    }

    /** True once when the chosen trigger goes down. Use a different slot (0..31) per module. */
    public static boolean pressed(int idx, int slot) {
        boolean now = down(idx);
        boolean r = now && !was[slot];
        was[slot] = now;
        return r;
    }
}
