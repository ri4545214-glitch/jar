package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    /** Real keyboard state of a key binding (works while a screen is open). Mouse-bound keys fall back to the binding state. */
    public static boolean physical(KeyBinding kb) {
        try {
            InputUtil.Key k = InputUtil.fromTranslationKey(kb.getBoundKeyTranslationKey());
            if (k.getCategory() != InputUtil.Type.KEYSYM) return kb.isPressed();
            return GLFW.glfwGetKey(MinecraftClient.getInstance().getWindow().getHandle(), k.getCode()) == GLFW.GLFW_PRESS;
        } catch (Throwable t) { return kb.isPressed(); }
    }
}
