package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** World -> HUD-space projection (no render-pipeline hooks, so ESP works through walls). */
public final class Projector {
    public static Vec3d cam = Vec3d.ZERO;
    static double fx, fy, fz, rx, ry, rz, ux, uy, uz, tan;
    public static int W, H;
    public static boolean ok;

    public static void update(MinecraftClient mc, float td) {
        Entity e = mc.getCameraEntity();
        if (e == null) { ok = false; return; }
        cam = e.getCameraPosVec(td);
        double yaw = Math.toRadians(e.getYaw(td)), pitch = Math.toRadians(e.getPitch(td));
        fx = -Math.sin(yaw) * Math.cos(pitch); fy = -Math.sin(pitch); fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw); ry = 0; rz = -Math.sin(yaw);
        ux = ry * fz - rz * fy; uy = rz * fx - rx * fz; uz = rx * fy - ry * fx;
        tan = Math.tan(Math.toRadians(fov(mc)) / 2.0);
        W = mc.getWindow().getScaledWidth();
        H = mc.getWindow().getScaledHeight();
        ok = true;
    }

    /** The FOV the game really renders with: the option, plus the sprint / speed / flying / bow zoom. */
    static double fov(MinecraftClient mc) {
        double fov = mc.options.getFov().getValue();
        var p = mc.player;
        if (p == null || mc.getCameraEntity() != p) return fov;
        try {
            float f = 1f;
            var ab = p.getAbilities();
            if (ab.flying) f *= 1.1f;
            double walk = ab.getWalkSpeed();
            if (walk > 0) f *= (float) ((p.getAttributeValue(EntityAttributes.MOVEMENT_SPEED) / walk + 1.0) / 2.0);
            if (p.isUsingItem() && p.getActiveItem().isOf(Items.BOW)) { float g = Math.min(p.getItemUseTime() / 20f, 1f); f *= 1f - g * g * 0.15f; }
            float scale = mc.options.getFovEffectScale().getValue().floatValue();
            return fov * (1f + (f - 1f) * scale);
        } catch (Throwable t) { return fov; }
    }

    static boolean bobSaved, bobOverridden;

    /** View bobbing moves the world but not the HUD, which makes every ESP wobble: switch it off while an ESP is on, restore it after. */
    public static void steady(MinecraftClient mc) {
        boolean need = com.goku.Modules.PLAYER_ESP.enabled || com.goku.Modules.TRACERS.enabled || com.goku.Modules.NAME_TAGS.enabled
            || com.goku.Modules.STORAGE.enabled || com.goku.Modules.SPAWNER.enabled || com.goku.Modules.BASE_FINDER.enabled
            || com.goku.Modules.ENTITY_FINDER.enabled || com.goku.Modules.TARGET_RENDERER.enabled || com.goku.Modules.TRAJECTORIES.enabled;
        var opt = mc.options.getBobView();
        if (need && !bobOverridden) { bobSaved = opt.getValue(); bobOverridden = true; }
        if (bobOverridden) { if (need) opt.setValue(false); else { opt.setValue(bobSaved); bobOverridden = false; } }
    }

    public static double[] to(Vec3d p) {
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.01) return null;
        double x = dx * rx + dy * ry + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double aspect = (double) W / H;
        return new double[]{ W / 2.0 + x / (z * tan * aspect) * W / 2.0, H / 2.0 - y / (z * tan) * H / 2.0, z };
    }

    public static double depth(Vec3d p) { return (p.x - cam.x) * fx + (p.y - cam.y) * fy + (p.z - cam.z) * fz; }

    /** Projects a 3D segment, clipped against the near plane. Returns {x1,y1,x2,y2} or null. */
    public static double[] clipLine(Vec3d a, Vec3d b) {
        double za = depth(a), zb = depth(b);
        if (za < 0.05 && zb < 0.05) return null;
        if (za < 0.05) a = a.lerp(b, (0.05 - za) / (zb - za));
        else if (zb < 0.05) b = b.lerp(a, (0.05 - zb) / (za - zb));
        double[] p = to(a), q = to(b);
        if (p == null || q == null) return null;
        return new double[]{ p[0], p[1], q[0], q[1] };
    }

    /** Like to(), but points behind the camera are pushed to the screen edge (for tracers). */
    public static double[] toEdge(Vec3d p) {
        double[] s = to(p);
        if (s != null) return s;
        double dx = p.x - cam.x, dy = p.y - cam.y, dz = p.z - cam.z;
        double x = dx * rx + dy * ry + dz * rz, y = dx * ux + dy * uy + dz * uz;
        double len = Math.hypot(x, y);
        if (len < 1e-6) { x = 0; y = -1; len = 1; }
        double k = Math.max(W, H);
        return new double[]{ W / 2.0 + x / len * k, H / 2.0 - y / len * k, 0 };
    }

    /** 2D bounding rect {minX,minY,maxX,maxY} of a box (edges are clipped at the camera, so close-up boxes still draw), or null if off screen. */
    public static int[] box(Box b) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        Vec3d[] v = new Vec3d[8];
        for (int i = 0; i < 8; i++) v[i] = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
        boolean any = false;
        for (int i = 0; i < 8; i++) for (int bit = 1; bit <= 4; bit <<= 1) {
            if ((i & bit) != 0) continue;
            double[] l = clipLine(v[i], v[i | bit]);
            if (l == null) continue;
            any = true;
            minX = Math.min(minX, Math.min(l[0], l[2])); maxX = Math.max(maxX, Math.max(l[0], l[2]));
            minY = Math.min(minY, Math.min(l[1], l[3])); maxY = Math.max(maxY, Math.max(l[1], l[3]));
        }
        if (!any || maxX < 0 || maxY < 0 || minX > W || minY > H) return null;
        minX = Math.max(-2000, minX); minY = Math.max(-2000, minY); maxX = Math.min(W + 2000, maxX); maxY = Math.min(H + 2000, maxY);
        if (maxX - minX < 3) maxX = minX + 3;
        if (maxY - minY < 3) maxY = minY + 3;
        return new int[]{ (int) minX, (int) minY, (int) maxX, (int) maxY };
    }
}
