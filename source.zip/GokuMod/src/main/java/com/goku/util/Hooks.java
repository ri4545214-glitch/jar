package com.goku.util;

import com.goku.Modules;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;

public final class Hooks {
    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && player == net.minecraft.client.MinecraftClient.getInstance().player) {
                if (Modules.HIT_SWAP.enabled) Modules.HIT_SWAP.onAttack(entity);
                if (Modules.CRYSTAL_OPT.enabled) Modules.CRYSTAL_OPT.onAttack(entity);
                if (Modules.AUTO_TEXT.enabled) Modules.AUTO_TEXT.onAttack(entity);
                if (Modules.WTAP.enabled) Modules.WTAP.onAttack(entity);
            }
            return ActionResult.PASS;
        });
    }
}
