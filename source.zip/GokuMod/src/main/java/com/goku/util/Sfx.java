package com.goku.util;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.MovingSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

import java.util.HashMap;
import java.util.Map;

/** GUI sounds + music player (assets/gokumod/sounds.json). Events are not registered, only looked up by id. */
public final class Sfx {
    /** Sound ids in sounds.json. To add a song: drop an .ogg in assets/gokumod/sounds, add an entry in sounds.json, then add its id + display name below. */
    public static final String[] TRACKS = {"phonk", "aura", "aurafunk", "chubina", "chubina127"};
    public static final String[] TRACK_NAMES = {"Phonk (original)", "Aura Phonk (original)", "Aura Funk", "Chubina Slowed", "Chubina 127 Slowed"};
    static final Map<String, SoundEvent> EV = new HashMap<>();
    static final java.util.Random RND = new java.util.Random();
    static Loop loop;
    static int loopMode = -1, lastTrack = -1;
    /** Set by the ClickGui while it is open. */
    public static boolean guiOpen;

    static SoundEvent ev(String n) { return EV.computeIfAbsent(n, k -> SoundEvent.of(Identifier.of("gokumod", k))); }

    public static void play(String n, float pitch) {
        if (!Modules.SOUND.sfx.b) return;
        MinecraftClient.getInstance().getSoundManager().play(new Shot(n, pitch, (float) (Modules.SOUND.sfxVol.v / 100.0)));
    }

    /** Called every client tick: starts/stops/switches the music so it can play with or without the GUI. */
    public static void tick() {
        var s = Modules.SOUND;
        var sm = MinecraftClient.getInstance().getSoundManager();
        boolean want = s.music.b && (guiOpen || s.keep.b);
        if (!want) { stopMusic(); return; }
        int mode = s.track.idx;                       // 0..TRACKS.length-1 = a track, TRACKS.length = shuffle
        if (loop != null) {
            boolean ended = System.nanoTime() - loop.started > 3_000_000_000L && !sm.isPlaying(loop);
            if (ended || mode != loopMode) stopMusic();
        }
        if (loop == null) {
            boolean shuf = mode >= TRACKS.length;
            boolean classic = mode > TRACKS.length;          // "Classic Shuffle": only the two original songs
            int pool = classic ? 2 : TRACKS.length;
            int t = shuf ? (lastTrack < 0 || lastTrack >= pool ? RND.nextInt(pool) : (lastTrack + 1) % pool) : mode;
            lastTrack = t; loopMode = mode;
            loop = new Loop(TRACKS[t], shuf);
            sm.play(loop);
        }
    }

    public static void stopMusic() {
        if (loop != null) { MinecraftClient.getInstance().getSoundManager().stop(loop); loop = null; }
        loopMode = -1;
    }

    /** One-shot UI sound (not positional). */
    static class Shot extends MovingSoundInstance {
        Shot(String n, float pitch, float vol) {
            super(ev(n), SoundCategory.MASTER, Random.create());
            this.volume = vol; this.pitch = pitch; this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
        }
        @Override public void tick() {}
    }

    static class Loop extends MovingSoundInstance {
        final boolean shuffle;
        final long started = System.nanoTime();
        Loop(String track, boolean shuffle) {
            super(ev(track), SoundCategory.MASTER, Random.create());
            this.shuffle = shuffle;
            this.repeat = !shuffle; this.repeatDelay = 0; this.relative = true;
            this.attenuationType = SoundInstance.AttenuationType.NONE;
            tick();
        }
        @Override public void tick() {
            this.volume = (float) (Modules.SOUND.musicVol.v / 100.0);
            this.pitch = (float) Modules.SOUND.musicPitch.v;
        }
    }
}
