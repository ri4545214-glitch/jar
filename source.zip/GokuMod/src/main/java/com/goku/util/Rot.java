package com.goku.util;

import com.goku.modules.LegitMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class Rot {
    /** Turns towards a point. With Legit Mode human aim on it turns in capped, noisy steps. Returns true once aligned. */
    public static boolean face(Vec3d to) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        float[] r = Targets.rot(p.getEyePos(), to);
        if (LegitMode.human()) {
            float dy = Targets.wrap(r[0] - p.getYaw()), dp = r[1] - p.getPitch();
            float m = LegitMode.maxTurn(180f);
            p.setYaw(p.getYaw() + Math.max(-m, Math.min(m, dy)) + LegitMode.noise());
            p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + Math.max(-m, Math.min(m, dp)) + LegitMode.noise())));
            return Math.abs(dy) <= 12f && Math.abs(dp) <= 12f;
        }
        p.setYaw(r[0]); p.setPitch(r[1]);
        return true;
    }
}
