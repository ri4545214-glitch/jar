package com.goku.util;

import com.goku.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Rotation helper: with Smooth Rotation on, turns a limited amount per tick (no instant snap) and reports when aligned. */
public final class Rot {
    public static boolean face(Vec3d to) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        float[] r = Targets.rot(p.getEyePos(), to);
        return faceAngles(r[0], r[1]);
    }

    /** @return true when the view is (close enough to) the requested angles and the caller may act now. */
    public static boolean faceAngles(float yaw, float pitch) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        float dy = Targets.wrap(yaw - p.getYaw()), dp = pitch - p.getPitch();
        if (!Modules.SMOOTH.enabled) { p.setYaw(yaw); p.setPitch(Math.max(-90f, Math.min(90f, pitch))); return true; }
        float m = (float) Modules.SMOOTH.maxTurn.v, big = Math.max(Math.abs(dy), Math.abs(dp));
        float k = big > m ? m / big : 1f;
        p.setYaw(p.getYaw() + dy * k);
        p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + dp * k)));
        return big * (1f - k) <= Modules.SMOOTH.tol.v;
    }
}
