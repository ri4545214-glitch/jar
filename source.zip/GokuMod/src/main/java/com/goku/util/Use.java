package com.goku.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;

public final class Use {
    /** Selects a hotbar slot, uses the item with the given look angles (the use packet carries them), then restores look + slot. */
    public static boolean item(int slot, float yaw, float pitch, boolean swapBack) {
        if (slot < 0) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        int prev = Inv.selected();
        float oy = p.getYaw(), op = p.getPitch();
        Inv.select(slot);
        p.setYaw(yaw); p.setPitch(pitch);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setYaw(oy); p.setPitch(op);
        if (swapBack) Inv.select(prev);
        return true;
    }
}
