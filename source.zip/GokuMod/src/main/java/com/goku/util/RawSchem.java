package com.goku.util;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Minecraft-free schematic loader for Litematica (.litematic) and vanilla structure (.nbt) files.
 * Result: a size, a palette of block state strings ("minecraft:lever[face=wall,facing=east]") and one palette index per cell
 * (x fastest, then z, then y).
 */
public final class RawSchem {
    public int width, height, length;
    public final List<String> palette = new ArrayList<>();
    public int[] cells;
    public String name = "";

    static String stateString(Map<String, Object> st) {
        String n = (String) st.get("Name");
        Map<String, Object> pr = NbtLite.map(st.get("Properties"));
        if (pr == null || pr.isEmpty()) return n;
        StringBuilder sb = new StringBuilder(n).append('[');
        boolean first = true;
        for (var e : new java.util.TreeMap<>(pr).entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append(e.getKey()).append('=').append(e.getValue());
        }
        return sb.append(']').toString();
    }

    public static RawSchem load(Path file) throws IOException {
        String n = file.getFileName().toString().toLowerCase();
        Map<String, Object> root = NbtLite.readFile(file);
        RawSchem r = n.endsWith(".litematic") ? litematic(root) : structure(root);
        r.name = file.getFileName().toString();
        return r;
    }

    // ---- Litematica
    static RawSchem litematic(Map<String, Object> root) throws IOException {
        Map<String, Object> regions = NbtLite.map(root.get("Regions"));
        if (regions == null || regions.isEmpty()) throw new IOException("no regions in litematic");
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (Object o : regions.values()) {
            Map<String, Object> reg = NbtLite.map(o);
            Map<String, Object> pos = NbtLite.map(reg.get("Position")), sz = NbtLite.map(reg.get("Size"));
            int px = NbtLite.num(pos.get("x")), py = NbtLite.num(pos.get("y")), pz = NbtLite.num(pos.get("z"));
            int sx = NbtLite.num(sz.get("x")), sy = NbtLite.num(sz.get("y")), sz2 = NbtLite.num(sz.get("z"));
            int x0 = sx < 0 ? px + sx + 1 : px, y0 = sy < 0 ? py + sy + 1 : py, z0 = sz2 < 0 ? pz + sz2 + 1 : pz;
            minX = Math.min(minX, x0); minY = Math.min(minY, y0); minZ = Math.min(minZ, z0);
            maxX = Math.max(maxX, x0 + Math.abs(sx)); maxY = Math.max(maxY, y0 + Math.abs(sy)); maxZ = Math.max(maxZ, z0 + Math.abs(sz2));
        }
        RawSchem r = new RawSchem();
        r.width = maxX - minX; r.height = maxY - minY; r.length = maxZ - minZ;
        long total = (long) r.width * r.height * r.length;
        if (total > 40_000_000L) throw new IOException("schematic too large");
        r.cells = new int[(int) total];
        r.palette.add("minecraft:air");
        Map<String, Integer> index = new HashMap<>();
        index.put("minecraft:air", 0);
        for (Object o : regions.values()) {
            Map<String, Object> reg = NbtLite.map(o);
            Map<String, Object> pos = NbtLite.map(reg.get("Position")), sz = NbtLite.map(reg.get("Size"));
            int px = NbtLite.num(pos.get("x")), py = NbtLite.num(pos.get("y")), pz = NbtLite.num(pos.get("z"));
            int sx = NbtLite.num(sz.get("x")), sy = NbtLite.num(sz.get("y")), sz2 = NbtLite.num(sz.get("z"));
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz2);
            int ox = (sx < 0 ? px + sx + 1 : px) - minX, oy = (sy < 0 ? py + sy + 1 : py) - minY, oz = (sz2 < 0 ? pz + sz2 + 1 : pz) - minZ;
            List<Object> pal = NbtLite.list(reg.get("BlockStatePalette"));
            long[] data = (long[]) reg.get("BlockStates");
            if (pal == null || data == null) throw new IOException("bad litematic region");
            int[] map = new int[pal.size()];
            for (int i = 0; i < map.length; i++) {
                String s = stateString(NbtLite.map(pal.get(i)));
                Integer id = index.get(s);
                if (id == null) { id = r.palette.size(); r.palette.add(s); index.put(s, id); }
                map[i] = id;
            }
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(Math.max(1, pal.size() - 1)));
            long mask = (1L << bits) - 1;
            long vol = (long) ax * ay * az;
            for (long i = 0; i < vol; i++) {
                long bit = i * bits;
                int li = (int) (bit >>> 6), off = (int) (bit & 63);
                if (li >= data.length) break;
                long v = data[li] >>> off;
                if (off + bits > 64 && li + 1 < data.length) v |= data[li + 1] << (64 - off);
                int pi = (int) (v & mask);
                if (pi >= map.length) continue;
                int x = (int) (i % ax), z = (int) ((i / ax) % az), y = (int) (i / ((long) ax * az));
                r.cells[((y + oy) * r.length + (z + oz)) * r.width + (x + ox)] = map[pi];
            }
        }
        return r;
    }

    // ---- vanilla structure block .nbt
    static RawSchem structure(Map<String, Object> root) throws IOException {
        List<Object> size = NbtLite.list(root.get("size")), pal = NbtLite.list(root.get("palette")), blocks = NbtLite.list(root.get("blocks"));
        if (size == null || pal == null || blocks == null) throw new IOException("unsupported .nbt (need a vanilla structure file)");
        RawSchem r = new RawSchem();
        r.width = NbtLite.num(size.get(0)); r.height = NbtLite.num(size.get(1)); r.length = NbtLite.num(size.get(2));
        r.cells = new int[r.width * r.height * r.length];
        r.palette.add("minecraft:air");
        int[] map = new int[pal.size()];
        for (int i = 0; i < map.length; i++) { map[i] = r.palette.size(); r.palette.add(stateString(NbtLite.map(pal.get(i)))); }
        for (Object o : blocks) {
            Map<String, Object> b = NbtLite.map(o);
            List<Object> p = NbtLite.list(b.get("pos"));
            int x = NbtLite.num(p.get(0)), y = NbtLite.num(p.get(1)), z = NbtLite.num(p.get(2)), s = NbtLite.num(b.get("state"));
            if (x < 0 || y < 0 || z < 0 || x >= r.width || y >= r.height || z >= r.length || s >= map.length) continue;
            r.cells[(y * r.length + z) * r.width + x] = map[s];
        }
        return r;
    }
}
