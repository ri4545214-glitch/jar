package com.goku.bot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** config/gokumod/bot.json: the bot's name tag and the player whose skin it wears. Edit it, then press "> Reload Bot Config". */
public final class BotConfig {
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static String name = "Goku_Bot";
    public static String skin = "Steve";
    public static boolean showName = true;

    public static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod").resolve("bot.json"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) {
                Files.createDirectories(f.getParent());
                JsonObject o = new JsonObject();
                o.addProperty("name", name); o.addProperty("skin", skin); o.addProperty("showName", showName);
                Files.writeString(f, GSON.toJson(o));
                return;
            }
            JsonObject o = GSON.fromJson(Files.readString(f), JsonObject.class);
            if (o.has("name")) name = o.get("name").getAsString();
            if (o.has("skin")) skin = o.get("skin").getAsString();
            if (o.has("showName")) showName = o.get("showName").getAsBoolean();
        } catch (Exception ignored) {}
        name = name.replaceAll("[^A-Za-z0-9_ ]", "");
        if (name.isEmpty()) name = "Goku_Bot";
        if (name.length() > 24) name = name.substring(0, 24);
        skin = skin.replaceAll("[^A-Za-z0-9_]", "");
        if (skin.isEmpty() || skin.length() > 16) skin = "Steve";
    }
}
