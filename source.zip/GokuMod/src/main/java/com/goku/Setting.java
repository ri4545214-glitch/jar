package com.goku;

public class Setting {
    public enum Type { BOOL, NUM, MODE, COLOR }
    public final String name;
    public final Type type;
    public boolean b;
    public double v, min, max, step;
    public String[] modes;
    public int idx;
    public float anim = -1; // GUI animation state
    public int rgb = 0xFFFFFF;          // COLOR settings: 0xRRGGBB
    public float hue, sat, val = 1f;    // COLOR settings: HSV mirror of rgb (for the colour wheel)
    public boolean open;                // COLOR settings: wheel expanded in the GUI

    private Setting(String n, Type t) { name = n; type = t; }

    public static Setting bool(String n, boolean d) { Setting s = new Setting(n, Type.BOOL); s.b = d; return s; }
    public static Setting num(String n, double d, double min, double max, double step) {
        Setting s = new Setting(n, Type.NUM); s.v = d; s.min = min; s.max = max; s.step = step; return s;
    }
    public static Setting mode(String n, int idx, String... m) {
        Setting s = new Setting(n, Type.MODE); s.idx = idx; s.modes = m; return s;
    }
    public static Setting color(String n, int rgb) { Setting s = new Setting(n, Type.COLOR); s.setRgb(rgb); return s; }
    public int argb() { return 0xFF000000 | rgb; }
    public void setRgb(int c) {
        rgb = c & 0xFFFFFF;
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn;
        val = mx; sat = mx <= 0 ? 0 : d / mx;
        if (d <= 0) hue = 0;
        else if (mx == r) hue = ((g - b) / d + 6f) % 6f / 6f;
        else if (mx == g) hue = ((b - r) / d + 2f) / 6f;
        else hue = ((r - g) / d + 4f) / 6f;
    }
    public void setHsv(float h, float s, float v) { hue = h; sat = s; val = v; rgb = hsvToRgb(h, s, v); }
    public static int hsvToRgb(float h, float s, float v) {
        h = ((h % 1f) + 1f) % 1f;
        float k = h * 6f; int i = (int) k; float f = k - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s), r, g, b;
        switch (i % 6) { case 0 -> { r = v; g = t; b = p; } case 1 -> { r = q; g = v; b = p; } case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; } case 4 -> { r = t; g = p; b = v; } default -> { r = v; g = p; b = q; } }
        return ((int) (r * 255 + .5f) << 16) | ((int) (g * 255 + .5f) << 8) | (int) (b * 255 + .5f);
    }
    public String modeName() { return modes[idx]; }
    public void cycle() { idx = (idx + 1) % modes.length; }
    public int i() { return (int) Math.round(v); }
}
