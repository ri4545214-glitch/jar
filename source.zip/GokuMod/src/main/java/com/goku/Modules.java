package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final XRay XRAY = new XRay();
    public static final SpawnerEsp SPAWNER = new SpawnerEsp();
    public static final BaseEsp BASE_FINDER = new BaseEsp();
    public static final EntityEsp ENTITY_FINDER = new EntityEsp();
    public static final ChunkLog CHUNK_LOG = new ChunkLog();
    public static final ParticleModule PARTICLES = new ParticleModule();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final AnchorMacro ANCHOR = new AnchorMacro();
    public static final AutoCrystal CRYSTAL = new AutoCrystal();
    public static final AutoTotem TOTEM = new AutoTotem();
    public static final HoverTotem HOVER_TOTEM = new HoverTotem();
    public static final Speed SPEED = new Speed();
    public static final AutoBridge BRIDGE = new AutoBridge();
    public static final BaseAi BASE_AI = new BaseAi();
    public static final CrystalPvp CRYSTAL_PVP = new CrystalPvp();
    public static final AutoClicker AUTO_CLICKER = new AutoClicker();
    public static final AutoWalk AUTO_WALK = new AutoWalk();
    public static final AutoMine AUTO_MINE = new AutoMine();
    public static final AutoFind AUTO_FIND = new AutoFind();
    public static final PlayerHunter HUNTER = new PlayerHunter();
    public static final AirAnchor AIR_ANCHOR = new AirAnchor();
    public static final SafeAnchor SAFE_ANCHOR = new SafeAnchor();
    public static final AutoDTap DTAP = new AutoDTap();
    public static final FeetTrap FEET_TRAP = new FeetTrap();
    public static final AutoTrap AUTO_TRAP = new AutoTrap();
    public static final AutoPot AUTO_POT = new AutoPot();
    public static final BowAim BOW_AIM = new BowAim();
    public static final SkinChanger SKIN = new SkinChanger();
    public static final LegitMode LEGIT = new LegitMode();
    public static final AutoExplore EXPLORE = new AutoExplore();
    public static final WaterClutch CLUTCH = new WaterClutch();
    public static final AutoBuilder BUILDER = new AutoBuilder();
    public static final LowFire LOW_FIRE = new LowFire();
    public static final Performance PERF = new Performance();
    public static final FpsCounter FPS = new FpsCounter();
    public static final Keystrokes KEYSTROKES = new Keystrokes();
    public static final Waypoints WAYPOINTS = new Waypoints();
    public static final Zoom ZOOM = new Zoom();
    public static final Fullbright FULLBRIGHT = new Fullbright();
    /** The practice bot lives in com.goku.bot and is loaded by name so the rest of the mod still builds with -Penable_bot=false. */
    static Module loadBot() {
        try { return (Module) Class.forName("com.goku.bot.BotModule").getDeclaredConstructor().newInstance(); } catch (Throwable t) { return null; }
    }
    public static final Module BOT = loadBot();
    public static final List<Module> BOTS = BOT == null ? List.of() : List.of(BOT);
    public static final ConfigModule CONFIG = new ConfigModule();
    public static final SoundModule SOUND = new SoundModule();
    public static final ThemeModule THEME = new ThemeModule();
    public static final GuiStyle GUI_STYLE = new GuiStyle();
    public static final AutoMace AUTO_MACE = new AutoMace();
    public static final WindLaunch WIND_LAUNCH = new WindLaunch();
    public static final MaceSwap MACE_SWAP = new MaceSwap();
    public static final CartAura CART_AURA = new CartAura();
    public static final CartDefuse CART_DEFUSE = new CartDefuse();
    public static final PotRefill POT_REFILL = new PotRefill();
    public static final PotThrow POT_THROW = new PotThrow();
    public static final PvpCounter PVP_COUNTER = new PvpCounter();
    public static final Navigator NAVIGATOR = new Navigator();
    public static final SmoothRotation SMOOTH = new SmoothRotation();
    public static final Sprint SPRINT = new Sprint();
    public static final NoJumpDelay NO_JUMP_DELAY = new NoJumpDelay();
    public static final FastPlace FAST_PLACE = new FastPlace();
    public static final AutoRespawn AUTO_RESPAWN = new AutoRespawn();
    public static final NoScoreboard NO_SCOREBOARD = new NoScoreboard();
    public static final ScreenMove SCREEN_MOVE = new ScreenMove();
    public static final AntiCobweb ANTI_COBWEB = new AntiCobweb();
    public static final AutoStairs AUTO_STAIRS = new AutoStairs();
    public static final AutoTool AUTO_TOOL = new AutoTool();
    public static final AntiFire ANTI_FIRE = new AntiFire();
    public static final AntiBot ANTI_BOT = new AntiBot();
    public static final Tracers TRACERS = new Tracers();
    public static final AutoPearl AUTO_PEARL = new AutoPearl();
    public static final AutoElytra AUTO_ELYTRA = new AutoElytra();
    public static final MaceFinisher MACE_FINISH = new MaceFinisher();
    public static final PotAim POT_AIM = new PotAim();
    public static final CartEsp CART_ESP = new CartEsp();
    public static final CartGuard CART_GUARD = new CartGuard();
    public static final ElytraSwap ELYTRA_SWAP = new ElytraSwap();
    public static final ElytraBoost ELYTRA_BOOST = new ElytraBoost();
    public static final MaceChain MACE_CHAIN = new MaceChain();
    public static final MaceDive MACE_DIVE = new MaceDive();

    // ---- sections: every module lives in exactly one of these
    public static final List<Module> COMBAT = List.of(AUTO_AIM, AUTO_ATTACK, KILL_AURA, TOTEM, HOVER_TOTEM, AUTO_PEARL, ANTI_BOT, SMOOTH, FEET_TRAP, AUTO_TRAP, BOW_AIM);
    public static final List<Module> CRYSTAL_SEC = List.of(CRYSTAL_PVP, DTAP, CRYSTAL, ANCHOR, SAFE_ANCHOR, AIR_ANCHOR);
    public static final List<Module> MACE_SEC = List.of(AUTO_MACE, MACE_FINISH, MACE_CHAIN, MACE_DIVE, WIND_LAUNCH, MACE_SWAP);
    public static final List<Module> ELYTRA_SEC = List.of(AUTO_ELYTRA, ELYTRA_SWAP, ELYTRA_BOOST);
    public static final List<Module> CART_SEC = List.of(CART_AURA, CART_DEFUSE, CART_GUARD, CART_ESP);
    public static final List<Module> POT_SEC = List.of(AUTO_POT, POT_REFILL, POT_THROW, POT_AIM, PVP_COUNTER);
    public static final List<Module> MOVEMENT = List.of(SPRINT, NO_JUMP_DELAY, AUTO_STAIRS, SCREEN_MOVE, ANTI_COBWEB, ANTI_FIRE, SPEED, BRIDGE, CLUTCH);
    public static final List<Module> VISUAL = List.of(PLAYER_ESP, TRACERS, ENTITY_FINDER, STORAGE, SPAWNER, XRAY, FULLBRIGHT, ZOOM, FREECAM, LOW_FIRE);
    public static final List<Module> AUTOMATION = List.of(AUTO_CLICKER, AUTO_WALK, AUTO_MINE, AUTO_FIND, HUNTER, EXPLORE, BUILDER, NAVIGATOR);
    public static final List<Module> BASE = List.of(BASE_AI, BASE_FINDER, SUS, CHUNK_LOG);
    public static final List<Module> UTILITY = List.of(AUTO_TOOL, FAST_PLACE, AUTO_RESPAWN, NO_SCOREBOARD, PERF, SKIN);
    public static final List<Module> HUD = List.of(FPS, KEYSTROKES, WAYPOINTS);
    public static final List<Module> SETTINGS = List.of(LEGIT, THEME, GUI_STYLE, PARTICLES, SOUND, CONFIG);

    /** Ordered sections (name -> modules) and the short tag shown on the section icon. Used by every GUI. */
    public static final Map<String, List<Module>> SECTIONS = new LinkedHashMap<>();
    public static final Map<String, String> TAGS = new HashMap<>();
    static void sec(String name, String tag, List<Module> l) { if (!l.isEmpty()) { SECTIONS.put(name, l); TAGS.put(name, tag); } }
    public static final List<Module> ALL = new ArrayList<>();
    public static final List<Module> EVERY = new ArrayList<>();
    static {
        sec("Combat", "C", COMBAT); sec("Crystal PvP", "Cr", CRYSTAL_SEC); sec("Mace PvP", "Ma", MACE_SEC); sec("Elytra", "El", ELYTRA_SEC);
        sec("Cart PvP", "Ct", CART_SEC); sec("Nethpot", "Np", POT_SEC); sec("Movement", "Mv", MOVEMENT); sec("Visual", "V", VISUAL);
        sec("Automation", "Au", AUTOMATION); sec("Base", "B", BASE); sec("Utility", "U", UTILITY); sec("HUD", "H", HUD);
        sec("Practice Bot", "Pb", BOTS); sec("Settings", "St", SETTINGS);
        Set<Module> cfg = Set.of(THEME, GUI_STYLE, PARTICLES, SOUND, CONFIG);
        for (List<Module> l : SECTIONS.values()) for (Module m : l) if (!cfg.contains(m)) ALL.add(m);
        EVERY.addAll(ALL);
        EVERY.add(THEME); EVERY.add(GUI_STYLE); EVERY.add(PARTICLES); EVERY.add(SOUND); EVERY.add(CONFIG);
    }
    public static List<Module> section(String name) { return SECTIONS.getOrDefault(name, List.of()); }

    public static int accent() { return THEME.accent(); }
    public static int accent2() { return THEME.accent2(); }
}
