package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final XRay XRAY = new XRay();
    public static final SpawnerEsp SPAWNER = new SpawnerEsp();
    public static final BaseEsp BASE_FINDER = new BaseEsp();
    public static final EntityEsp ENTITY_FINDER = new EntityEsp();
    public static final ChunkLog CHUNK_LOG = new ChunkLog();
    public static final ParticleModule PARTICLES = new ParticleModule();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final AnchorMacro ANCHOR = new AnchorMacro();
    public static final AutoCrystal CRYSTAL = new AutoCrystal();
    public static final AutoTotem TOTEM = new AutoTotem();
    public static final HoverTotem HOVER_TOTEM = new HoverTotem();
    public static final Speed SPEED = new Speed();
    public static final AutoBridge BRIDGE = new AutoBridge();
    public static final BaseAi BASE_AI = new BaseAi();
    public static final CrystalPvp CRYSTAL_PVP = new CrystalPvp();
    public static final AutoClicker AUTO_CLICKER = new AutoClicker();
    public static final AutoWalk AUTO_WALK = new AutoWalk();
    public static final AutoMine AUTO_MINE = new AutoMine();
    public static final AutoFind AUTO_FIND = new AutoFind();
    public static final PlayerHunter HUNTER = new PlayerHunter();
    public static final AirAnchor AIR_ANCHOR = new AirAnchor();
    public static final SafeAnchor SAFE_ANCHOR = new SafeAnchor();
    public static final AutoDTap DTAP = new AutoDTap();
    public static final FeetTrap FEET_TRAP = new FeetTrap();
    public static final AutoTrap AUTO_TRAP = new AutoTrap();
    public static final AutoPot AUTO_POT = new AutoPot();
    public static final BowAim BOW_AIM = new BowAim();
    public static final WaterClutch CLUTCH = new WaterClutch();
    public static final AutoBuilder BUILDER = new AutoBuilder();
    public static final LowFire LOW_FIRE = new LowFire();
    public static final Performance PERF = new Performance();
    public static final FpsCounter FPS = new FpsCounter();
    public static final Keystrokes KEYSTROKES = new Keystrokes();
    public static final Waypoints WAYPOINTS = new Waypoints();
    public static final Zoom ZOOM = new Zoom();
    public static final Fullbright FULLBRIGHT = new Fullbright();
    /** The practice bot lives in com.goku.bot and is loaded by name so the rest of the mod still builds with -Penable_bot=false. */
    static Module loadBot() {
        try { return (Module) Class.forName("com.goku.bot.BotModule").getDeclaredConstructor().newInstance(); } catch (Throwable t) { return null; }
    }
    public static final Module BOT = loadBot();
    public static final List<Module> BOTS = BOT == null ? List.of() : List.of(BOT);
    public static final ConfigModule CONFIG = new ConfigModule();
    public static final SoundModule SOUND = new SoundModule();
    public static final ThemeModule THEME = new ThemeModule();

    public static final List<Module> BASE = List.of(XRAY, BASE_AI, STORAGE, SPAWNER, BASE_FINDER, ENTITY_FINDER, SUS, CHUNK_LOG, FREECAM);
    public static final List<Module> COMBAT = List.of(PLAYER_ESP, CRYSTAL_PVP, DTAP, AUTO_AIM, AUTO_ATTACK, KILL_AURA, CRYSTAL, ANCHOR, SAFE_ANCHOR, AIR_ANCHOR, TOTEM, HOVER_TOTEM, FEET_TRAP, AUTO_TRAP, AUTO_POT, BOW_AIM);
    public static final List<Module> MOVEMENT = List.of(SPEED, BRIDGE, CLUTCH);
    public static final List<Module> AUTOMATION = List.of(AUTO_CLICKER, AUTO_WALK, AUTO_MINE, AUTO_FIND, HUNTER, BUILDER);
    public static final List<Module> MODS = List.of(FPS, KEYSTROKES, WAYPOINTS, ZOOM, FULLBRIGHT, LOW_FIRE, PERF);
    public static final List<Module> ALL = new ArrayList<>();
    public static final List<Module> EVERY = new ArrayList<>();
    static { ALL.addAll(BASE); ALL.addAll(COMBAT); ALL.addAll(MOVEMENT); ALL.addAll(AUTOMATION); ALL.addAll(MODS); ALL.addAll(BOTS);
        EVERY.addAll(ALL); EVERY.add(THEME); EVERY.add(PARTICLES); EVERY.add(SOUND); EVERY.add(CONFIG); }

    public static int accent() { return THEME.accent(); }
    public static int accent2() { return THEME.accent2(); }
}
