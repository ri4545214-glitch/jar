package com.goku;

import com.goku.modules.*;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final StorageEsp STORAGE = new StorageEsp();
    public static final XRay XRAY = new XRay();
    public static final SpawnerEsp SPAWNER = new SpawnerEsp();
    public static final BaseEsp BASE_FINDER = new BaseEsp();
    public static final EntityEsp ENTITY_FINDER = new EntityEsp();
    public static final ChunkLog CHUNK_LOG = new ChunkLog();
    public static final ParticleModule PARTICLES = new ParticleModule();
    public static final SusChunk SUS = new SusChunk();
    public static final Freecam FREECAM = new Freecam();
    public static final PlayerEsp PLAYER_ESP = new PlayerEsp();
    public static final AutoAim AUTO_AIM = new AutoAim();
    public static final AutoAttack AUTO_ATTACK = new AutoAttack();
    public static final KillAura KILL_AURA = new KillAura();
    public static final AnchorMacro ANCHOR = new AnchorMacro();
    public static final AutoCrystal CRYSTAL = new AutoCrystal();
    public static final AutoTotem TOTEM = new AutoTotem();
    public static final HoverTotem HOVER_TOTEM = new HoverTotem();
    public static final Speed SPEED = new Speed();
    public static final AutoBridge BRIDGE = new AutoBridge();
    public static final BaseAi BASE_AI = new BaseAi();
    public static final CrystalPvp CRYSTAL_PVP = new CrystalPvp();
    public static final AutoClicker AUTO_CLICKER = new AutoClicker();
    public static final AutoWalk AUTO_WALK = new AutoWalk();
    public static final AutoMine AUTO_MINE = new AutoMine();
    public static final AutoFind AUTO_FIND = new AutoFind();
    public static final PlayerHunter HUNTER = new PlayerHunter();
    public static final AirAnchor AIR_ANCHOR = new AirAnchor();
    public static final SafeAnchor SAFE_ANCHOR = new SafeAnchor();
    public static final AutoDTap DTAP = new AutoDTap();
    public static final FeetTrap FEET_TRAP = new FeetTrap();
    public static final AutoTrap AUTO_TRAP = new AutoTrap();
    public static final AutoPot AUTO_POT = new AutoPot();
    public static final BowAim BOW_AIM = new BowAim();
    public static final SkinChanger SKIN = new SkinChanger();
    public static final LegitMode LEGIT = new LegitMode();
    public static final AutoExplore EXPLORE = new AutoExplore();
    public static final WaterClutch CLUTCH = new WaterClutch();
    public static final AutoBuilder BUILDER = new AutoBuilder();
    public static final LowFire LOW_FIRE = new LowFire();
    public static final Performance PERF = new Performance();
    public static final FpsCounter FPS = new FpsCounter();
    public static final Keystrokes KEYSTROKES = new Keystrokes();
    public static final Waypoints WAYPOINTS = new Waypoints();
    public static final Zoom ZOOM = new Zoom();
    public static final Fullbright FULLBRIGHT = new Fullbright();
    /** The practice bot lives in com.goku.bot and is loaded by name so the rest of the mod still builds with -Penable_bot=false. */
    static Module loadBot() {
        try { return (Module) Class.forName("com.goku.bot.BotModule").getDeclaredConstructor().newInstance(); } catch (Throwable t) { return null; }
    }
    public static final Module BOT = loadBot();
    public static final List<Module> BOTS = BOT == null ? List.of() : List.of(BOT);
    public static final ConfigModule CONFIG = new ConfigModule();
    public static final SoundModule SOUND = new SoundModule();
    public static final ThemeModule THEME = new ThemeModule();
    public static final GuiStyle GUI_STYLE = new GuiStyle();
    public static final AutoMace AUTO_MACE = new AutoMace();
    public static final WindLaunch WIND_LAUNCH = new WindLaunch();
    public static final MaceSwap MACE_SWAP = new MaceSwap();
    public static final CartAura CART_AURA = new CartAura();
    public static final CartDefuse CART_DEFUSE = new CartDefuse();
    public static final PotRefill POT_REFILL = new PotRefill();
    public static final PotThrow POT_THROW = new PotThrow();
    public static final PvpCounter PVP_COUNTER = new PvpCounter();
    public static final Navigator NAVIGATOR = new Navigator();
    public static final Sprint SPRINT = new Sprint();
    public static final NoJumpDelay NO_JUMP_DELAY = new NoJumpDelay();
    public static final ScreenMove SCREEN_MOVE = new ScreenMove();
    public static final AutoStairs AUTO_STAIRS = new AutoStairs();
    public static final AntiCobweb ANTI_COBWEB = new AntiCobweb();
    public static final AutoPearl AUTO_PEARL = new AutoPearl();
    public static final WindCharge WIND_CHARGE = new WindCharge();
    public static final AntiBot ANTIBOT = new AntiBot();
    public static final AntiFire ANTI_FIRE = new AntiFire();
    public static final Tracers TRACERS = new Tracers();
    public static final NoScoreboard NO_SCOREBOARD = new NoScoreboard();
    public static final AutoRespawn AUTO_RESPAWN = new AutoRespawn();
    public static final FastPlace FAST_PLACE = new FastPlace();
    public static final AutoTool AUTO_TOOL = new AutoTool();
    public static final ModuleList MODULE_LIST = new ModuleList();
    public static final NameTags NAME_TAGS = new NameTags();
    public static final SilentAura SILENT_AURA = new SilentAura();
    public static final KeepSprint KEEP_SPRINT = new KeepSprint();
    public static final HitSwap HIT_SWAP = new HitSwap();
    public static final Triggerbot TRIGGERBOT = new Triggerbot();
    public static final WTap WTAP = new WTap();
    public static final TargetFilter TARGET_FILTER = new TargetFilter();
    public static final FakeLag FAKE_LAG = new FakeLag();
    public static final BackTrack BACK_TRACK = new BackTrack();
    public static final Friends FRIENDS = new Friends();
    public static final MiddleClickFriend MIDDLE_FRIEND = new MiddleClickFriend();
    public static final Teams TEAMS = new Teams();
    public static final AutoText AUTO_TEXT = new AutoText();
    public static final ChestStealer CHEST_STEALER = new ChestStealer();
    public static final FastExp FAST_EXP = new FastExp();
    public static final Parkour PARKOUR = new Parkour();
    public static final AutoJumpReset JUMP_RESET = new AutoJumpReset();
    public static final AutoShield AUTO_SHIELD = new AutoShield();
    public static final AutoShieldBreaker SHIELD_BREAKER = new AutoShieldBreaker();
    public static final KeyPearl KEY_PEARL = new KeyPearl("Key Pearl", true, 0, 10);
    public static final KeyPearl SHORT_PEARL = new KeyPearl("Short Pearl", false, 25, 11);
    public static final KeyWindCharge KEY_WIND = new KeyWindCharge();
    public static final Trajectories TRAJECTORIES = new Trajectories();
    public static final TargetRenderer TARGET_RENDERER = new TargetRenderer();

    public static final List<Module> BASE = List.of(XRAY, BASE_AI, STORAGE, SPAWNER, BASE_FINDER, ENTITY_FINDER, SUS, CHUNK_LOG, FREECAM);
    public static final List<Module> COMBAT = List.of(PLAYER_ESP, AUTO_AIM, AUTO_ATTACK, KILL_AURA, TOTEM, HOVER_TOTEM, FEET_TRAP, AUTO_TRAP, BOW_AIM, TRACERS, NAME_TAGS, SILENT_AURA, TRIGGERBOT, KEEP_SPRINT, WTAP, HIT_SWAP, TARGET_FILTER, FAKE_LAG, BACK_TRACK, AUTO_SHIELD, SHIELD_BREAKER, TEAMS, FRIENDS, MIDDLE_FRIEND, AUTO_PEARL, ANTIBOT, ANTI_FIRE);
    public static final List<Module> CRYSTAL_SEC = List.of(CRYSTAL_PVP, DTAP, CRYSTAL, ANCHOR, SAFE_ANCHOR, AIR_ANCHOR);
    public static final List<Module> MACE_SEC = List.of(AUTO_MACE, WIND_LAUNCH, MACE_SWAP, WIND_CHARGE, KEY_WIND);
    public static final List<Module> CART_SEC = List.of(CART_AURA, CART_DEFUSE);
    public static final List<Module> POT_SEC = List.of(AUTO_POT, POT_REFILL, POT_THROW, PVP_COUNTER);
    public static final List<Module> MOVEMENT = List.of(SPEED, SPRINT, NO_JUMP_DELAY, SCREEN_MOVE, AUTO_STAIRS, ANTI_COBWEB, PARKOUR, JUMP_RESET, KEY_PEARL, SHORT_PEARL, BRIDGE, CLUTCH);
    public static final List<Module> AUTOMATION = List.of(AUTO_CLICKER, AUTO_WALK, AUTO_MINE, AUTO_FIND, HUNTER, EXPLORE, BUILDER, NAVIGATOR);
    public static final List<Module> MODS = List.of(FPS, KEYSTROKES, WAYPOINTS, ZOOM, FULLBRIGHT, LOW_FIRE, NO_SCOREBOARD, CHEST_STEALER, FAST_EXP, AUTO_TEXT, TRAJECTORIES, TARGET_RENDERER, AUTO_RESPAWN, FAST_PLACE, AUTO_TOOL, MODULE_LIST, PERF, LEGIT, SKIN);
    public static final List<Module> ALL = new ArrayList<>();
    public static final List<Module> EVERY = new ArrayList<>();
    static { ALL.addAll(BASE); ALL.addAll(COMBAT); ALL.addAll(CRYSTAL_SEC); ALL.addAll(MACE_SEC); ALL.addAll(CART_SEC); ALL.addAll(POT_SEC); ALL.addAll(MOVEMENT); ALL.addAll(AUTOMATION); ALL.addAll(MODS); ALL.addAll(BOTS);
        EVERY.addAll(ALL); EVERY.add(THEME); EVERY.add(GUI_STYLE); EVERY.add(PARTICLES); EVERY.add(SOUND); EVERY.add(CONFIG); }

    public static int accent() { return THEME.accent(); }
    public static int accent2() { return THEME.accent2(); }
}
