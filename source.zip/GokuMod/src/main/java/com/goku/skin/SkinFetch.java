package com.goku.skin;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Constructor;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/** Looks a player name up on Mojang's servers and loads that account's skin / cape as local textures (cached). */
public final class SkinFetch {
    public record Loaded(Identifier skin, boolean slim, Identifier cape) {}

    static final HttpClient HTTP = HttpClient.newHttpClient();
    static final Map<String, Loaded> CACHE = new ConcurrentHashMap<>();

    static String get(String url) throws Exception {
        HttpResponse<String> r = HTTP.send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "gokumod").GET().build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() != 200) throw new Exception("HTTP " + r.statusCode() + " for " + url);
        return r.body();
    }

    static byte[] bytes(String url) throws Exception {
        return HTTP.send(HttpRequest.newBuilder(URI.create(url)).header("User-Agent", "gokumod").GET().build(), HttpResponse.BodyHandlers.ofByteArray()).body();
    }

    /** NativeImageBackedTexture's constructor changed between versions, so pick whichever one exists. */
    static NativeImageBackedTexture texture(NativeImage img, String name) throws Exception {
        for (Constructor<?> k : NativeImageBackedTexture.class.getConstructors()) {
            Class<?>[] p = k.getParameterTypes();
            if (p.length == 0 || p[p.length - 1] != NativeImage.class) continue;
            Object[] a = new Object[p.length];
            for (int i = 0; i < p.length - 1; i++) {
                if (p[i] == java.util.function.Supplier.class) a[i] = (java.util.function.Supplier<String>) () -> name;
                else if (p[i] == String.class) a[i] = name;
                else if (p[i] == boolean.class) a[i] = true;
            }
            a[p.length - 1] = img;
            return (NativeImageBackedTexture) k.newInstance(a);
        }
        throw new Exception("no usable texture constructor");
    }

    static Identifier register(byte[] png, String key) throws Exception {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        NativeImageBackedTexture t = texture(img, "gokumod/" + key);
        Identifier id = Identifier.of("gokumod", "textures/dyn/" + key + ".png");
        var mc = MinecraftClient.getInstance();
        mc.execute(() -> mc.getTextureManager().registerTexture(id, t));
        return id;
    }

    public static void load(String name, Consumer<Loaded> ok, Consumer<String> fail) {
        Loaded c = CACHE.get(name.toLowerCase());
        if (c != null) { ok.accept(c); return; }
        Thread th = new Thread(() -> {
            try {
                JsonObject prof = JsonParser.parseString(get("https://api.mojang.com/users/profiles/minecraft/" + name)).getAsJsonObject();
                String id = prof.get("id").getAsString();
                JsonObject sess = JsonParser.parseString(get("https://sessionserver.mojang.com/session/minecraft/profile/" + id)).getAsJsonObject();
                String val = null;
                for (var e : sess.getAsJsonArray("properties")) if (e.getAsJsonObject().get("name").getAsString().equals("textures")) val = e.getAsJsonObject().get("value").getAsString();
                if (val == null) throw new Exception("no textures");
                JsonObject tex = JsonParser.parseString(new String(Base64.getDecoder().decode(val))).getAsJsonObject().getAsJsonObject("textures");
                Identifier skin = null, cape = null;
                boolean slim = false;
                String key = name.toLowerCase().replaceAll("[^a-z0-9_]", "");
                if (tex.has("SKIN")) {
                    JsonObject s = tex.getAsJsonObject("SKIN");
                    slim = s.has("metadata") && s.getAsJsonObject("metadata").has("model") && s.getAsJsonObject("metadata").get("model").getAsString().equals("slim");
                    skin = register(bytes(s.get("url").getAsString()), "skin_" + key);
                }
                if (tex.has("CAPE")) cape = register(bytes(tex.getAsJsonObject("CAPE").get("url").getAsString()), "cape_" + key);
                Loaded l = new Loaded(skin, slim, cape);
                CACHE.put(name.toLowerCase(), l);
                ok.accept(l);
            } catch (Throwable t) { fail.accept(t.getMessage() == null ? t.toString() : t.getMessage()); }
        }, "gokumod-skin");
        th.setDaemon(true);
        th.start();
    }
}
