package com.goku.skin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;

/**
 * Builds a modified copy of the game's skin record for the local player. It works by reflection on the record the game
 * returns, so it adapts to small changes between versions; if it cannot build the copy it returns null (nothing changes).
 */
public final class SkinOverride {
    public static volatile boolean active;
    public static volatile Identifier skin, cape;
    public static volatile boolean slim;
    public static volatile String problem;
    static boolean warned;

    public static Object apply(Object entry, Object original) {
        try {
            if (!active || original == null || (skin == null && cape == null)) return null;
            var mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.getNetworkHandler() == null) return null;
            if (mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) != entry) return null;
            Class<?> c = original.getClass();
            if (!c.isRecord()) { problem = "skin type is not a record"; return null; }
            RecordComponent[] rc = c.getRecordComponents();
            Class<?>[] types = new Class<?>[rc.length];
            Object[] args = new Object[rc.length];
            int tex = 0;
            for (int i = 0; i < rc.length; i++) {
                types[i] = rc[i].getType();
                rc[i].getAccessor().setAccessible(true);
                args[i] = rc[i].getAccessor().invoke(original);
                Class<?> t = types[i];
                boolean texLike = t == Identifier.class || (t.isRecord() && t != String.class);
                if (texLike) {
                    Identifier id = tex == 0 ? skin : cape;      // 0 = body, 1 = cape, 2 = elytra (uses the cape)
                    tex++;
                    if (id == null) continue;                    // keep the original
                    args[i] = t == Identifier.class ? id : wrap(t, id);
                } else if (t.isEnum() && skin != null) {
                    for (Object k : t.getEnumConstants()) {
                        String n = k.toString().toUpperCase();
                        if (slim ? n.contains("SLIM") : n.contains("WIDE") || n.contains("CLASSIC")) { args[i] = k; break; }
                    }
                }
            }
            Constructor<?> ctor = c.getDeclaredConstructor(types);
            ctor.setAccessible(true);
            return ctor.newInstance(args);
        } catch (Throwable t) {
            problem = t.toString();
            return null;
        }
    }

    /** Wrapper records (newer versions) take the texture id(s); we pass our id for every Identifier. */
    static Object wrap(Class<?> t, Identifier id) throws Exception {
        Constructor<?> k = t.getDeclaredConstructors()[0];
        Class<?>[] p = k.getParameterTypes();
        Object[] a = new Object[p.length];
        for (int i = 0; i < p.length; i++) if (p[i] == Identifier.class) a[i] = id;
        k.setAccessible(true);
        return k.newInstance(a);
    }
}
