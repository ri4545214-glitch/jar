package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Vanilla stops your sprint and multiplies your speed by 0.6 each time you hit. This keeps the sprint and applies your own factor instead (1.0 = no slowdown). Does nothing while Legit Mode is on. */
public class KeepSprint extends Module {
    final Setting slow = add(Setting.num("Speed Factor", 0.6, 0.6, 1.0, 0.05));

    public KeepSprint() { super("Keep Sprint"); }

    public void after(PlayerEntity p, Vec3d before, boolean sprinted) {
        if (!enabled || !sprinted || LegitMode.on()) return;
        Vec3d now = p.getVelocity();
        p.setVelocity(before.x * slow.v, now.y, before.z * slow.v);
        p.setSprinting(true);
    }
}
