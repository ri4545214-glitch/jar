package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Big readable name plates over players: name, health, distance, held item + armor. Drawn on the HUD, so they show through walls and in Freecam. */
public class NameTags extends Module {
    final Setting health = add(Setting.bool("Health", true));
    final Setting dist = add(Setting.bool("Distance", true));
    final Setting armor = add(Setting.bool("Armor", true));
    final Setting held = add(Setting.bool("Held Item", true));
    final Setting self = add(Setting.bool("Show Self (Freecam)", true));
    final Setting scale = add(Setting.num("Scale", 1.0, 0.5, 3.0, 0.1));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));

    public NameTags() { super("Name Tags"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        var tr = mc.textRenderer;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p) || p == mc.getCameraEntity()) continue;
            if (p == mc.player && !self.b) continue;
            if (Modules.ANTIBOT.isBot(p)) continue;
            Vec3d lp = p.getLerpedPos(td);
            double d = lp.distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            double[] s = Projector.to(lp.add(0, p.getHeight() + 0.5, 0));
            if (s == null) continue;

            float hp = p.getHealth() + p.getAbsorptionAmount();
            float f = Math.max(0f, Math.min(1f, p.getHealth() / Math.max(1f, p.getMaxHealth())));
            int hc = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8) | 0x20;
            String name = p.getName().getString();
            String hs = health.b ? " " + (int) Math.ceil(hp) : "";
            String ds = dist.b ? " " + (int) d + "m" : "";
            int w = tr.getWidth(name) + tr.getWidth(hs) + tr.getWidth(ds);

            List<ItemStack> items = new ArrayList<>();
            if (held.b && !p.getMainHandStack().isEmpty()) items.add(p.getMainHandStack());
            if (armor.b) for (EquipmentSlot sl : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                ItemStack st = p.getEquippedStack(sl);
                if (!st.isEmpty()) items.add(st);
            }

            float sc = (float) (scale.v * Math.max(0.65, Math.min(1.3, 14.0 / (d + 6.0))));
            var m = c.getMatrices();
            m.pushMatrix();
            m.translate((float) s[0], (float) s[1]);
            m.scale(sc, sc);
            int x = -w / 2;
            c.fill(x - 2, -2, x + w + 2, 10, 0x90000000);
            c.drawText(tr, name, x, 0, p.isSneaking() ? 0xFFFFAA33 : 0xFFFFFFFF, false);
            c.drawText(tr, hs, x + tr.getWidth(name), 0, hc, false);
            c.drawText(tr, ds, x + tr.getWidth(name) + tr.getWidth(hs), 0, 0xFFAAAAAA, false);
            int ix = -(items.size() * 16) / 2;
            for (ItemStack st : items) { c.drawItem(st, ix, -19); ix += 16; }
            m.popMatrix();
        }
    }
}
