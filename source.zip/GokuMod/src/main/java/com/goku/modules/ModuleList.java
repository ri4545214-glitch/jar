package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** On-screen list of enabled modules (top right), with the first mode setting as a grey suffix, e.g. "Auto Mace Density". */
public class ModuleList extends Module {
    final Setting suffix = add(Setting.bool("Show Mode", true));
    final Setting bar = add(Setting.bool("Accent Bar", true));

    public ModuleList() { super("Module List"); }

    String suffixOf(Module m) {
        for (Setting s : m.settings) if (s.type == Setting.Type.MODE) return s.modeName();
        return null;
    }

    @Override public void onRender(DrawContext c, float td) {
        var tr = mc.textRenderer;
        List<Module> on = new ArrayList<>();
        for (Module m : Modules.ALL) if (m.enabled && m.toggleable && m != this) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(m.name + (suffix.b && suffixOf(m) != null ? " " + suffixOf(m) : ""))));
        int W = c.getScaledWindowWidth(), y = 2;
        for (Module m : on) {
            String suf = suffix.b ? suffixOf(m) : null;
            int w = tr.getWidth(m.name) + (suf != null ? tr.getWidth(" " + suf) : 0);
            int x = W - w - 5;
            c.fill(x - 2, y - 1, W - 2, y + 10, 0xA0000000);
            if (bar.b) c.fill(W - 2, y - 1, W, y + 10, 0xFF000000 | Modules.accent());
            c.drawText(tr, m.name, x, y, 0xFFFFFFFF, false);
            if (suf != null) c.drawText(tr, " " + suf, x + tr.getWidth(m.name), y, 0xFFAAAAAA, false);
            y += 11;
        }
    }
}
