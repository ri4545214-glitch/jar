package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Sends a short chat message when you kill a player or when you die. Respect the server's chat rules - keep the cooldown sensible. */
public class AutoText extends Module {
    static final String[] MSGS = {"gg", "GG", "good fight", "gg, well played", "gf"};
    final Setting msg = add(Setting.mode("Message", 0, MSGS));
    final Setting onKill = add(Setting.bool("On Kill", true));
    final Setting onDeath = add(Setting.bool("On Death", false));
    final Setting cooldown = add(Setting.num("Cooldown (s)", 8, 3, 60, 1));
    LivingEntity last;
    long lastHit, lastSent;
    boolean deadSent;

    public AutoText() { super("Auto Text"); }

    public void onAttack(Entity e) { if (e instanceof PlayerEntity p) { last = p; lastHit = System.currentTimeMillis(); } }

    void send() {
        long now = System.currentTimeMillis();
        if (now - lastSent < cooldown.v * 1000) return;
        lastSent = now;
        mc.getNetworkHandler().sendChatMessage(MSGS[msg.idx]);
    }

    @Override public void onTick() {
        if (onDeath.b) {
            boolean dead = mc.currentScreen instanceof DeathScreen;
            if (dead && !deadSent) { send(); deadSent = true; } else if (!dead) deadSent = false;
        }
        if (!onKill.b || last == null) return;
        if (System.currentTimeMillis() - lastHit > 6000) { last = null; return; }
        if (!last.isAlive() || last.getHealth() <= 0f) { send(); last = null; }
    }
}
