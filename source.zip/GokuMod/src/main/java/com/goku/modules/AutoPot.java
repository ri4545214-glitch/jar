package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;

/** Throws splash potions from the hotbar at your feet: healing when low, and keeps Speed / Strength / Fire Resistance up. */
public class AutoPot extends Module {
    final Setting heal = add(Setting.bool("Healing", true));
    final Setting healHp = add(Setting.num("Heal At HP", 10, 2, 19, 1));
    final Setting speed = add(Setting.bool("Speed", false));
    final Setting strength = add(Setting.bool("Strength", false));
    final Setting fireRes = add(Setting.bool("Fire Resistance", false));
    final Setting buffNear = add(Setting.num("Buffs Only If Player Within (0=always)", 0, 0, 40, 2));
    final Setting delay = add(Setting.num("Delay (ticks)", 3, 2, 40, 1));
    final Setting lookDown = add(Setting.bool("Look Down To Throw", true));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;

    public AutoPot() { super("Auto Pot"); }

    static boolean has(ItemStack s, RegistryEntry<StatusEffect> eff) {
        PotionContentsComponent pc = s.get(DataComponentTypes.POTION_CONTENTS);
        if (pc == null) return false;
        for (StatusEffectInstance i : pc.getEffects()) if (i.getEffectType().equals(eff)) return true;
        return false;
    }

    boolean throwPot(RegistryEntry<StatusEffect> eff) {
        int slot = Inv.hotbar(s -> s.isOf(Items.SPLASH_POTION) && has(s, eff));
        if (slot < 0) return false;
        int prev = Inv.selected();
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Inv.select(slot);
        if (lookDown.b) mc.player.setPitch(90f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.setYaw(yaw); mc.player.setPitch(pitch);
        if (swapBack.b) Inv.select(prev);
        cd = LegitMode.delay(delay.i());
        return true;
    }

    boolean buffOk() { return buffNear.v <= 0 || !Targets.find(mc, buffNear.v, true, false, true).isEmpty(); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) { cd--; return; }
        float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (heal.b && hp <= healHp.v && throwPot(StatusEffects.INSTANT_HEALTH)) return;
        if (!buffOk()) return;
        if (speed.b && !mc.player.hasStatusEffect(StatusEffects.SPEED) && throwPot(StatusEffects.SPEED)) return;
        if (strength.b && !mc.player.hasStatusEffect(StatusEffects.STRENGTH) && throwPot(StatusEffects.STRENGTH)) return;
        if (fireRes.b && !mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) throwPot(StatusEffects.FIRE_RESISTANCE);
    }
}
