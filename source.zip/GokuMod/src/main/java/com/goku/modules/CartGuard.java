package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.Vec3d;

/** Cart Guard: when a lit TNT minecart is close to you (yours or theirs) it turns away and runs out of the blast; optionally jumps to clear carts rolling at you. */
public class CartGuard extends Module {
    final Setting danger = add(Setting.num("Danger Radius", 7, 4, 14, 1));
    final Setting hold = add(Setting.num("Keep Running (ticks)", 12, 4, 40, 2));
    final Setting jump = add(Setting.bool("Jump While Running", false));
    final Setting totemWarn = add(Setting.bool("Need Totem In Offhand To Stay Calm", false));

    int run;
    Vec3d from = Vec3d.ZERO;
    boolean keys;

    public CartGuard() { super("Cart Guard"); }

    @Override public void onDisable() { stop(); }

    void stop() {
        if (keys) {
            if (!Modules.AUTO_WALK.enabled) { mc.options.forwardKey.setPressed(false); mc.options.sprintKey.setPressed(false); }
            mc.options.jumpKey.setPressed(false);
            keys = false;
        }
        run = 0;
    }

    @Override public void onPreTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        Entity near = null; double best = danger.v;
        for (Entity e : mc.world.getEntities())
            if (e instanceof TntMinecartEntity m && m.isPrimed()) {
                double d = m.distanceTo(mc.player);
                if (d < best) { best = d; near = m; }
            }
        if (near != null && totemWarn.b && mc.player.getOffHandStack().isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING)) near = null;
        if (near != null) { run = hold.i(); from = near.getEntityPos(); }
        if (run > 0) {
            float[] r = Targets.rot(from, mc.player.getEntityPos());
            Rot.faceAngles(r[0], mc.player.getPitch());
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
            if (jump.b) mc.options.jumpKey.setPressed(mc.player.isOnGround());
            keys = true;
            run--;
        } else if (keys) stop();
    }
}
