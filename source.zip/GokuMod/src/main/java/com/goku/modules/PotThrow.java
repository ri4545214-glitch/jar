package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Nethpot: throws harming / slowness / weakness / poison splash potions at the enemy, aimed with a trajectory solver that leads a moving target. */
public class PotThrow extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting harming = add(Setting.bool("Harming", true));
    final Setting slowness = add(Setting.bool("Slowness", true));
    final Setting weakness = add(Setting.bool("Weakness", false));
    final Setting poison = add(Setting.bool("Poison", false));
    final Setting minRange = add(Setting.num("Min Distance", 4.5, 3, 8, 0.5));
    final Setting maxRange = add(Setting.num("Max Distance", 12, 5, 20, 1));
    final Setting lead = add(Setting.num("Lead (ticks)", 4, 0, 12, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 4, 4, 60, 1));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;
    LivingEntity lastT;
    Vec3d lastPos = Vec3d.ZERO, vel = Vec3d.ZERO;

    public PotThrow() { super("Pot Throw"); }

    /** Returns {yaw, pitch} that lands a thrown splash potion at 'to', or null. Vanilla: speed 0.5, drag 0.99, gravity 0.05, throw angle offset -20 degrees. */
    float[] solve(Vec3d from, Vec3d to) {
        float yaw = (float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0);
        double yr = Math.toRadians(yaw), best = 1e9; float bestP = Float.NaN;
        Vec3d sv = mc.player.getVelocity();
        boolean ground = mc.player.isOnGround();
        for (float p = -89; p <= 89; p += 0.5f) {
            double pr = Math.toRadians(p - 20f);
            double vx = -Math.sin(yr) * Math.cos(pr) * 0.5 + sv.x, vy = -Math.sin(pr) * 0.5 + (ground ? 0 : sv.y), vz = Math.cos(yr) * Math.cos(pr) * 0.5 + sv.z;
            double x = from.x, y = from.y, z = from.z;
            for (int t = 0; t < 100; t++) {
                x += vx; y += vy; z += vz;
                vx *= 0.99; vy = vy * 0.99 - 0.05; vz *= 0.99;
                if (y <= to.y && vy < 0) {
                    double err = Math.hypot(x - to.x, z - to.z);
                    if (err < best) { best = err; bestP = p; }
                    break;
                }
            }
        }
        return best < 1.6 ? new float[]{yaw, bestP} : null;
    }

    boolean has(RegistryEntry<StatusEffect> e) { return Inv.hotbar(s -> s.isOf(Items.SPLASH_POTION) && AutoPot.has(s, e)) >= 0; }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        List<LivingEntity> ts = Targets.find(mc, LegitMode.reach(maxRange.v), players.b, mobs.b, LegitMode.walls(walls.b));
        LivingEntity t = null;
        for (LivingEntity e : ts) if (mc.player.distanceTo(e) >= minRange.v) { t = e; break; }
        // movement of the target, from tick to tick
        if (t != null) {
            Vec3d p = t.getEntityPos();
            vel = t == lastT ? p.subtract(lastPos) : Vec3d.ZERO;
            lastT = t; lastPos = p;
        } else lastT = null;
        if (cd > 0) { cd--; return; }
        if (t == null) return;

        RegistryEntry<StatusEffect> eff = null;
        if (harming.b && has(StatusEffects.INSTANT_DAMAGE)) eff = StatusEffects.INSTANT_DAMAGE;
        else if (slowness.b && !t.hasStatusEffect(StatusEffects.SLOWNESS) && has(StatusEffects.SLOWNESS)) eff = StatusEffects.SLOWNESS;
        else if (weakness.b && !t.hasStatusEffect(StatusEffects.WEAKNESS) && has(StatusEffects.WEAKNESS)) eff = StatusEffects.WEAKNESS;
        else if (poison.b && !t.hasStatusEffect(StatusEffects.POISON) && has(StatusEffects.POISON)) eff = StatusEffects.POISON;
        if (eff == null) return;

        Vec3d aim = t.getEntityPos().add(vel.multiply(lead.v)).add(0, 0.1, 0);
        float[] r = solve(mc.player.getEyePos().add(0, -0.1, 0), aim);
        if (r == null) return;
        final RegistryEntry<StatusEffect> fe = eff;
        int slot = Inv.hotbar(s -> s.isOf(Items.SPLASH_POTION) && AutoPot.has(s, fe));
        if (slot < 0) return;
        int prev = Inv.selected();
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Inv.select(slot);
        mc.player.setYaw(r[0]); mc.player.setPitch(r[1]);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.setYaw(yaw); mc.player.setPitch(pitch);
        if (swapBack.b) Inv.select(prev);
        cd = LegitMode.delay(delay.i());
    }
}
