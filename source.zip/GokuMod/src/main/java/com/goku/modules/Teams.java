package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.player.PlayerEntity;

/** Treats your teammates as non-targets. */
public class Teams extends Module {
    final Setting scoreboard = add(Setting.bool("Scoreboard Team", true));
    final Setting nameColor = add(Setting.bool("Name Color", true));

    public Teams() { super("Teams"); }

    public boolean same(PlayerEntity e) {
        if (!enabled || e == mc.player) return false;
        if (scoreboard.b && e.isTeammate(mc.player)) return true;
        if (nameColor.b) {
            var a = e.getDisplayName().getStyle().getColor();
            var b = mc.player.getDisplayName().getStyle().getColor();
            return a != null && a.equals(b);
        }
        return false;
    }
}
