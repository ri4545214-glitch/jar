package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.ElyUtil;
import com.goku.util.Inv;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Elytra Boost: while you glide it keeps your speed up with fireworks (and optionally only while you hold forward). Works with any elytra flight, no target needed. */
public class ElytraBoost extends Module {
    final Setting minSpeed = add(Setting.num("Boost Below Speed", 1.0, 0.4, 2.5, 0.1));
    final Setting onlyForward = add(Setting.bool("Only While Holding Forward", true));
    final Setting interval = add(Setting.num("Min Delay (ticks)", 25, 8, 80, 1));
    final Setting needHeight = add(Setting.num("Min Height Above Ground", 3, 0, 30, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;

    public ElytraBoost() { super("Elytra Boost"); }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        if (mc.currentScreen != null || !ElyUtil.gliding()) return;
        if (onlyForward.b && !mc.options.forwardKey.isPressed()) return;
        if (mc.player.getVelocity().length() >= minSpeed.v || ElyUtil.heightAbove() < needHeight.v) return;
        int fw = Inv.hotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
        if (fw < 0) return;
        int prev = Inv.selected();
        Inv.select(fw);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (swapBack.b) Inv.select(prev);
        cd = LegitMode.delay(interval.i());
    }
}
