package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Gear;
import com.goku.util.Inv;
import com.goku.util.Use;
import net.minecraft.item.Items;

/** While gliding, keeps your speed up with fireworks and/or wind charges. Other modules (Auto Elytra, Auto Launch) call boostNow() too. */
public class ElytraBoost extends Module {
    final Setting mode = add(Setting.mode("Boost With", 2, "Firework", "Wind Charge", "Both"));
    final Setting minSpeed = add(Setting.num("Boost Below Speed", 1.0, 0.3, 2.5, 0.1));
    final Setting windDir = add(Setting.mode("Wind Charge Aim", 0, "Auto", "Down", "Behind"));
    final Setting autoBoost = add(Setting.bool("Auto Boost", true));
    int cd;

    public ElytraBoost() { super("Elytra Boost"); }

    /** Uses one firework or wind charge now (respecting the mode). Returns true if something was used. */
    public boolean boostNow() {
        if (cd > 0) return false;
        var p = mc.player;
        if (mode.idx != 1) {
            int fw = Inv.hotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0 && Use.item(fw, p.getYaw(), p.getPitch(), true)) { cd = 8; return true; }
        }
        if (mode.idx != 0) {
            int wc = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
            if (wc >= 0) {
                boolean down = windDir.idx == 1 || (windDir.idx == 0 && Gear.height(14) < 12);
                float yaw = down ? p.getYaw() : p.getYaw() + 180f, pitch = down ? 90f : 25f;
                if (Use.item(wc, yaw, pitch, true)) { cd = 10; return true; }
            }
        }
        return false;
    }

    @Override public void onTick() {
        if (cd > 0) cd--;
        if (!autoBoost.b || mc.currentScreen != null || !mc.player.isGliding()) return;
        if (mc.player.getVelocity().length() < minSpeed.v) boostNow();
    }
}
