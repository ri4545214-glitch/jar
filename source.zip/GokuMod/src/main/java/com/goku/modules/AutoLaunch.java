package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Gear;
import com.goku.util.Inv;
import com.goku.util.Trig;
import com.goku.util.Use;
import net.minecraft.item.Items;

/** One button launch: wind charge blast up, optional ender pearl, then elytra out and boost (fireworks / wind charges). */
public class AutoLaunch extends Module {
    final Setting trigger = add(Setting.mode("Trigger", 0, Trig.NAMES));
    final Setting wind = add(Setting.bool("Wind Charge Up", true));
    final Setting pearl = add(Setting.bool("Then Ender Pearl", false));
    final Setting pearlPitch = add(Setting.num("Pearl Angle (up)", 35, 0, 80, 5));
    final Setting pearlDelay = add(Setting.num("Pearl After (ticks)", 8, 1, 30, 1));
    final Setting elytra = add(Setting.bool("Then Elytra", true));
    final Setting elytraDelay = add(Setting.num("Elytra After (ticks)", 5, 2, 30, 1));
    final Setting boost = add(Setting.bool("Boost After", true));
    boolean active;
    int t;

    public AutoLaunch() { super("Auto Launch"); }

    @Override public void onDisable() { active = false; }

    @Override public void onPreTick() {
        var p = mc.player;
        if (!active) {
            if (mc.currentScreen != null || !Trig.pressed(trigger.idx, 13)) return;
            boolean started = false;
            if (wind.b && p.isOnGround()) {
                int w = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
                if (w >= 0) started = Use.item(w, p.getYaw(), 90f, true);
            }
            if (!started && !p.isOnGround()) started = true;   // already in the air: just run the follow-ups
            if (started) { active = true; t = 0; }
            return;
        }
        t++;
        if (pearl.b && t == pearlDelay.i()) {
            int s = Inv.hotbar(i -> i.isOf(Items.ENDER_PEARL));
            if (s >= 0) Use.item(s, p.getYaw(), -(float) pearlAngle(), true);
        }
        if (elytra.b && t == elytraDelay.i()) Gear.equipChest(Gear.ELYTRA);
        if (elytra.b && t > elytraDelay.i() + 1 && !p.isGliding() && !p.isOnGround()) Gear.startGlide();
        if (boost.b && p.isGliding()) Modules.ELYTRA_BOOST.boostNow();
        if ((p.isOnGround() && t > 12) || t > 240) active = false;
    }

    double pearlAngle() { return pearlPitch.v; }
}
