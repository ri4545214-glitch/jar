package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import org.lwjgl.glfw.GLFW;

/** Hold (or toggle) a key to zoom by lowering the FOV option, restored afterwards. Vanilla FOV minimum is 30. */
public class Zoom extends Module {
    static final String[] KEYS = {"C", "Z", "V", "X", "B", "G", "Left Alt"};
    static final int[] CODES = {GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_LEFT_ALT};

    final Setting key = add(Setting.mode("Key", 0, KEYS));
    final Setting mode = add(Setting.mode("Mode", 0, "Hold", "Toggle"));
    final Setting zoomFov = add(Setting.num("Zoom FOV", 30, 30, 70, 1));
    final Setting smooth = add(Setting.bool("Smooth", true));
    final Setting sens = add(Setting.bool("Lower Sensitivity", true));

    private int origFov = -1;
    private double origSens, cur;
    private boolean toggled, wasDown;

    public Zoom() { super("Zoom"); }

    @Override public void onTick() {
        boolean down = mc.currentScreen == null && GLFW.glfwGetKey(mc.getWindow().getHandle(), CODES[key.idx]) == GLFW.GLFW_PRESS;
        boolean active;
        if (mode.idx == 0) active = down;
        else { if (down && !wasDown) toggled = !toggled; active = toggled; }
        wasDown = down;
        if (active && origFov < 0) {
            origFov = mc.options.getFov().getValue();
            origSens = mc.options.getMouseSensitivity().getValue();
            cur = origFov;
        }
        if (origFov < 0) return;
        double target = active ? Math.min(zoomFov.v, origFov) : origFov;
        cur += (target - cur) * (smooth.b ? 0.35 : 1.0);
        if (Math.abs(target - cur) < 0.5) cur = target;
        mc.options.getFov().setValue((int) Math.round(cur));
        if (sens.b) mc.options.getMouseSensitivity().setValue(Math.max(0.0, Math.min(1.0, origSens * (cur / origFov))));
        if (!active && cur == origFov) restore();
    }

    /** Puts FOV and sensitivity back. Also called when leaving a world. */
    public void restore() {
        if (origFov < 0) return;
        mc.options.getFov().setValue(origFov);
        mc.options.getMouseSensitivity().setValue(origSens);
        origFov = -1;
        toggled = false;
    }

    @Override public void onDisable() { restore(); }
}
