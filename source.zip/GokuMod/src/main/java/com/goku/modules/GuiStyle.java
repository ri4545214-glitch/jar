package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;

/**
 * GUI layout / look. Pick a preset or tune every value yourself; touching a value switches the preset to "Custom".
 * Read by gui.ClickGui and gui.ManagerGui.
 */
public class GuiStyle extends Module {
    static final String[] PRESETS = {"Custom", "Default", "Compact", "Minimal", "Glass", "Neon", "Big", "Anime"};
    //                                     style opac  w    h   anchor dim  particles slim frame shadow
    static final double[][] VALUES = {
            {},
            {0, 97, 620, 372, 0, 66, 1, 0, 1, 1},
            {0, 97, 480, 300, 0, 50, 0, 1, 1, 1},
            {1, 100, 520, 330, 0, 30, 0, 0, 1, 0},
            {2, 78, 620, 372, 0, 45, 1, 0, 1, 1},
            {3, 94, 620, 372, 0, 70, 1, 0, 2, 1},
            {0, 97, 760, 440, 0, 66, 1, 0, 1, 1},
            {4, 92, 640, 380, 0, 55, 1, 0, 2, 1}
    };

    public final Setting preset = add(Setting.mode("Layout Preset", 1, PRESETS));
    public final Setting style = add(Setting.mode("Window Style", 0, "Modern", "Flat", "Glass", "Neon", "Anime"));
    public final Setting opacity = add(Setting.num("Window Opacity", 97, 40, 100, 1));
    public final Setting width = add(Setting.num("Window Width", 620, 400, 820, 10));
    public final Setting height = add(Setting.num("Window Height", 372, 260, 500, 10));
    public final Setting anchor = add(Setting.mode("Position", 0, "Center", "Left", "Right"));
    public final Setting dim = add(Setting.num("Background Dim", 66, 0, 100, 2));
    public final Setting particles = add(Setting.bool("Background Particles", true));
    public final Setting slim = add(Setting.bool("Slim Sidebar (icons)", false));
    public final Setting frame = add(Setting.num("Accent Frame", 1, 0, 3, 1));
    public final Setting shadow = add(Setting.bool("Shadow", true));
    public final Setting anims = add(Setting.bool("Open Animation", true));
    public final Setting panels = add(Setting.bool("Panel Layout", true));

    private int last = -1;
    private double sig;

    public GuiStyle() { super("GUI Style"); toggleable = false; open = true; }

    private Setting[] all() { return new Setting[]{style, opacity, width, height, anchor, dim, particles, slim, frame, shadow}; }

    private double signature() {
        double s = 0;
        for (Setting x : all()) s = s * 31 + (x.type == Setting.Type.BOOL ? (x.b ? 1 : 0) : x.type == Setting.Type.MODE ? x.idx : x.v);
        return s;
    }

    /** Applies a chosen preset, and falls back to "Custom" when a value is changed by hand. Call every frame. */
    public void sync() {
        if (last < 0) { last = preset.idx; sig = signature(); return; }
        if (preset.idx != last) {
            last = preset.idx;
            if (last > 0 && last < VALUES.length) {
                double[] v = VALUES[last];
                style.idx = (int) v[0]; opacity.v = v[1]; width.v = v[2]; height.v = v[3]; anchor.idx = (int) v[4];
                dim.v = v[5]; particles.b = v[6] > 0; slim.b = v[7] > 0; frame.v = v[8]; shadow.b = v[9] > 0;
            }
            if (last == 7) Modules.THEME.preset.idx = 8;   // Anime layout also picks the Sakura colours
            sig = signature();
        } else if (last > 0 && signature() != sig) { preset.idx = 0; last = 0; }
    }
}
