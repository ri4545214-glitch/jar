package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.Random;

/** Attacks the moment your crosshair is on a valid target (no rotation, no packets of its own), with a random reaction delay. */
public class Triggerbot extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting minDelay = add(Setting.num("Min Delay (ms)", 0, 0, 500, 10));
    final Setting maxDelay = add(Setting.num("Max Delay (ms)", 30, 0, 500, 10));
    final Setting cooldown = add(Setting.num("Min Cooldown %", 90, 10, 100, 5));
    final Setting weaponOnly = add(Setting.bool("Weapon Only", true));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Random rnd = new Random();
    long nextAt;

    public Triggerbot() { super("Triggerbot"); }

    boolean weapon(ItemStack s) { return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || mc.targetedEntity == null) { nextAt = 0; return; }
        if (!Targets.valid(mc, mc.targetedEntity, LegitMode.reach(3.0), players.b, mobs.b, LegitMode.walls(walls.b))) { nextAt = 0; return; }
        if (weaponOnly.b && !weapon(mc.player.getMainHandStack())) return;
        long now = System.currentTimeMillis();
        if (nextAt == 0) {
            double lo = Math.min(minDelay.v, maxDelay.v), hi = Math.max(minDelay.v, maxDelay.v);
            nextAt = now + (long) (lo + rnd.nextDouble() * (hi - lo));
        }
        if (now < nextAt || mc.player.getAttackCooldownProgress(0.5f) < cooldown.v / 100.0) return;
        mc.interactionManager.attackEntity(mc.player, mc.targetedEntity);
        mc.player.swingHand(Hand.MAIN_HAND);
        nextAt = 0;
    }
}
