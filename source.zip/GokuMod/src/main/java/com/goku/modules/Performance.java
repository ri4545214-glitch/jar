package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.option.ParticlesMode;

/** Lowers vanilla video options for smoother play on weak PCs. Originals are restored when turned off. */
public class Performance extends Module {
    final Setting view = add(Setting.num("Max Render Distance", 8, 2, 32, 1));
    final Setting sim = add(Setting.num("Max Simulation Distance", 6, 5, 32, 1));
    final Setting entDist = add(Setting.num("Entity Distance", 0.75, 0.5, 5, 0.25));
    final Setting blend = add(Setting.num("Biome Blend", 0, 0, 7, 1));
    final Setting shadows = add(Setting.bool("Disable Entity Shadows", true));
    final Setting particles = add(Setting.bool("Minimal Particles", true));
    final Setting fpsCap = add(Setting.num("Max FPS (260=unlimited)", 260, 30, 260, 10));

    private boolean saved;
    private int oView, oSim, oBlend, oFps;
    private double oEnt;
    private boolean oShadows;
    private ParticlesMode oParticles;

    public Performance() { super("Performance"); }

    private void save() {
        if (saved) return;
        var o = mc.options;
        oView = o.getViewDistance().getValue(); oSim = o.getSimulationDistance().getValue();
        oBlend = o.getBiomeBlendRadius().getValue(); oFps = o.getMaxFps().getValue();
        oEnt = o.getEntityDistanceScaling().getValue(); oShadows = o.getEntityShadows().getValue();
        oParticles = o.getParticles().getValue();
        saved = true;
    }

    @Override public void onEnable() { save(); }

    @Override public void onTick() {
        if (!saved) save();
        if (mc.player.age % 20 != 0) return;
        var o = mc.options;
        if (oView > view.i()) o.getViewDistance().setValue(view.i());
        if (oSim > sim.i()) o.getSimulationDistance().setValue(sim.i());
        o.getEntityDistanceScaling().setValue(Math.min(oEnt, entDist.v));
        o.getBiomeBlendRadius().setValue(Math.min(oBlend, blend.i()));
        if (shadows.b) o.getEntityShadows().setValue(false);
        if (particles.b) o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getMaxFps().setValue(Math.min(oFps, fpsCap.i()));
    }

    @Override public void onDisable() {
        if (!saved) return;
        var o = mc.options;
        o.getViewDistance().setValue(oView); o.getSimulationDistance().setValue(oSim);
        o.getBiomeBlendRadius().setValue(oBlend); o.getMaxFps().setValue(oFps);
        o.getEntityDistanceScaling().setValue(oEnt); o.getEntityShadows().setValue(oShadows);
        o.getParticles().setValue(oParticles);
        saved = false;
    }
}
