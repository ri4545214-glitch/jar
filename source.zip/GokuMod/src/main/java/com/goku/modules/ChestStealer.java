package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** While a chest / barrel / shulker is open, shift-clicks its items into your inventory one at a time. */
public class ChestStealer extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 0, 0, 10, 1));
    final Setting valuable = add(Setting.bool("Only Valuables", false));
    final Setting close = add(Setting.bool("Close When Empty", true));
    int wait;

    public ChestStealer() { super("Chest Stealer"); }

    static boolean worth(ItemStack s) {
        if (!s.getEnchantments().isEmpty()) return true;
        String p = Registries.ITEM.getId(s.getItem()).getPath();
        for (String k : new String[]{"diamond", "netherite", "totem", "golden_apple", "elytra", "end_crystal", "shulker", "ender_pearl", "mace", "wind_charge", "experience_bottle", "emerald", "gold_ingot"})
            if (p.contains(k)) return true;
        return false;
    }

    @Override public void onTick() {
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) { wait = 0; return; }
        if (wait-- > 0) return;
        var h = gs.getScreenHandler();
        int n = h.getRows() * 9;
        for (int i = 0; i < n; i++) {
            ItemStack st = h.slots.get(i).getStack();
            if (st.isEmpty() || (valuable.b && !worth(st))) continue;
            mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
            wait = LegitMode.delay(delay.i());
            return;
        }
        if (close.b) mc.player.closeHandledScreen();
    }
}
