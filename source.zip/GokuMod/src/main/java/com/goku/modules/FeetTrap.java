package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Place;
import net.minecraft.util.math.BlockPos;

/** Surrounds your own feet with obsidian. */
public class FeetTrap extends Module {
    final Setting obsOnly = add(Setting.bool("Obsidian Only", true));
    final Setting perTick = add(Setting.num("Blocks Per Tick", 2, 1, 4, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));
    final Setting base = add(Setting.bool("Floor Block", false));
    final Setting head = add(Setting.bool("Head Level Sides", false));
    final Setting top = add(Setting.bool("Cap Above Head", false));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting offMove = add(Setting.bool("Disable If You Move", true));
    final Setting offDone = add(Setting.bool("Disable When Done", false));
    BlockPos start;
    int cd;

    public FeetTrap() { super("Feet Trap"); }

    @Override public void onEnable() { start = mc.player == null ? null : mc.player.getBlockPos(); cd = 0; }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        BlockPos feet = mc.player.getBlockPos();
        if (offMove.b && start != null && !feet.equals(start)) { Place.msg("Feet Trap off (moved)"); setEnabled(false); return; }
        if (cd > 0) { cd--; return; }
        var shell = Place.shell(feet, base.b, head.b, top.b);
        boolean done = true;
        for (BlockPos p : shell) if (mc.world.getBlockState(p).isReplaceable()) { done = false; break; }
        if (done) { if (offDone.b) { Place.msg("Feet Trap done"); setEnabled(false); } return; }
        int slot = Place.blockSlot(obsOnly.b);
        if (slot < 0) return;
        int prev = Inv.selected(), n = 0;
        Inv.select(slot);
        for (BlockPos p : shell) {
            if (n >= com.goku.modules.LegitMode.perTick(perTick.i())) break;
            if (Place.place(p, 4.5)) n++;
        }
        if (swapBack.b) Inv.select(prev);
        if (n > 0) cd = LegitMode.delay(delay.i());
    }
}
