package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/**
 * X-Ray: highlights ores through walls. Only the ores are drawn (boxes projected onto the HUD, like the ESPs),
 * the world itself is not changed. Every ore type can be toggled and the scan/draw is fully configurable.
 */
public class XRay extends Module {
    static final String[] NAMES = {"Coal", "Iron", "Copper", "Gold", "Redstone", "Lapis", "Diamond", "Emerald", "Nether Quartz", "Nether Gold", "Ancient Debris"};
    static final int[] COLORS = {0xFF555555, 0xFFD8AF93, 0xFFE07B39, 0xFFFFDD33, 0xFFFF2222, 0xFF3355FF, 0xFF33EEFF, 0xFF33FF66, 0xFFEEEEEE, 0xFFFFAA22, 0xFF8B4A3A};
    static final boolean[] DEFAULT_ON = {false, true, false, true, false, false, true, true, false, false, true};
    static final Block[][] BLOCKS = {
            {Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE},
            {Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE},
            {Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE},
            {Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE},
            {Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE},
            {Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE},
            {Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE},
            {Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE},
            {Blocks.NETHER_QUARTZ_ORE},
            {Blocks.NETHER_GOLD_ORE},
            {Blocks.ANCIENT_DEBRIS}
    };

    record Ore(BlockPos pos, int type, double dist) {}

    final Setting[] ores = new Setting[NAMES.length];
    final Setting range = add(Setting.num("Range", 32, 8, 96, 4));
    final Setting scanRate = add(Setting.num("Scan Every (ticks)", 20, 5, 100, 5));
    final Setting maxOres = add(Setting.num("Max Ores Drawn", 200, 20, 1000, 20));
    final Setting hideExposed = add(Setting.bool("Hide Exposed Ores", false));
    final Setting minY = add(Setting.num("Min Y", -64, -64, 320, 8));
    final Setting maxY = add(Setting.num("Max Y", 320, -64, 320, 8));
    final Setting style = add(Setting.mode("Box Style", 0, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting colorMode = add(Setting.mode("Colors", 0, "Per Ore", "Single"));
    final Setting singleColor = add(Setting.color("Single Color", 0x44FFFF));
    final Setting fade = add(Setting.bool("Distance Fade", true));
    final Setting width = add(Setting.num("Line Width", 1, 1, 4, 1));
    final Setting labels = add(Setting.bool("Labels", false));
    final Setting tracers = add(Setting.bool("Tracers", false));
    final Setting origin = add(Setting.mode("Tracer From", 0, Esp.ORIGINS));
    final Setting summary = add(Setting.bool("Summary HUD", true));

    private final Map<Block, Integer> lookup = new HashMap<>();
    private List<Ore> found = List.of();
    private int[] counts = new int[NAMES.length];

    public XRay() {
        super("X-Ray");
        // ore toggles go first in the GUI
        List<Setting> rest = new ArrayList<>(settings);
        settings.clear();
        for (int i = 0; i < NAMES.length; i++) {
            ores[i] = Setting.bool(NAMES[i], DEFAULT_ON[i]);
            settings.add(ores[i]);
            for (Block b : BLOCKS[i]) lookup.put(b, i);
        }
        settings.addAll(rest);
    }

    private boolean wanted(net.minecraft.block.BlockState st) {
        Integer i = lookup.get(st.getBlock());
        return i != null && ores[i].b;
    }

    @Override public void onTick() {
        if (mc.world == null || mc.player == null || mc.player.age % scanRate.i() != 0) return;
        Entity cam = mc.getCameraEntity();
        if (cam == null) return;
        Vec3d c = cam.getEntityPos();
        double r = range.v, r2 = r * r;
        int lo = minY.i(), hi = Math.max(lo, maxY.i());
        int minCx = (int) Math.floor((c.x - r) / 16), maxCx = (int) Math.floor((c.x + r) / 16);
        int minCz = (int) Math.floor((c.z - r) / 16), maxCz = (int) Math.floor((c.z + r) / 16);
        List<Ore> out = new ArrayList<>();
        BlockPos.Mutable mp = new BlockPos.Mutable();
        for (int cx = minCx; cx <= maxCx; cx++) for (int cz = minCz; cz <= maxCz; cz++) {
            WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
            if (ch == null) continue;
            ChunkSection[] secs = ch.getSectionArray();
            for (int i = 0; i < secs.length; i++) {
                ChunkSection s = secs[i];
                if (s == null || s.isEmpty()) continue;
                int baseY = (ch.getBottomSectionCoord() + i) * 16;
                if (baseY + 15 < lo || baseY > hi || baseY + 16 < c.y - r || baseY > c.y + r) continue;
                boolean[] any = {false};
                s.getBlockStateContainer().count((st, n) -> { if (n > 0 && wanted(st)) any[0] = true; });
                if (!any[0]) continue;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    var st = s.getBlockState(x, y, z);
                    Integer type = lookup.get(st.getBlock());
                    if (type == null || !ores[type].b) continue;
                    int wx = cx * 16 + x, wy = baseY + y, wz = cz * 16 + z;
                    if (wy < lo || wy > hi) continue;
                    double dx = wx + 0.5 - c.x, dy = wy + 0.5 - c.y, dz = wz + 0.5 - c.z;
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) continue;
                    if (hideExposed.b && exposed(mp.set(wx, wy, wz))) continue;
                    out.add(new Ore(new BlockPos(wx, wy, wz), type, Math.sqrt(d2)));
                }
            }
        }
        out.sort(Comparator.comparingDouble(Ore::dist));
        int[] cnt = new int[NAMES.length];
        for (Ore o : out) cnt[o.type()]++;
        found = out.size() > maxOres.i() ? new ArrayList<>(out.subList(0, maxOres.i())) : out;
        counts = cnt;
    }

    private boolean exposed(BlockPos.Mutable p) {
        int x = p.getX(), y = p.getY(), z = p.getZ();
        for (Direction d : Direction.values()) {
            BlockPos n = new BlockPos(x + d.getOffsetX(), y + d.getOffsetY(), z + d.getOffsetZ());
            if (mc.world.getBlockState(n).isAir()) return true;
        }
        return false;
    }

    private int color(Ore o) {
        return colorMode.idx == 0 ? COLORS[o.type()] : singleColor.argb();
    }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        if (summary.b) {
            StringBuilder sb = new StringBuilder("X-Ray: ");
            int shown = 0;
            for (int i = 0; i < NAMES.length; i++) if (counts[i] > 0) { if (shown++ > 0) sb.append("  "); sb.append(counts[i]).append(' ').append(NAMES[i]); }
            if (shown > 0) Esp.hud(c, sb.toString(), Modules.accent());
        }
        for (Ore o : found) {
            BlockPos p = o.pos();
            Box box = new Box(p.getX() + 0.02, p.getY() + 0.02, p.getZ() + 0.02, p.getX() + 0.98, p.getY() + 0.98, p.getZ() + 0.98);
            int col = fade.b ? Esp.fade(color(o), o.dist(), range.v) : color(o);
            Esp.box(c, box, col, style.idx, fill.b, width.i());
            if (tracers.b) Esp.tracer(c, box.getCenter(), col, origin.idx, width.i());
            if (labels.b) {
                double[] sp = Projector.to(new Vec3d(p.getX() + 0.5, p.getY() + 1.2, p.getZ() + 0.5));
                if (sp != null) Esp.label(c, NAMES[o.type()] + " " + (int) o.dist() + "m", (int) sp[0], (int) sp[1] - 11, col);
            }
        }
    }

    @Override public void onDisable() { found = List.of(); counts = new int[NAMES.length]; }
}
