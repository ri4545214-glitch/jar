package com.goku.modules;

import com.goku.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;

/** Removes an end crystal on your screen the moment you hit it (instead of waiting for the server), so the next one can be placed right away. */
public class CrystalOptimizer extends Module {
    int pending = -1;

    public CrystalOptimizer() { super("Crystal Optimizer"); }

    public void onAttack(Entity e) { if (e instanceof EndCrystalEntity) pending = e.getId(); }

    @Override public void onPreTick() {
        if (pending < 0) return;
        Entity e = mc.world.getEntityById(pending);
        pending = -1;
        if (e instanceof EndCrystalEntity) mc.world.removeEntity(e.getId(), Entity.RemovalReason.KILLED);
    }
}
