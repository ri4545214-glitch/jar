package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Hold right click with XP bottles in hand to throw them quickly. */
public class FastExp extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 2, 1, 4, 1));
    int t;

    public FastExp() { super("Fast Exp"); }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || !mc.player.getMainHandStack().isOf(Items.EXPERIENCE_BOTTLE) || !mc.options.useKey.isPressed()) { t = 0; return; }
        if (++t >= LegitMode.delay(delay.i())) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.swingHand(Hand.MAIN_HAND);
            t = 0;
        }
    }
}
