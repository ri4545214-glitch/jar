package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.List;

/**
 * Mace Chain: right after a mace smash lands it throws a wind charge at your feet, bounces you back up and the next fall smashes again.
 * Repeats until the target is dead or you run out of wind charges.
 */
public class MaceChain extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting within = add(Setting.num("Target Within", 8, 3, 16, 1));
    final Setting maxChain = add(Setting.num("Max Bounces", 6, 1, 20, 1));
    final Setting window = add(Setting.num("Bounce Window (ticks)", 6, 2, 20, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 3, 0, 10, 1));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting hudOn = add(Setting.bool("Bounce Counter HUD", true));

    long lastSeen = -100;
    int chain, cd;

    public MaceChain() { super("Mace Chain"); }

    @Override public void onDisable() { chain = 0; }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) cd--;
        long now = mc.world.getTime();
        if (now - AutoMace.smashTick > 200) chain = 0;
        if (AutoMace.smashTick == lastSeen) return;      // already bounced for this smash
        if (now - AutoMace.smashTick > window.i()) { lastSeen = AutoMace.smashTick; return; }
        if (cd > 0 || chain >= maxChain.i()) return;
        List<LivingEntity> t = Targets.find(mc, LegitMode.reach(within.v), players.b, mobs.b, LegitMode.walls(walls.b));
        if (t.isEmpty()) { lastSeen = AutoMace.smashTick; return; }
        int wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
        if (wind < 0) return;
        int mace = Inv.hotbar(s -> s.isOf(Items.MACE));
        var p = mc.player;
        int prev = Inv.selected();
        float yaw = p.getYaw(), pitch = p.getPitch();
        Inv.select(wind);
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        p.setYaw(yaw); p.setPitch(pitch);
        Inv.select(mace >= 0 ? mace : prev);
        lastSeen = AutoMace.smashTick; chain++; cd = LegitMode.delay(delay.i());
    }

    @Override public void onRender(net.minecraft.client.gui.DrawContext c, float td) {
        if (hudOn.b && chain > 0) com.goku.util.Esp.hud(c, "Mace chain: " + chain + " / " + maxChain.i(), Modules.accent());
    }
}
