package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.block.Blocks;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Random;

/** Crystal macro help: places a crystal on the obsidian / bedrock you look at and breaks the crystal you look at, with human timing. */
public class CrystalAssist extends Module {
    final Setting place = add(Setting.bool("Place On Obsidian/Bedrock", true));
    final Setting hit = add(Setting.bool("Break Crystal Under Crosshair", true));
    final Setting needClick = add(Setting.bool("Require Mouse Held", true));
    final Setting enemy = add(Setting.num("Only If Player Within", 10, 0, 30, 1));
    final Setting minMs = add(Setting.num("Min Delay (ms)", 0, 0, 300, 10));
    final Setting maxMs = add(Setting.num("Max Delay (ms)", 40, 0, 300, 10));
    final Setting minHp = add(Setting.num("Stop Below HP", 5, 0, 20, 1));
    final Random rnd = new Random();
    long nextAt;

    public CrystalAssist() { super("Crystal Assist"); }

    boolean ready() {
        long now = System.currentTimeMillis();
        if (nextAt == 0) {
            double lo = Math.min(minMs.v, maxMs.v), hi = Math.max(minMs.v, maxMs.v);
            nextAt = now + (long) (lo + rnd.nextDouble() * (hi - lo));
        }
        return now >= nextAt;
    }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || p.getHealth() <= minHp.v) return;
        if (enemy.v > 0 && Targets.find(mc, enemy.v, true, false, true).isEmpty()) return;
        if (hit.b && mc.targetedEntity instanceof EndCrystalEntity cr && (!needClick.b || mc.options.attackKey.isPressed())) {
            if (!ready()) return;
            mc.interactionManager.attackEntity(p, cr);
            p.swingHand(Hand.MAIN_HAND);
            nextAt = 0;
            return;
        }
        if (place.b && p.getMainHandStack().isOf(Items.END_CRYSTAL) && (!needClick.b || mc.options.useKey.isPressed())
                && mc.crosshairTarget instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK && b.getSide() == Direction.UP) {
            BlockPos pos = b.getBlockPos();
            var st = mc.world.getBlockState(pos);
            if (!(st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK))) return;
            if (!mc.world.getBlockState(pos.up()).isAir() || !mc.world.getBlockState(pos.up(2)).isAir()) return;
            if (!mc.world.getOtherEntities(null, new net.minecraft.util.math.Box(pos.up())).isEmpty()) return;
            if (!ready()) return;
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, b);
            p.swingHand(Hand.MAIN_HAND);
            nextAt = 0;
        }
    }
}
