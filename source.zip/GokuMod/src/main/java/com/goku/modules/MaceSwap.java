package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Mace Swap: manual assist. When you press attack while falling onto something, the best mace is selected for you (and your old item comes back on landing). */
public class MaceSwap extends Module {
    final Setting minFall = add(Setting.num("Min Fall Height", 1.5, 1.5, 20, 0.5));
    final Setting playersOnly = add(Setting.bool("Players Only", false));
    final Setting smart = add(Setting.bool("Smart Mace (Breach/Density)", true));
    final Setting armorLimit = add(Setting.num("Breach If Armor >=", 8, 1, 20, 1));
    final Setting swapBack = add(Setting.bool("Swap Back On Landing", true));
    int restore = -1;

    public MaceSwap() { super("Mace Swap"); }

    @Override public void onDisable() { restore = -1; }

    @Override public void onPreTick() {
        if (mc.currentScreen != null || mc.player == null) return;
        if (restore >= 0 && mc.player.isOnGround()) {
            if (swapBack.b) Inv.select(restore);
            restore = -1;
            return;
        }
        if (!mc.options.attackKey.isPressed() || !AutoMace.falling(mc.player) || mc.player.fallDistance < minFall.v) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hr) || !(hr.getEntity() instanceof LivingEntity le)) return;
        if (playersOnly.b && !(le instanceof PlayerEntity)) return;
        int s = AutoMace.bestMace(le, smart.b, armorLimit.i());
        if (s < 0 || Inv.selected() == s) return;
        if (restore < 0) restore = Inv.selected();
        Inv.select(s);
    }
}
