package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

/** Combat modules that need to look at something turn toward it over a few ticks instead of snapping, and only act once aligned. */
public class SmoothRotation extends Module {
    public final Setting maxTurn = add(Setting.num("Max Turn Per Tick (deg)", 24, 5, 90, 1));
    public final Setting tol = add(Setting.num("Act Within (deg)", 4, 1, 15, 1));

    public SmoothRotation() { super("Smooth Rotation"); enabled = true; }
}
