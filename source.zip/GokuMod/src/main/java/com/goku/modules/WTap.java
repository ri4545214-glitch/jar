package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** After you hit something, lets go of forward for a moment so you re-sprint and the next hit has full knockback. */
public class WTap extends Module {
    final Setting delay = add(Setting.num("Release (ms)", 50, 50, 300, 10));
    final Setting playersOnly = add(Setting.bool("Players Only", true));
    int ticks;
    boolean wasForward;

    public WTap() { super("W Tap"); }

    @Override public void onDisable() { restore(); }

    public void onAttack(Entity e) {
        if (playersOnly.b && !(e instanceof PlayerEntity)) return;
        if (ticks > 0 || !mc.player.isSprinting() || !mc.options.forwardKey.isPressed()) return;
        wasForward = true;
        ticks = Math.max(1, (int) Math.ceil(delay.v / 50.0)) + (LegitMode.on() ? LegitMode.delay(0) : 0);
        mc.options.forwardKey.setPressed(false);
        mc.player.setSprinting(false);
    }

    void restore() {
        if (wasForward && mc.options != null) mc.options.forwardKey.setPressed(true);
        wasForward = false; ticks = 0;
    }

    @Override public void onPreTick() {
        if (ticks <= 0) return;
        if (--ticks == 0) restore(); else mc.options.forwardKey.setPressed(false);
    }
}
