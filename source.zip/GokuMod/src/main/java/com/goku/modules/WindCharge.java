package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Keys;
import com.goku.util.Use;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Wind charge utility: Double Jump (press jump again in the air -> charge at your feet) and Fall Save (charge just before landing hard). */
public class WindCharge extends Module {
    final Setting doubleJump = add(Setting.bool("Double Jump", true));
    final Setting fallSave = add(Setting.bool("Fall Save", true));
    final Setting minFall = add(Setting.num("Fall Save Min Fall", 6, 3, 40, 1));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 10, 10, 60, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd, air;
    boolean jumpWas;

    public WindCharge() { super("Wind Charge"); }

    @Override public void onPreTick() {
        var p = mc.player;
        if (cd > 0) cd--;
        air = p.isOnGround() ? 0 : air + 1;
        boolean jump = Keys.physical(mc.options.jumpKey);
        boolean pressed = jump && !jumpWas;
        jumpWas = jump;
        if (cd > 0 || mc.currentScreen != null || p.isTouchingWater() || p.isClimbing() || p.isGliding()) return;
        int slot = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
        if (slot < 0) return;
        boolean go = false;
        if (doubleJump.b && pressed && air >= 2) go = true;
        if (!go && fallSave.b && p.fallDistance >= minFall.v && p.getVelocity().y < -0.6) {
            Vec3d f = p.getEntityPos();
            var hit = mc.world.raycast(new RaycastContext(f, f.add(0, -4.0, 0), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            go = hit.getType() == HitResult.Type.BLOCK;
        }
        if (go && Use.item(slot, p.getYaw(), 90f, swapBack.b)) cd = LegitMode.delay(cooldown.i());
    }
}
