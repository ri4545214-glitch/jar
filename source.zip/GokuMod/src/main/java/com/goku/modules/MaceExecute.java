package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Rot;
import com.goku.util.Targets;
import com.goku.util.Use;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.List;

/** Finisher: when a player is low on health it turns to them, launches you up with a wind charge, then drops on them with the mace. */
public class MaceExecute extends Module {
    final Setting hpLimit = add(Setting.num("Target HP <=", 8, 2, 20, 1));
    final Setting range = add(Setting.num("Target Range", 30, 8, 80, 2));
    final Setting needFall = add(Setting.num("Min Fall Before Hit", 3.0, 1.5, 15, 0.5));
    final Setting steer = add(Setting.bool("Steer Toward Target", true));
    final Setting walls = add(Setting.bool("Through Walls", false));

    enum S { IDLE, RISE, DIVE }
    S state = S.IDLE;
    LivingEntity tgt;
    int t, cd;
    boolean fwd;

    public MaceExecute() { super("Mace Execute"); }

    @Override public void onDisable() { stop(); }

    void stop() {
        if (fwd && mc.options != null) mc.options.forwardKey.setPressed(false);
        fwd = false; state = S.IDLE; tgt = null; cd = 40; t = 0;
    }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !p.isAlive()) return;
        if (cd > 0) { cd--; if (state == S.IDLE) return; }
        t++;
        switch (state) {
            case IDLE -> {
                int mace = Inv.hotbar(s -> s.isOf(Items.MACE)), wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
                if (mace < 0 || wind < 0 || !p.isOnGround()) return;
                List<LivingEntity> l = Targets.find(mc, LegitMode.reach(range.v), true, false, LegitMode.walls(walls.b));
                for (LivingEntity e : l) if (e.getHealth() + e.getAbsorptionAmount() <= hpLimit.v) { tgt = e; break; }
                if (tgt == null) return;
                Rot.face(tgt.getEntityPos().add(0, 1, 0));                 // turn around first
                if (Use.item(wind, p.getYaw(), 90f, false)) { Inv.select(mace); state = S.RISE; t = 0; }
                else tgt = null;
            }
            case RISE -> {
                if (tgt == null || !tgt.isAlive()) { stop(); return; }
                Rot.face(tgt.getEntityPos().add(0, 1, 0));
                if ((p.getVelocity().y <= 0.05 && t > 3) || t > 40) { state = S.DIVE; t = 0; }
            }
            case DIVE -> {
                if (tgt == null || !tgt.isAlive() || t > 120 || (p.isOnGround() && t > 4)) { stop(); return; }
                int mace = Inv.hotbar(s -> s.isOf(Items.MACE));
                if (mace >= 0 && Inv.selected() != mace) Inv.select(mace);
                Rot.face(tgt.getEntityPos().add(0, tgt.getHeight() * 0.6, 0));
                if (steer.b) { mc.options.forwardKey.setPressed(true); fwd = true; }
                if (p.distanceTo(tgt) <= 3.6 && p.fallDistance >= needFall.v && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                    mc.interactionManager.attackEntity(p, tgt);
                    p.swingHand(Hand.MAIN_HAND);
                    stop();
                }
            }
        }
    }
}
