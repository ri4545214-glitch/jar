package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;

/** Nethpot: moves splash potions from the inventory into empty hotbar slots so Auto Pot never runs dry. */
public class PotRefill extends Module {
    final Setting heal = add(Setting.num("Healing In Hotbar", 6, 0, 9, 1));
    final Setting speed = add(Setting.num("Speed In Hotbar", 1, 0, 3, 1));
    final Setting strength = add(Setting.num("Strength In Hotbar", 1, 0, 3, 1));
    final Setting fireRes = add(Setting.num("Fire Res In Hotbar", 0, 0, 3, 1));
    final Setting invOnly = add(Setting.bool("Only With Inventory Open", true));
    final Setting delay = add(Setting.num("Delay (ticks)", 2, 0, 20, 1));
    int cd;

    public PotRefill() { super("Pot Refill"); }

    boolean isPot(ItemStack s, RegistryEntry<StatusEffect> eff) { return s.isOf(Items.SPLASH_POTION) && AutoPot.has(s, eff); }

    boolean refill(RegistryEntry<StatusEffect> eff, int want) {
        if (want <= 0) return false;
        int have = 0, empty = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (isPot(s, eff)) have++;
            else if (s.isEmpty() && empty < 0) empty = i;
        }
        if (have >= want || empty < 0) return false;
        for (int i = 9; i < 36; i++) {
            if (!isPot(mc.player.getInventory().getStack(i), eff)) continue;
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, Inv.containerSlot(i), empty, SlotActionType.SWAP, mc.player);
            return true;
        }
        return false;
    }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        boolean inv = mc.currentScreen instanceof InventoryScreen;
        if (mc.currentScreen != null && !inv) return;
        if (invOnly.b && !inv) return;
        if (refill(StatusEffects.INSTANT_HEALTH, heal.i()) || refill(StatusEffects.SPEED, speed.i())
                || refill(StatusEffects.STRENGTH, strength.i()) || refill(StatusEffects.FIRE_RESISTANCE, fireRes.i()))
            cd = LegitMode.delay(delay.i());
    }
}
