package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.mixin.LivingEntityAccessor;

/** Removes the 10 tick pause between jumps (hold space to bunny-hop up 1 block steps). Legit Mode keeps a small minimum delay. */
public class NoJumpDelay extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));

    public NoJumpDelay() { super("No Jump Delay"); }

    @Override public void onPreTick() {
        try {
            LivingEntityAccessor a = (LivingEntityAccessor) (Object) mc.player;
            int d = delay.i() + (LegitMode.on() ? 2 : 0);
            if (a.gokuJumpCd() > d) a.gokuSetJumpCd(d);
        } catch (Throwable t) { setEnabled(false); }
    }
}
