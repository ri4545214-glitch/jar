package com.goku.modules;

import com.goku.Module;

/** Jump again the moment you land while the jump key is held (removes the 10-tick jump cooldown). */
public class NoJumpDelay extends Module {
    public NoJumpDelay() { super("No Jump Delay"); }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !mc.options.jumpKey.isPressed()) return;
        if (p.isOnGround() && p.getVelocity().y <= 0 && !p.isTouchingWater() && !p.isInLava() && !p.isClimbing()) p.jump();
    }
}
