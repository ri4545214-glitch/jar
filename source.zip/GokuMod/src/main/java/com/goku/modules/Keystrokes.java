package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Hud;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;

/** WASD / space / mouse key display with CPS. */
public class Keystrokes extends Module {
    final Setting corner = add(Setting.mode("Corner", 2, Hud.CORNERS));
    final Setting offX = add(Setting.num("Offset X", 6, 0, 400, 2));
    final Setting offY = add(Setting.num("Offset Y", 6, 0, 400, 2));
    final Setting size = add(Setting.num("Key Size", 20, 12, 36, 2));
    final Setting gap = add(Setting.num("Gap", 2, 0, 8, 1));
    final Setting mouse = add(Setting.bool("Mouse Buttons", true));
    final Setting cps = add(Setting.bool("Show CPS", true));
    final Setting space = add(Setting.bool("Space Bar", true));
    final Setting pressedColor = add(Setting.mode("Pressed Color", 4, Draw.NAMES));
    final Setting bgAlpha = add(Setting.num("Background Alpha", 110, 0, 255, 5));

    private final ArrayDeque<Long> left = new ArrayDeque<>(), right = new ArrayDeque<>();
    private boolean wasL, wasR;

    public Keystrokes() { super("Keystrokes"); }

    private static int count(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
        return q.size();
    }

    private void key(DrawContext c, int x, int y, int w, int h, String t, boolean down) {
        int col = Draw.COLORS[pressedColor.idx];
        c.fill(x, y, x + w, y + h, down ? Esp.a(col, 0xB0) : (bgAlpha.i() << 24));
        int tw = mc.textRenderer.getWidth(t);
        c.drawText(mc.textRenderer, t, x + (w - tw) / 2, y + (h - 8) / 2, down ? 0xFF000000 : 0xFFFFFFFF, !down);
    }

    @Override public void onRender(DrawContext c, float td) {
        var o = mc.options;
        long now = System.currentTimeMillis();
        boolean l = o.attackKey.isPressed(), r = o.useKey.isPressed();
        if (l && !wasL) left.addLast(now);
        if (r && !wasR) right.addLast(now);
        wasL = l; wasR = r;

        int s = size.i(), g = gap.i();
        int w = 3 * s + 2 * g;
        int sh = s * 2 / 3;
        int h = 2 * s + g + (mouse.b ? s + g : 0) + (space.b ? sh + g : 0);
        int[] p = Hud.pos(corner.idx, offX.i(), offY.i(), w, h);
        int x = p[0], y = p[1];
        key(c, x + s + g, y, s, s, "W", o.forwardKey.isPressed());
        y += s + g;
        key(c, x, y, s, s, "A", o.leftKey.isPressed());
        key(c, x + s + g, y, s, s, "S", o.backKey.isPressed());
        key(c, x + 2 * (s + g), y, s, s, "D", o.rightKey.isPressed());
        y += s + g;
        if (mouse.b) {
            int bw = (w - g) / 2;
            key(c, x, y, bw, s, cps.b ? "L " + count(left, now) : "LMB", l);
            key(c, x + bw + g, y, bw, s, cps.b ? "R " + count(right, now) : "RMB", r);
            y += s + g;
        }
        if (space.b) key(c, x, y, w, sh, "-----", o.jumpKey.isPressed());
    }

    @Override public void onDisable() { left.clear(); right.clear(); wasL = wasR = false; }
}
