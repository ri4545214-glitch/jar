package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Trig;
import com.goku.util.Use;
import net.minecraft.item.Items;

/** Press the trigger to throw an ender pearl from your hotbar. Key Pearl throws where you look; Short Pearl uses a fixed (low) pitch for a short hop. */
public class KeyPearl extends Module {
    final Setting trigger;
    final Setting useLook;
    final Setting pitch;
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 20, 20, 60, 1));
    final int slot;
    int cd;

    public KeyPearl(String name, boolean look, double defPitch, int slot) {
        super(name);
        this.slot = slot;
        trigger = add(Setting.mode("Trigger", look ? 0 : 1, Trig.NAMES));
        useLook = add(Setting.bool("Use Look Direction", look));
        pitch = add(Setting.num("Pitch (if not look)", defPitch, -90, 90, 1));
    }

    @Override public void onPreTick() {
        if (cd > 0) cd--;
        if (mc.currentScreen != null || !Trig.pressed(trigger.idx, slot) || cd > 0) return;
        int s = Inv.hotbar(i -> i.isOf(Items.ENDER_PEARL));
        if (s < 0) return;
        if (Use.item(s, mc.player.getYaw(), useLook.b ? mc.player.getPitch() : (float) pitch.v, swapBack.b)) cd = LegitMode.delay(cooldown.i());
    }
}
