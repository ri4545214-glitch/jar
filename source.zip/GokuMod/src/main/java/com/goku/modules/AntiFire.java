package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** When you are burning, places a water bucket at your feet to put the fire out. */
public class AntiFire extends Module {
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting delay = add(Setting.num("Cooldown (ticks)", 20, 5, 60, 1));
    int cd;

    public AntiFire() { super("Anti Fire"); }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        var p = mc.player;
        if (!p.isOnFire() || p.isTouchingWater() || p.isFireImmune() || p.hasStatusEffect(StatusEffects.FIRE_RESISTANCE) || !p.isOnGround()) return;
        int slot = Inv.hotbar(s -> s.isOf(Items.WATER_BUCKET));
        if (slot < 0) return;
        var below = p.getBlockPos().down();
        int prev = Inv.selected();
        Inv.select(slot);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(new Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5), Direction.UP, below, false));
        p.swingHand(Hand.MAIN_HAND);
        if (swapBack.b) Inv.select(prev);
        cd = delay.i();
    }
}
