package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Use;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Items;
import net.minecraft.world.World;

/** Puts yourself out: places water from a bucket under you while burning, then picks it back up. (Low Fire only hides the overlay.) */
public class AntiFire extends Module {
    final Setting pickup = add(Setting.bool("Pick Water Back Up", true));
    final Setting pickDelay = add(Setting.num("Pickup Delay (ticks)", 4, 1, 20, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    boolean placed;
    int wait, cd;

    public AntiFire() { super("Anti Fire"); }

    @Override public void onDisable() { placed = false; wait = cd = 0; }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !p.isAlive()) return;
        if (cd > 0) { cd--; return; }
        if (placed) {
            if (!p.isOnFire() && ++wait >= pickDelay.i()) {
                if (pickup.b) Use.item(Inv.hotbar(s -> s.isOf(Items.BUCKET)), p.getYaw(), 90f, swapBack.b);
                placed = false; wait = 0; cd = LegitMode.delay(5);
            } else if (++wait > 100) { placed = false; wait = 0; }
            return;
        }
        if (!p.isOnFire() || p.isTouchingWater() || p.isFireImmune() || p.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)) return;
        if (mc.world.getRegistryKey() == World.NETHER || !p.isOnGround()) return;
        int bucket = Inv.hotbar(s -> s.isOf(Items.WATER_BUCKET));
        if (bucket >= 0 && Use.item(bucket, p.getYaw(), 90f, swapBack.b)) { placed = true; wait = 0; }
    }
}
