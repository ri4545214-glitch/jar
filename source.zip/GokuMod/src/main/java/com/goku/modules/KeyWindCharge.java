package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Trig;
import com.goku.util.Use;
import net.minecraft.item.Items;

/** Press the trigger to throw a wind charge: Down (launch yourself up), Crosshair, or Behind you (launch forward). */
public class KeyWindCharge extends Module {
    final Setting trigger = add(Setting.mode("Trigger", 3, Trig.NAMES));
    final Setting dir = add(Setting.mode("Direction", 0, "Down", "Crosshair", "Behind"));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 10, 10, 60, 1));
    int cd;

    public KeyWindCharge() { super("Key Wind Charge"); }

    @Override public void onPreTick() {
        if (cd > 0) cd--;
        if (mc.currentScreen != null || !Trig.pressed(trigger.idx, 2) || cd > 0) return;
        int s = Inv.hotbar(i -> i.isOf(Items.WIND_CHARGE));
        if (s < 0) return;
        float y = mc.player.getYaw(), p = mc.player.getPitch();
        if (dir.idx == 0) p = 90f;
        else if (dir.idx == 2) { y += 180f; p = Math.max(p, 0f); }
        if (Use.item(s, y, p, swapBack.b)) cd = LegitMode.delay(cooldown.i());
    }
}
