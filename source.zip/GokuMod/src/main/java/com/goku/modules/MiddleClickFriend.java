package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Trig;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/** Look at a player and press the trigger to add / remove them as a friend. */
public class MiddleClickFriend extends Module {
    final Setting trigger = add(Setting.mode("Trigger", 0, Trig.NAMES));

    public MiddleClickFriend() { super("Middle Click Friend"); }

    @Override public void onPreTick() {
        if (mc.currentScreen != null) return;
        if (!Trig.pressed(trigger.idx, 0)) return;
        if (mc.targetedEntity instanceof PlayerEntity p) {
            String n = p.getName().getString();
            boolean now = Modules.FRIENDS.toggle(n);
            mc.player.sendMessage(Text.literal("[Goku] " + n + (now ? " added to friends" : " removed from friends")), true);
        }
    }
}
