package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Lag;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;

/**
 * Holds what you send to the server for a short time, then releases it in order. Dynamic only does this while a player is near you.
 * (Needs the packet hook in the optional mixin config; if that failed to apply, this module simply does nothing.)
 */
public class FakeLag extends Module {
    final Setting mode = add(Setting.mode("Mode", 1, "Constant", "Dynamic"));
    final Setting delay = add(Setting.num("Delay (ms)", 150, 50, 500, 10));
    final Setting near = add(Setting.num("Dynamic Range", 10, 3, 30, 1));

    public FakeLag() { super("Fake Lag"); }

    @Override public void onDisable() { Lag.holdOut = false; Lag.flushOut(0); }

    void step() {
        boolean on = mode.idx == 0 || !Targets.find(mc, near.v, true, false, true).isEmpty();
        if (mc.currentScreen != null) on = false;
        Lag.holdOut = on;
        Lag.flushOut(on ? (long) delay.v : 0);
    }

    @Override public void onTick() { step(); }
    @Override public void onRender(DrawContext c, float td) { if (Lag.hasOut()) Lag.flushOut(Lag.holdOut ? (long) delay.v : 0); }
}
