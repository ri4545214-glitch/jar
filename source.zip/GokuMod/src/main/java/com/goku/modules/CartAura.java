package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Place;
import com.goku.util.Targets;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Cart PvP: places a rail at the target's feet, puts a TNT minecart on it, lights it with flint &amp; steel / a fire charge
 * and (optionally) runs away from the blast. Needs rails + TNT minecarts + an igniter in the hotbar.
 */
public class CartAura extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Target Range", 4.5, 2, 6, 0.5));
    final Setting spot = add(Setting.mode("Rail Spot", 0, "Target Feet", "Next To Target"));
    final Setting maxCarts = add(Setting.num("Max Carts At Once", 1, 1, 3, 1));
    final Setting igniter = add(Setting.mode("Ignite With", 0, "Flint & Steel", "Fire Charge", "Any"));
    final Setting ignite = add(Setting.bool("Auto Ignite", true));
    final Setting retreat = add(Setting.bool("Run Away After Ignite", true));
    final Setting retreatTicks = add(Setting.num("Run Away (ticks)", 30, 10, 80, 5));
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 1, 20, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting needGround = add(Setting.bool("Target Must Be On Ground", true));

    final Set<UUID> lit = new HashSet<>();
    int cd, run;
    Vec3d runFrom;
    boolean runKeys;

    public CartAura() { super("Cart Aura"); }

    @Override public void onDisable() { stopRun(); lit.clear(); }

    void stopRun() {
        if (runKeys) {
            if (!Modules.AUTO_WALK.enabled) { mc.options.forwardKey.setPressed(false); mc.options.sprintKey.setPressed(false); }
            runKeys = false;
        }
        run = 0;
    }

    boolean isIgniter(net.minecraft.item.ItemStack s) {
        return switch (igniter.idx) {
            case 0 -> s.isOf(Items.FLINT_AND_STEEL);
            case 1 -> s.isOf(Items.FIRE_CHARGE);
            default -> s.isOf(Items.FLINT_AND_STEEL) || s.isOf(Items.FIRE_CHARGE);
        };
    }

    @Override public void onPreTick() {
        if (mc.player == null) return;
        if (run > 0 && runFrom != null && mc.currentScreen == null) {
            float[] r = Targets.rot(runFrom, mc.player.getEntityPos());
            mc.player.setYaw(r[0]);
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
            runKeys = true;
            if (--run <= 0) stopRun();
        }
    }

    boolean railOk(BlockPos p) {
        var st = mc.world.getBlockState(p);
        if (st.getBlock() instanceof AbstractRailBlock) return true;
        return st.isReplaceable() && !mc.world.getBlockState(p.down()).isReplaceable();
    }

    /** Places the held rail at p (clicking the block below / beside). Entities standing there do not block rails. */
    boolean placeRail(BlockPos p, double reach) {
        reach = LegitMode.placeReach(reach);
        Vec3d eye = mc.player.getEyePos();
        Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
        for (Direction d : order) {
            BlockPos nb = p.offset(d);
            if (mc.world.getBlockState(nb).isReplaceable()) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(nb).add(Vec3d.of(face.getVector()).multiply(0.5));
            if (eye.distanceTo(hit) > reach) continue;
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, nb, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) { cd--; return; }
        if (lit.size() > 64) lit.clear();
        List<LivingEntity> ts = Targets.find(mc, LegitMode.reach(range.v + 2), players.b, mobs.b, false);
        if (ts.isEmpty()) return;
        LivingEntity t = ts.get(0);
        if (needGround.b && !t.isOnGround()) return;
        BlockPos tf = t.getBlockPos();

        // carts near the target
        int carts = 0; TntMinecartEntity fresh = null;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof TntMinecartEntity c) || c.distanceTo(t) > 4) continue;
            carts++;
            if (!lit.contains(c.getUuid()) && fresh == null) fresh = c;
        }

        // 1) light a placed cart
        if (fresh != null && ignite.b) {
            if (mc.player.distanceTo(fresh) > 2.8) return;   // entity reach; step closer
            int slot = Inv.hotbar(this::isIgniter);
            if (slot < 0) return;
            int prev = Inv.selected();
            Inv.select(slot);
            mc.interactionManager.interactEntity(mc.player, fresh, Hand.MAIN_HAND);
            mc.player.swingHand(Hand.MAIN_HAND);
            if (swapBack.b) Inv.select(prev);
            lit.add(fresh.getUuid());
            if (retreat.b) { run = retreatTicks.i(); runFrom = fresh.getEntityPos(); }
            cd = LegitMode.delay(delay.i());
            return;
        }
        if (carts >= maxCarts.i()) return;

        // 2) find a rail spot
        BlockPos spotPos = null;
        BlockPos[] cand = spot.idx == 0 ? new BlockPos[]{tf}
                : new BlockPos[]{tf.north(), tf.south(), tf.east(), tf.west()};
        for (BlockPos p : cand) if (railOk(p) && mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) <= LegitMode.placeReach(4.5)) { spotPos = p; break; }
        if (spotPos == null) return;

        int prev = Inv.selected();
        if (!(mc.world.getBlockState(spotPos).getBlock() instanceof AbstractRailBlock)) {
            int rail = Inv.hotbar(s -> s.isOf(Items.RAIL) || s.isOf(Items.POWERED_RAIL) || s.isOf(Items.DETECTOR_RAIL) || s.isOf(Items.ACTIVATOR_RAIL));
            if (rail < 0) return;
            Inv.select(rail);
            boolean ok = placeRail(spotPos, 4.5);
            if (swapBack.b) Inv.select(prev);
            if (ok) cd = LegitMode.delay(delay.i());
            return;
        }
        // 3) rail is there: put the TNT minecart on it
        int cart = Inv.hotbar(s -> s.isOf(Items.TNT_MINECART));
        if (cart < 0) return;
        Inv.select(cart);
        Vec3d hit = new Vec3d(spotPos.getX() + 0.5, spotPos.getY() + 0.125, spotPos.getZ() + 0.5);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, spotPos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        if (swapBack.b) Inv.select(prev);
        cd = LegitMode.delay(delay.i());
    }
}
