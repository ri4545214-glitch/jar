package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/** Raises your shield while a player is close and facing you. Lowers it again when you attack or nobody is near. */
public class AutoShield extends Module {
    final Setting range = add(Setting.num("Range", 4.5, 2, 8, 0.5));
    final Setting swingOnly = add(Setting.bool("Only When They Swing", false));
    final Setting release = add(Setting.bool("Lower When Attacking", true));
    boolean forced;

    public AutoShield() { super("Auto Shield"); }

    @Override public void onDisable() { if (forced && mc.options != null) mc.options.useKey.setPressed(false); forced = false; }

    @Override public void onPreTick() {
        var p = mc.player;
        boolean has = p.getOffHandStack().isOf(Items.SHIELD) || p.getMainHandStack().isOf(Items.SHIELD);
        boolean threat = false;
        if (has && mc.currentScreen == null && !(release.b && mc.options.attackKey.isPressed())) {
            for (LivingEntity t : Targets.find(mc, range.v, true, false, true)) {
                Vec3d look = t.getRotationVec(1f).normalize();
                Vec3d to = p.getEyePos().subtract(t.getEyePos()).normalize();
                if (look.dotProduct(to) < 0.5) continue;
                if (swingOnly.b && !t.handSwinging) continue;
                threat = true; break;
            }
        }
        if (threat) { mc.options.useKey.setPressed(true); forced = true; }
        else if (forced) { mc.options.useKey.setPressed(false); forced = false; }
    }
}
