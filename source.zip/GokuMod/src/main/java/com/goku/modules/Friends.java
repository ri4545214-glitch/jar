package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.player.PlayerEntity;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.TreeSet;

/** Friend list (saved in config/gokumod_friends.txt). Friends are never targeted by combat modules. Add them with Middle Click Friend. */
public class Friends extends Module {
    final Setting protect = add(Setting.bool("Protect Friends", true));
    final Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
    boolean loaded;

    public Friends() { super("Friends"); }

    Path file() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod_friends.txt"); }

    void load() {
        if (loaded) return;
        loaded = true;
        try { if (Files.exists(file())) for (String l : Files.readAllLines(file())) if (!l.isBlank()) names.add(l.trim()); } catch (Exception ignored) {}
    }

    void save() { try { Files.write(file(), names); } catch (Exception ignored) {} }

    public boolean isFriend(PlayerEntity p) {
        if (!enabled || !protect.b) return false;
        load();
        return names.contains(p.getName().getString());
    }

    /** Returns true if the player is now a friend. */
    public boolean toggle(String name) {
        load();
        boolean now = !names.remove(name);
        if (now) names.add(name);
        save();
        return now;
    }
}
