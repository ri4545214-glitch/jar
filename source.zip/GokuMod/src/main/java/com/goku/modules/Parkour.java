package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Keys;
import net.minecraft.util.math.Vec3d;

/** Jumps for you at the very edge of a block while you walk forward. */
public class Parkour extends Module {
    final Setting edge = add(Setting.num("Edge Distance", 0.3, 0.1, 0.6, 0.05));
    boolean forced;

    public Parkour() { super("Parkour"); }

    @Override public void onDisable() { release(); }

    void release() {
        if (forced && mc.options != null && !Keys.physical(mc.options.jumpKey)) mc.options.jumpKey.setPressed(false);
        forced = false;
    }

    @Override public void onPreTick() {
        release();
        var p = mc.player;
        if (mc.currentScreen != null || !p.isOnGround() || p.isSneaking() || !mc.options.forwardKey.isPressed()) return;
        Vec3d f = Vec3d.fromPolar(0f, p.getYaw());
        var box = p.getBoundingBox().offset(f.x * edge.v, -0.5, f.z * edge.v);
        if (mc.world.getBlockCollisions(p, box).iterator().hasNext()) return;
        mc.options.jumpKey.setPressed(true);
        forced = true;
    }
}
