package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.Vec3d;

/** Cart ESP: boxes TNT minecarts (red = lit, orange = not lit yet) with distance, and warns on the HUD when a lit one is close. */
public class CartEsp extends Module {
    final Setting style = add(Setting.mode("Style", 1, Esp.STYLES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting labels = add(Setting.bool("Labels", true));
    final Setting warn = add(Setting.num("Warn HUD Within", 8, 3, 20, 1));
    final Setting tracers = add(Setting.bool("Tracers To Lit Carts", false));

    public CartEsp() { super("Cart ESP"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok || mc.world == null) return;
        double nearestLit = 1e9; int lit = 0;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof TntMinecartEntity m) || !m.isAlive()) continue;
            boolean on = m.isPrimed();
            int col = on ? 0xFFFF3030 : 0xFFFF9933;
            Vec3d lp = m.getLerpedPos(td);
            double d = lp.distanceTo(mc.player.getEntityPos());
            Esp.box(c, m.getBoundingBox().offset(lp.subtract(m.getEntityPos())), col, style.idx, fill.b, 1);
            if (labels.b) {
                double[] s = Projector.to(lp.add(0, 1.2, 0));
                if (s != null) Esp.label(c, (on ? "LIT " : "TNT ") + String.format("%.1fm", d), (int) s[0], (int) s[1], col);
            }
            if (on) {
                lit++; nearestLit = Math.min(nearestLit, d);
                if (tracers.b) Esp.tracer(c, lp.add(0, 0.4, 0), col, 0, 1);
            }
        }
        if (lit > 0 && nearestLit <= warn.v) Esp.hud(c, String.format("! LIT TNT MINECART %.1f blocks away", nearestLit), 0xFFFF4444);
    }
}
