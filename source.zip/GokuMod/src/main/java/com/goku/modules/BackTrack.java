package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Lag;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;

/**
 * Delays what the server tells you while a player is in range, so you see (and hit) them a moment in the past.
 * (Needs the packet hook in the optional mixin config; if that failed to apply, this module simply does nothing.)
 */
public class BackTrack extends Module {
    final Setting minMs = add(Setting.num("Min Delay (ms)", 75, 25, 300, 5));
    final Setting maxMs = add(Setting.num("Max Delay (ms)", 75, 25, 300, 5));
    final Setting range = add(Setting.num("Range", 7, 3, 12, 1));
    long cur = 75;
    final java.util.Random rnd = new java.util.Random();

    public BackTrack() { super("Back Track"); }

    @Override public void onDisable() { Lag.holdIn = false; Lag.flushIn(0); }

    void step() {
        boolean on = mc.currentScreen == null && !Targets.find(mc, range.v, true, false, true).isEmpty();
        Lag.holdIn = on;
        Lag.flushIn(on ? cur : 0);
    }

    @Override public void onTick() {
        double lo = Math.min(minMs.v, maxMs.v), hi = Math.max(minMs.v, maxMs.v);
        cur = (long) (lo + rnd.nextDouble() * (hi - lo));
        step();
    }
    @Override public void onRender(DrawContext c, float td) { if (Lag.hasIn()) Lag.flushIn(Lag.holdIn ? cur : 0); }
}
