package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Inv;
import com.goku.util.Place;
import com.goku.util.Schem;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/** Builds a .schem / .litematic / .nbt from config/gokumod/schematics using blocks from your hotbar (and optionally your inventory). */
public class AutoBuilder extends Module {
    record Target(BlockPos pos, Block block) {}

    final Setting file = add(Setting.mode("Schematic", 0, "(none)"));
    final Setting refresh = add(Setting.bool("> Refresh File List", false));
    final Setting start = add(Setting.bool("> Start Build", false));
    final Setting stop = add(Setting.bool("> Stop Build", false));
    final Setting origin = add(Setting.mode("Origin", 0, "In Front Of Me", "Looking At Block", "My Feet"));
    final Setting rotation = add(Setting.mode("Rotation", 0, "0", "90", "180", "270"));
    final Setting offY = add(Setting.num("Y Offset", 0, -10, 10, 1));
    final Setting perTick = add(Setting.num("Blocks Per Tick", 2, 1, 6, 1));
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 10, 1));
    final Setting reach = add(Setting.num("Place Range", 4.5, 2, 5, 0.5));
    final Setting layerFrom = add(Setting.num("From Layer (0=bottom)", 0, 0, 400, 1));
    final Setting layerTo = add(Setting.num("To Layer (0=top)", 0, 0, 400, 1));
    final Setting follow = add(Setting.bool("Walk To Next Blocks", true));
    final Setting materials = add(Setting.bool("Show Material List On Start", true));
    final Setting refill = add(Setting.bool("Refill From Inventory", true));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting showBounds = add(Setting.bool("Show Bounds", true));
    final Setting showNext = add(Setting.bool("Show Next Blocks", true));
    final Setting hud = add(Setting.bool("Progress HUD", true));

    private List<Target> plan = List.of();
    private Schem loaded;
    private Box bounds;
    private boolean building;
    private int cd, done, cursor, recount;
    private String missing = "";

    public AutoBuilder() { super("Auto Builder"); refreshFiles(); }

    static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("gokumod").resolve("schematics"); }

    void refreshFiles() {
        List<String> names = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> s = Files.list(dir())) {
                s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".schem") || n.endsWith(".litematic") || n.endsWith(".nbt")).sorted().forEach(names::add);
            }
        } catch (Exception ignored) {}
        if (names.isEmpty()) names.add("(none)");
        file.modes = names.toArray(new String[0]);
        file.idx = Math.max(0, Math.min(file.idx, file.modes.length - 1));
    }

    @Override public void onDisable() { building = false; plan = List.of(); bounds = null; if (walking) { com.goku.util.Nav.release(); walking = false; } }

    private boolean begin() {
        String name = file.modeName();
        if (name.equals("(none)")) { Place.msg("Put .schem / .litematic files in config/gokumod/schematics"); return false; }
        try { loaded = Schem.load(dir().resolve(name)); } catch (Exception e) { Place.msg("Load failed: " + e.getMessage()); return false; }
        int rot = rotation.idx, w = loaded.width, l = loaded.length;
        boolean swap = rot == 1 || rot == 3;
        int sx = swap ? l : w, sz = swap ? w : l;
        BlockPos base;
        var p = mc.player;
        if (origin.idx == 1 && mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) base = bh.getBlockPos().up();
        else if (origin.idx == 2) base = p.getBlockPos();
        else {
            var d = p.getHorizontalFacing();
            base = p.getBlockPos().offset(d, 2);
            if (d.getOffsetX() < 0) base = base.add(-(sx - 1), 0, 0);
            if (d.getOffsetZ() < 0) base = base.add(0, 0, -(sz - 1));
            if (d.getOffsetX() != 0) base = base.add(0, 0, -sz / 2);
            if (d.getOffsetZ() != 0) base = base.add(-sx / 2, 0, 0);
        }
        base = base.up(offY.i());
        List<Target> out = new ArrayList<>();
        for (Schem.Entry e : loaded.blocks) {
            int dx, dz;
            switch (rot) {
                case 1 -> { dx = l - 1 - e.z(); dz = e.x(); }
                case 2 -> { dx = w - 1 - e.x(); dz = l - 1 - e.z(); }
                case 3 -> { dx = e.z(); dz = w - 1 - e.x(); }
                default -> { dx = e.x(); dz = e.z(); }
            }
            out.add(new Target(base.add(dx, e.y(), dz), e.block()));
        }
        int lo = layerFrom.i(), hi = layerTo.i();
        final int baseY = base.getY();
        if (lo > 0 || hi > 0) out.removeIf(t -> { int ly = t.pos().getY() - baseY; return ly < lo || (hi > 0 && ly >= hi); });
        out.removeIf(t -> t.block().asItem() == net.minecraft.item.Items.AIR);   // water, lava, fire ... cannot be placed from an item
        // bottom to top, and snake through each row so neighbouring blocks are built one after another
        out.sort(Comparator.comparingInt((Target t) -> t.pos().getY()).thenComparingInt(t -> t.pos().getZ())
                .thenComparingInt(t -> (t.pos().getZ() & 1) == 0 ? t.pos().getX() : -t.pos().getX()));
        plan = out; cursor = 0;
        if (materials.b) {
            Map<Block, Integer> need = new HashMap<>();
            for (Target t : out) need.merge(t.block(), 1, Integer::sum);
            StringBuilder sb = new StringBuilder("Needs: ");
            need.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(6)
                    .forEach(e -> sb.append(e.getValue()).append(" ").append(e.getKey().getName().getString()).append(", "));
            if (need.size() > 6) sb.append("+").append(need.size() - 6).append(" more types");
            Place.msg(sb.toString());
            if (mc.player != null) mc.player.sendMessage(net.minecraft.text.Text.literal("[Goku] " + sb), false);
        }
        bounds = new Box(base.getX(), base.getY(), base.getZ(), base.getX() + sx, base.getY() + loaded.height, base.getZ() + sz);
        done = 0; missing = ""; building = true;
        Place.msg("Building " + name + " (" + out.size() + " blocks)");
        return true;
    }

    private int findSource(Block b) {
        var item = b.asItem();
        int hb = Inv.hotbar(s -> s.isOf(item));
        if (hb >= 0) return hb;
        if (!refill.b) return -1;
        var inv = mc.player.getInventory();
        for (int i = 9; i < 36; i++) if (inv.getStack(i).isOf(item)) {
            int target = Inv.selected();
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, Inv.containerSlot(i), target, SlotActionType.SWAP, mc.player);
            return target;
        }
        return -1;
    }

    @Override public void onTick() {
        if (refresh.b) { refresh.b = false; refreshFiles(); Place.msg(file.modes.length + " schematic(s) found"); }
        if (stop.b) { stop.b = false; building = false; Place.msg("Build stopped"); com.goku.util.Nav.release(); }
        if (start.b) { start.b = false; begin(); }
        if (!building || mc.currentScreen != null || Modules.FREECAM.enabled) return;
        if (cd > 0) { cd--; return; }
        Vec3d eye = mc.player.getEyePos();
        // skip the finished prefix, then look at a window of the remaining blocks
        while (cursor < plan.size() && mc.world.getBlockState(plan.get(cursor).pos()).isOf(plan.get(cursor).block())) cursor++;
        if (--recount <= 0) {
            recount = 20; int d = 0;
            for (Target t : plan) if (mc.world.getBlockState(t.pos()).isOf(t.block())) d++;
            done = d;
        }
        if (cursor >= plan.size()) { done = plan.size(); building = false; com.goku.util.Nav.release(); Place.msg("Build finished"); return; }

        int n = 0, scanned = 0, prev = Inv.selected();
        Set<Block> noSource = new HashSet<>();
        Target first = null;
        missing = "";
        for (int i = cursor; i < plan.size() && scanned < 1500; i++) {
            Target t = plan.get(i);
            if (mc.world.getBlockState(t.pos()).isOf(t.block())) continue;
            scanned++;
            if (first == null) first = t;
            if (n >= LegitMode.perTick(perTick.i())) break;
            if (eye.distanceTo(Vec3d.ofCenter(t.pos())) > reach.v) continue;
            if (noSource.contains(t.block())) continue;
            int slot = findSource(t.block());
            if (slot < 0) { noSource.add(t.block()); missing = t.block().getName().getString(); continue; }
            Inv.select(slot);
            if (Place.place(t.pos(), reach.v)) n++;
        }
        if (swapBack.b) Inv.select(prev);
        if (n > 0) cd = LegitMode.delay(delay.i());
        // nothing in reach: walk over to the next unfinished block
        if (follow.b && n == 0 && first != null && missing.isEmpty()) {
            Vec3d to = Vec3d.ofCenter(first.pos());
            if (eye.distanceTo(to) > reach.v - 1.0) { com.goku.util.Nav.walk(to, false, true, 25f); walking = true; }
            else if (walking) { com.goku.util.Nav.release(); walking = false; }
        } else if (walking) { com.goku.util.Nav.release(); walking = false; }
    }

    private boolean walking;

    @Override public void onRender(DrawContext c, float td) {
        if (hud.b && building) Esp.hud(c, "Builder: " + done + "/" + plan.size() + (missing.isEmpty() ? "" : "  need " + missing), Modules.accent());
        if (!com.goku.util.Projector.ok || !building) return;
        if (showBounds.b && bounds != null) Esp.box(c, bounds, 0xFF44CCFF, 1, false, 1);
        if (showNext.b) {
            int shown = 0;
            for (Target t : plan) {
                if (shown >= 20) break;
                if (mc.world.getBlockState(t.pos()).isOf(t.block())) continue;
                Esp.box(c, new Box(t.pos()).contract(0.05), 0xFFFFCC33, 0, true, 1);
                shown++;
            }
        }
    }
}
