package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Esp;
import com.goku.util.Nav;
import com.goku.util.Sfx;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * AFK base explorer: walks a spiral / straight line / random path, avoids lava, drops and (optionally) water, turns when stuck,
 * switches on Base Finder AI, walks to the first confident base, logs it to config/gokumod/bases.txt and stops.
 * It also stops by itself if you take damage, get low on health, or another player comes close.
 */
public class AutoExplore extends Module {
    final Setting pattern = add(Setting.mode("Pattern", 0, "Spiral", "Straight Line", "Random Walk"));
    final Setting step = add(Setting.num("Spiral Step (blocks)", 96, 16, 400, 16));
    final Setting sprint = add(Setting.bool("Sprint", true));
    final Setting turn = add(Setting.num("Turn Speed", 20, 5, 90, 5));
    final Setting baseConf = add(Setting.num("Go To Base At Conf %", 65, 30, 95, 5));
    final Setting stopDist = add(Setting.num("Stop Distance From Base", 40, 10, 120, 5));
    final Setting onFound = add(Setting.mode("When Base Found", 0, "Stop & Alert", "Log & Keep Exploring"));
    final Setting autoBase = add(Setting.bool("Auto-Enable Base Finder AI", true));
    final Setting avoidDrops = add(Setting.bool("Avoid Drops", true));
    final Setting maxDrop = add(Setting.num("Max Drop (blocks)", 3, 1, 8, 1));
    final Setting avoidWater = add(Setting.bool("Avoid Water", false));
    final Setting stopPlayer = add(Setting.num("Stop If Player Within (0=off)", 48, 0, 150, 4));
    final Setting stopHp = add(Setting.num("Stop If HP At/Below", 8, 0, 19, 1));
    final Setting log = add(Setting.bool("Log Bases To File", true));
    final Setting hud = add(Setting.bool("Status HUD", true));

    private final Random rnd = new Random();
    private final List<Vec3d> ignored = new ArrayList<>();
    private double hx, hz, legLen;
    private Vec3d legStart, lastPos;
    private int legCount, checkTick, stuckCount, randTimer;
    private boolean done, baseWasOn, keepBase;
    private float lastHp;
    private String status = "";
    private double walked;

    public AutoExplore() { super("Auto Explore (AFK)"); }

    static Path logFile() { return com.goku.Config.dir().resolve("bases.txt"); }

    @Override public void onEnable() {
        if (mc.player == null) return;
        baseWasOn = Modules.BASE_AI.enabled;
        keepBase = false; done = false; walked = 0;
        if (autoBase.b && !baseWasOn) Modules.BASE_AI.setEnabled(true);
        double yaw = Math.toRadians(mc.player.getYaw());
        hx = -Math.sin(yaw); hz = Math.cos(yaw);
        if (pattern.idx != 2) { if (Math.abs(hx) > Math.abs(hz)) { hx = Math.signum(hx); hz = 0; } else { hz = Math.signum(hz); hx = 0; } }
        legStart = lastPos = mc.player.getEntityPos();
        legLen = step.v; legCount = stuckCount = checkTick = 0; randTimer = 100;
        lastHp = mc.player.getHealth();
        ignored.clear();
        status = "exploring";
    }

    @Override public void onDisable() {
        if (mc.player != null) Nav.release();
        if (autoBase.b && !baseWasOn && !keepBase) Modules.BASE_AI.setEnabled(false);
    }

    private void chat(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("[Goku] " + s), false); }

    private void halt(String why) {
        Nav.release(); done = true; status = "STOPPED: " + why;
        chat("Auto Explore stopped: " + why);
        Sfx.play("off", 1f);
    }

    private static boolean dangerous(BlockState st) {
        Block b = st.getBlock();
        return b == Blocks.LAVA || b == Blocks.FIRE || b == Blocks.SOUL_FIRE || b == Blocks.MAGMA_BLOCK || b == Blocks.CACTUS || b == Blocks.SWEET_BERRY_BUSH;
    }

    /** Is walking 1-2 blocks in this direction safe (no lava, no deep drop / void, optionally no water)? */
    private boolean safe(double dx, double dz) {
        var p = mc.player;
        for (int s = 1; s <= 2; s++) {
            BlockPos feet = BlockPos.ofFloored(p.getX() + dx * s, p.getY(), p.getZ() + dz * s);
            BlockState a = mc.world.getBlockState(feet), b = mc.world.getBlockState(feet.up());
            if (dangerous(a) || dangerous(b)) return false;
            if (avoidWater.b && (a.isOf(Blocks.WATER) || b.isOf(Blocks.WATER))) return false;
            int drop = 0;
            BlockPos g = feet.down();
            while (drop <= maxDrop.i()) {
                BlockState gs = mc.world.getBlockState(g);
                if (dangerous(gs)) return false;
                if (avoidWater.b && gs.isOf(Blocks.WATER)) return false;
                if (gs.isSolidBlock(mc.world, g) || gs.isOf(Blocks.WATER)) break;
                g = g.down(); drop++;
            }
            if (avoidDrops.b && drop > maxDrop.i()) return false;
        }
        return true;
    }

    private void rotate(boolean right) {
        double nx = right ? hz : -hz, nz = right ? -hx : hx;
        hx = nx; hz = nz;
    }

    @Override public void onPreTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null || Modules.FREECAM.enabled || done) return;
        var p = mc.player;
        Vec3d pos = p.getEntityPos();

        // ---- AFK safety
        if (stopHp.v > 0 && p.getHealth() + p.getAbsorptionAmount() <= stopHp.v) { halt("low health"); return; }
        if (p.getHealth() < lastHp - 0.5f) { halt("you took damage"); return; }
        lastHp = p.getHealth();
        if (stopPlayer.v > 0) for (PlayerEntity o : mc.world.getPlayers())
            if (o != p && o.distanceTo(p) <= stopPlayer.v) { halt("player nearby (" + o.getName().getString() + ")"); return; }

        // ---- base found / seek
        BaseAi.Result best = null;
        for (BaseAi.Result r : Modules.BASE_AI.ranked) {
            if (r.conf() < baseConf.v) continue;
            boolean skip = false;
            for (Vec3d i : ignored) if (Math.hypot(i.x - r.center().x, i.z - r.center().z) < 160) { skip = true; break; }
            if (!skip) { best = r; break; }
        }
        if (best != null) {
            Vec3d c = best.center();
            double hd = Math.hypot(c.x - pos.x, c.z - pos.z);
            if (hd <= stopDist.v) {
                String line = "BASE x=" + (int) c.x + " z=" + (int) c.z + " conf=" + (int) best.conf() + "% dim=" + mc.world.getRegistryKey().getValue();
                chat("Base found! " + line);
                if (log.b) try {
                    Files.createDirectories(logFile().getParent());
                    Files.writeString(logFile(), line + "\n", StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (Exception ignoredEx) {}
                Sfx.play("on", 0.8f);
                if (onFound.idx == 0) { Nav.release(); keepBase = true; done = true; status = "FOUND x=" + (int) c.x + " z=" + (int) c.z; return; }
                ignored.add(c);
                return;
            }
            double dx = (c.x - pos.x) / hd, dz = (c.z - pos.z) / hd;
            if (!safe(dx, dz)) { halt("path to base is blocked by lava or a drop"); return; }
            status = "heading to base (" + (int) hd + "m, " + (int) best.conf() + "%)";
            Nav.walk(new Vec3d(c.x, pos.y, c.z), sprint.b, true, (float) turn.v);
            return;
        }

        // ---- explore
        status = "exploring (" + pattern.modeName() + ")";
        if (pattern.idx == 0 && Math.hypot(pos.x - legStart.x, pos.z - legStart.z) >= legLen) {
            rotate(true); legStart = pos; legCount++;
            if (legCount % 2 == 0) legLen += step.v;
        }
        if (pattern.idx == 2 && --randTimer <= 0) {
            randTimer = 80 + rnd.nextInt(120);
            double a = Math.toRadians((rnd.nextBoolean() ? 1 : -1) * (30 + rnd.nextInt(60)));
            double nx = hx * Math.cos(a) - hz * Math.sin(a), nz = hx * Math.sin(a) + hz * Math.cos(a);
            hx = nx; hz = nz;
        }
        if (!safe(hx, hz)) {
            boolean ok = false;
            for (int t = 0; t < 3 && !ok; t++) {
                if (t == 0) rotate(true); else if (t == 1) { rotate(false); rotate(false); } else rotate(true);
                ok = safe(hx, hz);
            }
            if (!ok) { halt("boxed in by lava or drops"); return; }
            legStart = pos;
        }
        if (++checkTick >= 40) {
            checkTick = 0;
            if (lastPos != null && Math.hypot(pos.x - lastPos.x, pos.z - lastPos.z) < 2.0) {
                stuckCount++;
                if (stuckCount >= 3) { double a = rnd.nextDouble() * Math.PI * 2; hx = Math.cos(a); hz = Math.sin(a); stuckCount = 0; }
                else rotate(rnd.nextBoolean());
                legStart = pos;
            } else { stuckCount = 0; if (lastPos != null) walked += Math.hypot(pos.x - lastPos.x, pos.z - lastPos.z); }
            lastPos = pos;
        }
        Nav.walk(new Vec3d(pos.x + hx * 8, pos.y, pos.z + hz * 8), sprint.b, true, (float) turn.v);
    }

    @Override public void onRender(DrawContext c, float td) {
        if (hud.b) Esp.hud(c, "Auto Explore: " + status + "  |  " + (int) walked + " blocks", Modules.accent());
    }
}
