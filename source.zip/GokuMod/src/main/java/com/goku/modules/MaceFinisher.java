package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.List;

/**
 * Mace Finisher: when an enemy is low on health you throw a wind charge at your feet, fly up and over them (turning and gliding towards them),
 * then come down with the mace and finish them with one hit.
 */
public class MaceFinisher extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting hp = add(Setting.num("Target HP At or Below", 8, 1, 20, 1));
    final Setting range = add(Setting.num("Target Within", 12, 3, 30, 1));
    final Setting useWind = add(Setting.bool("Wind Charge Up", true));
    final Setting homing = add(Setting.bool("Fly Towards Target", true));
    final Setting reach = add(Setting.num("Hit Reach", 3.5, 2.5, 6, 0.1));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Setting swapBack = add(Setting.bool("Swap Back After", true));

    int state, cd, timeout, restore = -1;
    boolean keys;
    LivingEntity tgt;

    public MaceFinisher() { super("Mace Finisher"); }

    @Override public void onDisable() { stop(); }

    void stop() {
        if (keys) {
            if (!Modules.AUTO_WALK.enabled) mc.options.forwardKey.setPressed(false);
            keys = false;
        }
        state = 0; tgt = null;
        if (restore >= 0 && swapBack.b && mc.player != null) Inv.select(restore);
        restore = -1;
    }

    LivingEntity weakest() {
        List<LivingEntity> l = Targets.find(mc, LegitMode.reach(range.v), players.b, mobs.b, LegitMode.walls(walls.b));
        LivingEntity best = null;
        for (LivingEntity e : l) {
            float h = e.getHealth() + e.getAbsorptionAmount();
            if (h <= hp.v && (best == null || h < best.getHealth() + best.getAbsorptionAmount())) best = e;
        }
        return best;
    }

    @Override public void onPreTick() {
        if (mc.player == null || state != 1 || tgt == null || mc.currentScreen != null) return;
        if (homing.b && !mc.player.isOnGround()) {
            Rot.face(tgt.getEntityPos().add(0, tgt.getHeight() * 0.6, 0));
            mc.options.forwardKey.setPressed(true);
            keys = true;
        } else if (keys) {
            if (!Modules.AUTO_WALK.enabled) mc.options.forwardKey.setPressed(false);
            keys = false;
        }
    }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        if (cd > 0) cd--;
        var p = mc.player;
        if (state == 0) {
            if (cd > 0) return;
            LivingEntity t = weakest();
            if (t == null) return;
            int mace = AutoMace.bestMace(t, true, 8);
            if (mace < 0) return;
            if (p.isOnGround() && useWind.b) {
                int wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
                if (wind < 0) return;
                int prev = Inv.selected();
                float yaw = p.getYaw(), pitch = p.getPitch();
                Inv.select(wind);
                p.setPitch(90f);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.swingHand(Hand.MAIN_HAND);
                p.setYaw(yaw); p.setPitch(pitch);
                restore = prev;
            } else if (p.isOnGround()) {
                return;   // no wind charge: let Auto Mace / manual jump do the work
            } else if (restore < 0) restore = Inv.selected();
            Inv.select(mace);
            tgt = t; state = 1; timeout = 80;
            return;
        }
        // state 1: in the air, going for the kill
        if (tgt == null || !tgt.isAlive() || --timeout <= 0) { stop(); cd = 30; return; }
        int mace = AutoMace.bestMace(tgt, true, 8);
        if (mace >= 0 && Inv.selected() != mace) Inv.select(mace);
        double d = p.distanceTo(tgt);
        if (d <= LegitMode.reach(reach.v) && cd <= 0 && p.getAttackCooldownProgress(0.5f) >= 0.9f && !p.isOnGround()) {
            AutoMace.smashTick = mc.world.getTime();
            mc.interactionManager.attackEntity(p, tgt);
            p.swingHand(Hand.MAIN_HAND);
            cd = 6;
        }
        if (p.isOnGround() && timeout < 70) { stop(); cd = 30; }
    }
}
