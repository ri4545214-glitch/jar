package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Draws where an arrow, pearl, snowball, egg, trident or potion in your hand will fly. */
public class Trajectories extends Module {
    final Setting color = add(Setting.mode("Color", 4, Draw.NAMES));
    final Setting width = add(Setting.num("Line Width", 1, 1, 3, 1));

    public Trajectories() { super("Trajectories"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        var p = mc.player;
        Item it = p.getMainHandStack().getItem();
        double speed, g, drag = 0.99;
        if (it == Items.BOW) {
            if (!p.isUsingItem()) return;
            float pull = BowItem.getPullProgress(p.getItemUseTime());
            if (pull < 0.1f) return;
            speed = pull * 3.0; g = 0.05;
        } else if (it == Items.TRIDENT) { if (!p.isUsingItem()) return; speed = 2.5; g = 0.05; }
        else if (it == Items.ENDER_PEARL || it == Items.SNOWBALL || it == Items.EGG) { speed = 1.5; g = 0.03; }
        else if (it == Items.SPLASH_POTION || it == Items.LINGERING_POTION) { speed = 0.5; g = 0.05; }
        else if (it == Items.EXPERIENCE_BOTTLE) { speed = 0.7; g = 0.07; }
        else return;

        double yaw = Math.toRadians(p.getYaw()), pit = Math.toRadians(p.getPitch());
        Vec3d v = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit)).multiply(speed);
        Vec3d pos = p.getEyePos().add(0, -0.1, 0);
        int col = Draw.COLORS[color.idx];
        double[] last = Projector.to(pos);
        for (int i = 0; i < 120; i++) {
            Vec3d next = pos.add(v);
            var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            boolean end = hit.getType() == HitResult.Type.BLOCK;
            if (end) next = hit.getPos();
            double[] cur = Projector.to(next);
            if (last != null && cur != null) Draw.line(c, last[0], last[1], cur[0], cur[1], width.i(), col);
            last = cur; pos = next;
            if (end) { if (cur != null) c.fill((int) cur[0] - 2, (int) cur[1] - 2, (int) cur[0] + 3, (int) cur[1] + 3, 0xFFFFFFFF); break; }
            v = v.multiply(drag).add(0, -g, 0);
        }
    }
}
