package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Rot;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Cuts you out of a cobweb: looks at it, switches to shears / sword and mines it (a normal survival action, nothing is faked). */
public class AntiCobweb extends Module {
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting rotate = add(Setting.bool("Look At Web", true));
    int restore = -1;

    public AntiCobweb() { super("Anti Cobweb"); }

    @Override public void onDisable() { restore = -1; }

    BlockPos web() {
        BlockPos f = mc.player.getBlockPos();
        if (mc.world.getBlockState(f).isOf(Blocks.COBWEB)) return f;
        if (mc.world.getBlockState(f.up()).isOf(Blocks.COBWEB)) return f.up();
        return null;
    }

    @Override public void onTick() {
        if (mc.currentScreen != null) return;
        BlockPos w = web();
        if (w == null) {
            if (restore >= 0 && swapBack.b) Inv.select(restore);
            restore = -1;
            return;
        }
        int slot = Inv.hotbar(s -> s.isOf(Items.SHEARS));
        if (slot < 0) slot = Inv.hotbar(s -> s.isIn(ItemTags.SWORDS));
        if (slot >= 0 && Inv.selected() != slot) { if (restore < 0) restore = Inv.selected(); Inv.select(slot); }
        if (rotate.b && !Rot.face(Vec3d.ofCenter(w))) return;
        mc.interactionManager.updateBlockBreakingProgress(w, Direction.UP);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
