package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** When you are stuck in a cobweb it swaps to a sword/shears/axe and cuts it away. */
public class AntiCobweb extends Module {
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int prev = -1;

    public AntiCobweb() { super("Anti Cobweb"); }

    @Override public void onDisable() { prev = -1; }

    @Override public void onTick() {
        var p = mc.player;
        BlockPos feet = p.getBlockPos(), head = BlockPos.ofFloored(p.getX(), p.getEyeY(), p.getZ());
        BlockPos web = mc.world.getBlockState(feet).isOf(Blocks.COBWEB) ? feet : mc.world.getBlockState(head).isOf(Blocks.COBWEB) ? head : null;
        if (web == null) {
            if (prev >= 0) { if (swapBack.b) Inv.select(prev); prev = -1; }
            return;
        }
        int slot = Inv.hotbar(s -> s.isOf(Items.SHEARS) || s.isIn(ItemTags.SWORDS));
        if (slot < 0) slot = Inv.hotbar(s -> s.isIn(ItemTags.AXES));
        if (slot < 0) return;
        if (prev < 0) prev = Inv.selected();
        Inv.select(slot);
        mc.interactionManager.updateBlockBreakingProgress(web, Direction.UP);
        p.swingHand(Hand.MAIN_HAND);
    }
}
