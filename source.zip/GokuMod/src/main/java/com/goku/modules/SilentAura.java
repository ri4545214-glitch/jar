package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Random;

/**
 * CPS based aura. Silent mode sends the aim to the server only (your screen does not turn) and immediately sends your real look back.
 * With Legit Mode human aim on, it only swings at targets already within your turn limit of the crosshair.
 */
public class SilentAura extends Module {
    final Setting rotation = add(Setting.mode("Rotation", 0, "Silent", "Normal", "None"));
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Range", 3.0, 1, 6, 0.1));
    final Setting minCps = add(Setting.num("Min CPS", 12, 1, 20, 1));
    final Setting maxCps = add(Setting.num("Max CPS", 17, 1, 20, 1));
    final Setting lowHp = add(Setting.bool("Prefer Low Health", false));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Random rnd = new Random();
    double acc;

    public SilentAura() { super("Silent Aura"); }

    static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled) return;
        double lo = Math.min(minCps.v, maxCps.v), hi = Math.max(minCps.v, maxCps.v);
        acc = Math.min(acc + (lo + rnd.nextDouble() * (hi - lo)) / 20.0, 2.0);
        if (acc < 1) return;
        List<LivingEntity> t = Targets.find(mc, LegitMode.reach(range.v), players.b, mobs.b, LegitMode.walls(walls.b));
        if (t.isEmpty()) { acc = Math.min(acc, 1); return; }
        LivingEntity e = t.get(0);
        if (lowHp.b) for (LivingEntity o : t) if (o.getHealth() < e.getHealth()) e = o;

        Vec3d eye = mc.player.getEyePos();
        Box b = e.getBoundingBox();
        Vec3d pt = new Vec3d(clamp(eye.x, b.minX, b.maxX), clamp(eye.y, b.minY, b.maxY), clamp(eye.z, b.minZ, b.maxZ));
        if (b.contains(eye)) pt = b.getCenter();
        float[] r = Targets.rot(eye, pt);
        float cy = mc.player.getYaw(), cp = mc.player.getPitch();
        float dy = Targets.wrap(r[0] - cy), dp = r[1] - cp;
        float ty = r[0], tp = Math.max(-90f, Math.min(90f, r[1]));
        if (LegitMode.human() && rotation.idx != 2) {
            float m = LegitMode.maxTurn(180f);
            if (Math.abs(dy) > m || Math.abs(dp) > m) return;
            ty += LegitMode.noise(); tp += LegitMode.noise();
        }
        acc -= 1;

        if (rotation.idx == 0) {
            var h = mc.getNetworkHandler();
            h.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(ty, tp, mc.player.isOnGround(), mc.player.horizontalCollision));
            mc.interactionManager.attackEntity(mc.player, e);
            mc.player.swingHand(Hand.MAIN_HAND);
            h.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(cy, cp, mc.player.isOnGround(), mc.player.horizontalCollision));
        } else {
            if (rotation.idx == 1) { mc.player.setYaw(ty); mc.player.setPitch(tp); }
            mc.interactionManager.attackEntity(mc.player, e);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
