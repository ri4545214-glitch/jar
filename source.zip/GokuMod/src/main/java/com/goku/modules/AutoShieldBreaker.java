package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;

/** When the player under your crosshair is blocking with a shield, switches to an axe and hits, then swaps back. */
public class AutoShieldBreaker extends Module {
    final Setting back = add(Setting.bool("Swap Back", true));
    final Setting backDelay = add(Setting.num("Swap Back After (ticks)", 4, 1, 20, 1));
    final Setting walls = add(Setting.bool("Through Walls", false));
    int restore = -1, timer;

    public AutoShieldBreaker() { super("Auto Shield Breaker"); }

    @Override public void onDisable() { restore = -1; }

    @Override public void onTick() {
        if (restore >= 0 && --timer <= 0) { if (back.b) Inv.select(restore); restore = -1; }
        if (mc.currentScreen != null || !(mc.targetedEntity instanceof PlayerEntity t) || !t.isBlocking()) return;
        if (!Targets.valid(mc, t, LegitMode.reach(3.0), true, false, LegitMode.walls(walls.b))) return;
        int axe = Inv.hotbar(s -> s.isIn(ItemTags.AXES));
        if (axe < 0) return;
        if (Inv.selected() != axe) { if (restore < 0) restore = Inv.selected(); Inv.select(axe); }
        timer = backDelay.i();
        if (mc.player.getAttackCooldownProgress(0.5f) >= 0.9f) {
            mc.interactionManager.attackEntity(mc.player, t);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }
}
