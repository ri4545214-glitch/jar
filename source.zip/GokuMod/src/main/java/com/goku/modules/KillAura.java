package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public class KillAura extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", true));
    final Setting range = add(Setting.num("Range", 4, 1, 6, 0.1));
    final Setting maxTargets = add(Setting.num("Max Targets", 1, 1, 5, 1));
    final Setting waitCd = add(Setting.bool("Wait Cooldown", true));
    final Setting delay = add(Setting.num("Delay (ticks)", 10, 1, 20, 1));
    final Setting rotate = add(Setting.bool("Rotate", true));
    final Setting walls = add(Setting.bool("Through Walls", false));

    int ticks;

    public KillAura() { super("Kill Aura"); }

    @Override public void onTick() {
        if (mc.currentScreen != null) return;
        ticks++;
        boolean ready = waitCd.b ? mc.player.getAttackCooldownProgress(0.5f) >= 1f : ticks >= LegitMode.delay(delay.i());
        if (!ready) return;
        List<LivingEntity> t = Targets.find(mc, LegitMode.reach(range.v), players.b, mobs.b, LegitMode.walls(walls.b));
        if (t.isEmpty()) return;
        ticks = 0;
        for (int i = 0; i < Math.min(t.size(), maxTargets.i()); i++) {
            LivingEntity e = t.get(i);
            if (rotate.b && i == 0) {
                float[] r = Targets.rot(mc.player.getEyePos(), e.getEntityPos().add(0, e.getHeight() * 0.7, 0));
                if (LegitMode.human()) {
                    float dy = Targets.wrap(r[0] - mc.player.getYaw()), dp = r[1] - mc.player.getPitch();
                    float m = LegitMode.maxTurn(180f);
                    mc.player.setYaw(mc.player.getYaw() + Math.max(-m, Math.min(m, dy)) + LegitMode.noise());
                    mc.player.setPitch(Math.max(-90f, Math.min(90f, mc.player.getPitch() + Math.max(-m, Math.min(m, dp)) + LegitMode.noise())));
                    if (Math.abs(dy) > 12f || Math.abs(dp) > 12f) return;   // only swing once actually looking at the target
                } else { mc.player.setYaw(r[0]); mc.player.setPitch(r[1]); }
            }
            mc.interactionManager.attackEntity(mc.player, e);
        }
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
