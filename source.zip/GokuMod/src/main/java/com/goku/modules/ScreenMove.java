package com.goku.modules;

import com.goku.Module;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

/** Keep walking, jumping and sprinting while an inventory / chest screen is open. */
public class ScreenMove extends Module {
    public ScreenMove() { super("Screen Move"); }

    @Override public void onPreTick() {
        if (!(mc.currentScreen instanceof HandledScreen<?>)) return;
        long h = mc.getWindow().getHandle();
        KeyBinding[] keys = {mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey, mc.options.sprintKey};
        for (KeyBinding k : keys) {
            int code = KeyBindingHelper.getBoundKeyOf(k).getCode();
            k.setPressed(code > 0 && GLFW.glfwGetKey(h, code) == GLFW.GLFW_PRESS);
        }
    }
}
