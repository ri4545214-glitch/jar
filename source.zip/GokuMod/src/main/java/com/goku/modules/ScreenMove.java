package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.gui.ClickGui;
import com.goku.gui.ManagerGui;
import com.goku.util.Keys;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;

/** Lets you keep walking / jumping while an inventory or the Goku menu is open. Never active in chat, signs, books or the creative search box. */
public class ScreenMove extends Module {
    final Setting sneak = add(Setting.bool("Sneak", true));
    final Setting goku = add(Setting.bool("Goku Menus", true));
    final Setting inv = add(Setting.bool("Inventories", true));

    public ScreenMove() { super("Screen Move"); }

    boolean allowed(Screen s) {
        if (s instanceof CreativeInventoryScreen) return false;
        if (s instanceof HandledScreen<?>) return inv.b;
        return goku.b && (s instanceof ClickGui || s instanceof ManagerGui);
    }

    @Override public void onPreTick() {
        if (mc.currentScreen == null || !allowed(mc.currentScreen)) return;
        var o = mc.options;
        KeyBinding[] keys = {o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sprintKey};
        for (KeyBinding k : keys) k.setPressed(Keys.physical(k));
        if (sneak.b) o.sneakKey.setPressed(Keys.physical(o.sneakKey));
    }
}
