package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Pot Aim (Nethpot): aim assist for the crosshair. Holding a splash potion it steers to the spot where the potion will land (leading a moving target);
 * holding a sword / axe / mace it steers onto the enemy's body. You still do the clicking.
 */
public class PotAim extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting potions = add(Setting.bool("Aim Splash Potions", true));
    final Setting melee = add(Setting.bool("Aim Melee Weapons", true));
    final Setting potRange = add(Setting.num("Potion Range", 12, 4, 20, 1));
    final Setting meleeRange = add(Setting.num("Melee Range", 4.5, 3, 6, 0.1));
    final Setting speed = add(Setting.num("Strength", 40, 5, 100, 5));
    final Setting lead = add(Setting.num("Lead (ticks)", 4, 0, 12, 1));
    final Setting fov = add(Setting.num("Field Of View", 90, 20, 360, 10));
    final Setting needClick = add(Setting.bool("Only While Clicking", true));
    final Setting walls = add(Setting.bool("Through Walls", false));

    LivingEntity last;
    Vec3d lastPos = Vec3d.ZERO, vel = Vec3d.ZERO;

    public PotAim() { super("Pot Aim"); }

    boolean isMelee(ItemStack s) { return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE); }

    @Override public void onTick() {
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive()) return;
        var p = mc.player;
        ItemStack held = p.getMainHandStack();
        boolean pot = potions.b && held.isOf(Items.SPLASH_POTION), mel = melee.b && isMelee(held);
        if (!pot && !mel) { last = null; return; }
        double r = pot ? potRange.v : meleeRange.v;
        List<LivingEntity> ts = Targets.find(mc, r, players.b, false, LegitMode.walls(walls.b));
        LivingEntity t = null;
        for (LivingEntity e : ts) {
            float[] a = Targets.rot(p.getEyePos(), e.getEyePos());
            if (Math.abs(Targets.wrap(a[0] - p.getYaw())) <= fov.v / 2.0) { t = e; break; }
        }
        if (t != null) {
            Vec3d np = t.getEntityPos();
            vel = t == last ? np.subtract(lastPos) : Vec3d.ZERO;
            last = t; lastPos = np;
        } else { last = null; return; }
        if (needClick.b && !(pot ? mc.options.useKey.isPressed() : mc.options.attackKey.isPressed())) return;

        float yaw, pitch;
        if (pot) {
            Vec3d aim = t.getEntityPos().add(vel.multiply(lead.v)).add(0, 0.1, 0);
            float[] s = Modules.POT_THROW.solve(p.getEyePos().add(0, -0.1, 0), aim);
            if (s == null) return;
            yaw = s[0]; pitch = s[1];
        } else {
            float[] s = Targets.rot(p.getEyePos(), t.getEntityPos().add(vel.multiply(1.0)).add(0, t.getHeight() * 0.65, 0));
            yaw = s[0]; pitch = s[1];
        }
        float k = (float) (LegitMode.human() ? Math.min(speed.v, 60) : speed.v) / 100f;
        float dy = Targets.wrap(yaw - p.getYaw()), dp = pitch - p.getPitch();
        p.setYaw(p.getYaw() + dy * k + LegitMode.noise());
        p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + dp * k + LegitMode.noise())));
    }
}
