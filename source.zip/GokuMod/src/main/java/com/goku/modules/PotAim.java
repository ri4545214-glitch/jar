package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** Smooth, frame-rate independent aim assist for sword / axe / mace fights (netherite pot PvP): pulls your crosshair onto the target and leads moving targets. */
public class PotAim extends Module {
    final Setting range = add(Setting.num("Range", 4.5, 2, 8, 0.5));
    final Setting fov = add(Setting.num("FOV", 100, 20, 360, 5));
    final Setting speed = add(Setting.num("Speed (deg/s)", 220, 40, 720, 10));
    final Setting smooth = add(Setting.num("Smoothing", 8, 1, 20, 1));
    final Setting aim = add(Setting.mode("Aim At", 1, "Head", "Chest", "Closest Point"));
    final Setting predict = add(Setting.num("Lead (ticks)", 2, 0, 6, 0.5));
    final Setting vertical = add(Setting.bool("Vertical", true));
    final Setting weaponOnly = add(Setting.bool("Weapon Only", true));
    final Setting needClick = add(Setting.bool("Only While Attacking", true));
    final Setting walls = add(Setting.bool("Through Walls", false));
    final Map<Integer, Vec3d> last = new HashMap<>(), vel = new HashMap<>();
    long lastNs;

    public PotAim() { super("Pot Aim Assist"); }

    @Override public void onTick() {
        for (var e : mc.world.getEntities()) {
            Vec3d now = e.getEntityPos(), was = last.put(e.getId(), now);
            if (was != null) vel.put(e.getId(), now.subtract(was));
        }
        if (last.size() > 600) { last.clear(); vel.clear(); }
    }

    @Override public void onRender(DrawContext c, float td) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        var p = mc.player;
        if (mc.currentScreen != null || Modules_freecam()) return;
        var h = p.getMainHandStack();
        if (weaponOnly.b && !(h.isIn(ItemTags.SWORDS) || h.isIn(ItemTags.AXES) || h.isOf(Items.MACE) || h.isOf(Items.TRIDENT))) return;
        if (needClick.b && !mc.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos();
        LivingEntity best = null; float[] bestRot = null; float bestDiff = 1e9f;
        for (LivingEntity e : Targets.find(mc, LegitMode.reach(range.v), true, false, LegitMode.walls(walls.b))) {
            Vec3d v = vel.getOrDefault(e.getId(), Vec3d.ZERO).multiply(predict.v);
            Vec3d pt = switch (aim.idx) {
                case 0 -> e.getEyePos();
                case 2 -> {
                    var b = e.getBoundingBox();
                    yield new Vec3d(Math.max(b.minX, Math.min(b.maxX, eye.x)), Math.max(b.minY, Math.min(b.maxY, eye.y)), Math.max(b.minZ, Math.min(b.maxZ, eye.z)));
                }
                default -> e.getEntityPos().add(0, e.getHeight() * 0.6, 0);
            };
            float[] r = Targets.rot(eye, pt.add(v));
            float dy = Targets.wrap(r[0] - p.getYaw()), dp = r[1] - p.getPitch();
            float diff = (float) Math.sqrt(dy * dy + dp * dp);
            if (diff <= fov.v / 2 && diff < bestDiff) { best = e; bestDiff = diff; bestRot = r; }
        }
        if (best == null) return;
        float max = (float) speed.v * dt;
        if (LegitMode.human()) max = Math.min(max, LegitMode.maxTurn(max));
        float k = Math.min(1f, dt * LegitMode.smooth(21f - (float) smooth.v) * 1.6f);
        float dy = Targets.wrap(bestRot[0] - p.getYaw()) * k, dp = (bestRot[1] - p.getPitch()) * k;
        p.setYaw(p.getYaw() + Math.max(-max, Math.min(max, dy)) + (LegitMode.human() ? LegitMode.noise() * 0.2f : 0f));
        if (vertical.b) p.setPitch(Math.max(-90f, Math.min(90f, p.getPitch() + Math.max(-max, Math.min(max, dp)))));
    }

    boolean Modules_freecam() { return com.goku.Modules.FREECAM.enabled; }
}
