package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Keys;

/** Jumps the moment you take a hit on the ground, which shortens the knockback you take. */
public class AutoJumpReset extends Module {
    final Setting chance = add(Setting.num("Chance %", 100, 10, 100, 5));
    boolean forced;

    public AutoJumpReset() { super("Auto Jump Reset"); }

    @Override public void onDisable() { release(); }

    void release() {
        if (forced && mc.options != null && !Keys.physical(mc.options.jumpKey)) mc.options.jumpKey.setPressed(false);
        forced = false;
    }

    @Override public void onPreTick() {
        release();
        var p = mc.player;
        if (mc.currentScreen != null || !p.isOnGround() || p.hurtTime != 9) return;
        if (Math.random() * 100 > chance.v) return;
        mc.options.jumpKey.setPressed(true);
        forced = true;
    }
}
