package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;

import java.util.List;

/**
 * Mace Dive: whenever you are high above an enemy it equips the mace and dives onto them - turns, moves towards them in the air
 * (with a lead on moving targets) and lets Auto Mace do the smash. No wind charge needed, works with any fall (jumps from builds, pearls, elytra, wind charges).
 */
public class MaceDive extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting minHeight = add(Setting.num("Min Height Above Target", 4, 2, 30, 1));
    final Setting horiz = add(Setting.num("Horizontal Range", 12, 3, 30, 1));
    final Setting lead = add(Setting.num("Lead (ticks)", 3, 0, 10, 1));
    final Setting equip = add(Setting.bool("Equip Mace", true));
    final Setting sprint = add(Setting.bool("Sprint In Air", true));
    final Setting walls = add(Setting.bool("Through Walls", true));

    boolean keys;
    LivingEntity last;
    net.minecraft.util.math.Vec3d lastPos = net.minecraft.util.math.Vec3d.ZERO, vel = net.minecraft.util.math.Vec3d.ZERO;

    public MaceDive() { super("Mace Dive"); }

    @Override public void onDisable() { stop(); }

    void stop() {
        if (keys) {
            if (!Modules.AUTO_WALK.enabled) { mc.options.forwardKey.setPressed(false); mc.options.sprintKey.setPressed(false); }
            keys = false;
        }
    }

    @Override public void onPreTick() {
        if (mc.player == null || mc.currentScreen != null || Modules.FREECAM.enabled) return;
        var p = mc.player;
        if (p.isOnGround() || p.isTouchingWater() || p.isClimbing()) { stop(); last = null; return; }
        List<LivingEntity> l = Targets.find(mc, horiz.v + 30, players.b, mobs.b, LegitMode.walls(walls.b));
        LivingEntity t = null;
        for (LivingEntity e : l) {
            double dx = e.getX() - p.getX(), dz = e.getZ() - p.getZ();
            if (Math.hypot(dx, dz) <= horiz.v && p.getY() - e.getY() >= minHeight.v) { t = e; break; }
        }
        if (t == null) { stop(); last = null; return; }
        var np = t.getEntityPos();
        vel = t == last ? np.subtract(lastPos) : net.minecraft.util.math.Vec3d.ZERO;
        last = t; lastPos = np;
        if (equip.b) {
            int m = AutoMace.bestMace(t, true, 8);
            if (m >= 0 && Inv.selected() != m) Inv.select(m);
        }
        Rot.face(np.add(vel.multiply(lead.v)).add(0, t.getHeight() * 0.6, 0));
        mc.options.forwardKey.setPressed(true);
        if (sprint.b) mc.options.sprintKey.setPressed(true);
        keys = true;
    }
}
