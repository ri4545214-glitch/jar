package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;

import java.util.Random;

/**
 * Legit Mode: keeps the other modules inside vanilla limits (reach, speed, no wall-targeting, human-like aim and timing).
 * For testing how your own server's anti-cheat reacts. It does NOT make anything undetectable, and the module being on is the only switch:
 * the other modules call the helpers below.
 */
public class LegitMode extends Module {
    final Setting capReach = add(Setting.bool("Cap Combat Reach", true));
    final Setting reach = add(Setting.num("Max Reach", 3.0, 2.5, 4.0, 0.1));
    final Setting noWalls = add(Setting.bool("No Targeting Through Walls", true));
    final Setting humanAim = add(Setting.bool("Human-Like Aim", true));
    final Setting minSmooth = add(Setting.num("Min Aim Smoothing", 5, 2, 15, 1));
    final Setting noise = add(Setting.num("Aim Noise (deg)", 0.4, 0, 2, 0.1));
    final Setting maxTurn = add(Setting.num("Max Turn Per Tick (deg)", 30, 5, 90, 5));
    final Setting jitterDelay = add(Setting.bool("Randomize Delays", true));
    final Setting jitterMax = add(Setting.num("Delay Jitter (ticks)", 3, 0, 10, 1));
    final Setting oneBlock = add(Setting.bool("1 Block Per Tick", true));
    final Setting placeReach = add(Setting.num("Max Place Range", 4.0, 2.5, 4.5, 0.1));
    final Setting capSpeed = add(Setting.bool("Cap Speed To Vanilla", true));

    static final Random RND = new Random();

    public LegitMode() { super("Legit Mode"); }

    static boolean on() { return Modules.LEGIT.enabled; }

    public static double reach(double r) { return on() && Modules.LEGIT.capReach.b ? Math.min(r, Modules.LEGIT.reach.v) : r; }
    public static double placeReach(double r) { return on() && Modules.LEGIT.capReach.b ? Math.min(r, Modules.LEGIT.placeReach.v) : r; }
    public static boolean walls(boolean w) { return w && !(on() && Modules.LEGIT.noWalls.b); }
    public static boolean human() { return on() && Modules.LEGIT.humanAim.b; }
    public static float smooth(float s) { return human() ? Math.max(s, (float) Modules.LEGIT.minSmooth.v) : s; }
    public static float noise() { return human() ? (float) ((RND.nextDouble() * 2 - 1) * Modules.LEGIT.noise.v) : 0f; }
    public static float maxTurn(float s) { return human() ? Math.min(s, (float) Modules.LEGIT.maxTurn.v) : s; }
    public static int delay(int ticks) { return on() && Modules.LEGIT.jitterDelay.b ? ticks + RND.nextInt(Modules.LEGIT.jitterMax.i() + 1) : ticks; }
    public static int perTick(int n) { return on() && Modules.LEGIT.oneBlock.b ? 1 : n; }
    public static double speed(double v) { return on() && Modules.LEGIT.capSpeed.b ? Math.min(v, 0.28) : v; }
}
