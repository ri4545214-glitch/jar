package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.ElyUtil;
import com.goku.util.Inv;
import com.goku.util.Place;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Elytra Swap: a fall-saver. When you drop further than "Fall Distance" it wears the elytra, starts gliding (and fires a rocket if you want),
 * and when you touch ground or water it puts your chestplate back.
 */
public class ElytraSwap extends Module {
    final Setting fall = add(Setting.num("Fall Distance", 8, 4, 40, 1));
    final Setting rocket = add(Setting.bool("Firework When Gliding", false));
    final Setting back = add(Setting.bool("Chestplate Back On Landing", true));
    final Setting ignoreWater = add(Setting.bool("Skip If Water Below", true));

    Item prevChest;
    boolean wore, jumpWant, flip, held;
    int cd;

    public ElytraSwap() { super("Elytra Swap"); }

    @Override public void onDisable() { if (held) { mc.options.jumpKey.setPressed(false); held = false; } jumpWant = false; }

    @Override public void onPreTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (jumpWant) { flip = !flip; mc.options.jumpKey.setPressed(flip); held = true; }
        else if (held) { mc.options.jumpKey.setPressed(false); held = false; }
    }

    boolean waterBelow() {
        var p = mc.player.getBlockPos();
        for (int i = 1; i < 40; i++) {
            var st = mc.world.getBlockState(p.down(i));
            if (!st.isAir()) return !st.getFluidState().isEmpty();
        }
        return false;
    }

    @Override public void onTick() {
        if (mc.currentScreen != null || !mc.player.isAlive()) { jumpWant = false; return; }
        if (cd > 0) cd--;
        var p = mc.player;
        boolean ground = p.isOnGround() || p.isTouchingWater() || p.isInLava();
        if (wore && ground) {   // landed
            jumpWant = false;
            if (back.b && ElyUtil.wearing() && prevChest != null && cd <= 0) {
                final Item pc = prevChest;
                int i = ElyUtil.find(s -> s.isOf(pc));
                if (i >= 0) { ElyUtil.swapChest(i); cd = 3; }
            }
            if (!ElyUtil.wearing() || prevChest == null) wore = false;
            return;
        }
        if (ground) { jumpWant = false; return; }
        if (!ElyUtil.wearing()) {
            if (p.fallDistance < fall.v || p.getVelocity().y > -0.4 || cd > 0) return;
            if (ignoreWater.b && waterBelow()) return;
            int i = ElyUtil.find(ElyUtil::goodElytra);
            if (i < 0) return;
            var chest = p.getEquippedStack(EquipmentSlot.CHEST);
            prevChest = chest.isEmpty() ? null : chest.getItem();
            ElyUtil.swapChest(i);
            wore = true; cd = 3;
            return;
        }
        if (!ElyUtil.gliding()) { jumpWant = p.getVelocity().y < -0.05; return; }
        jumpWant = false;
        if (rocket.b && cd <= 0 && p.getVelocity().length() < 0.7) {
            int fw = Inv.hotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0) {
                int prev = Inv.selected(); Inv.select(fw);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND); p.swingHand(Hand.MAIN_HAND);
                Inv.select(prev); cd = 25;
            }
        }
    }
}
