package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Targets;
import com.goku.util.Use;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Throws an ender pearl for you: Escape (low health, enemy close -> pearl away) and/or Chase (target far -> pearl onto it, arc is simulated). */
public class AutoPearl extends Module {
    final Setting mode = add(Setting.mode("Mode", 2, "Escape", "Chase", "Both"));
    final Setting health = add(Setting.num("Escape Health <=", 8, 1, 20, 1));
    final Setting enemy = add(Setting.num("Escape If Enemy Within", 6, 2, 15, 1));
    final Setting chase = add(Setting.num("Chase If Target Farther", 18, 8, 40, 1));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 25, 20, 100, 5));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd;

    public AutoPearl() { super("Auto Pearl"); }

    /** Pitch that lands a pearl closest to the point (ballistic simulation, vanilla speed 1.5, drag 0.99, gravity 0.03). */
    static float solvePitch(Vec3d eye, Vec3d to, float yaw) {
        float best = -30f; double bd = 1e18;
        double yr = Math.toRadians(yaw);
        for (float pitch = -70f; pitch <= 15f; pitch += 1f) {
            double pr = Math.toRadians(pitch);
            Vec3d v = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(pr), Math.cos(yr) * Math.cos(pr)).multiply(1.5);
            Vec3d pos = eye.add(0, -0.1, 0);
            for (int t = 0; t < 120; t++) {
                pos = pos.add(v);
                v = v.multiply(0.99).add(0, -0.03, 0);
                double d = pos.distanceTo(to);
                if (d < bd) { bd = d; best = pitch; }
                if (pos.y < to.y - 3) break;
            }
        }
        return best;
    }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        if (mc.currentScreen != null || !mc.player.isAlive()) return;
        int slot = Inv.hotbar(s -> s.isOf(Items.ENDER_PEARL));
        if (slot < 0) return;
        List<LivingEntity> near = Targets.find(mc, 60, true, false, true);
        if (near.isEmpty()) return;
        LivingEntity t = near.get(0);
        double d = mc.player.distanceTo(t);
        Vec3d eye = mc.player.getEyePos();
        boolean escape = mode.idx != 1 && d <= enemy.v && mc.player.getHealth() + mc.player.getAbsorptionAmount() <= health.v;
        boolean chaseIt = mode.idx != 0 && d >= chase.v && mc.player.canSee(t);
        if (escape) {
            float yaw = Targets.rot(t.getEyePos(), eye)[0];   // straight away from the enemy
            Use.item(slot, yaw, -35f, swapBack.b);
        } else if (chaseIt) {
            Vec3d to = t.getEntityPos().add(0, 0.2, 0);
            float yaw = Targets.rot(eye, to)[0];
            Use.item(slot, yaw, solvePitch(eye, to, yaw), swapBack.b);
        } else return;
        cd = LegitMode.delay(cooldown.i());
    }
}
