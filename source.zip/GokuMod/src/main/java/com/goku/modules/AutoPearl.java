package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Escape pearl: when your health is low and an enemy is close, turns away from them and throws an ender pearl. */
public class AutoPearl extends Module {
    final Setting hp = add(Setting.num("Health At or Below", 8, 2, 20, 1));
    final Setting enemy = add(Setting.num("Enemy Within", 8, 3, 20, 1));
    final Setting loft = add(Setting.num("Throw Angle Up (deg)", 25, 5, 55, 1));
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int cd, active;
    float yaw;

    public AutoPearl() { super("Auto Pearl"); }

    @Override public void onDisable() { cd = active = 0; }

    @Override public void onTick() {
        if (cd > 0) { cd--; return; }
        var p = mc.player;
        if (mc.currentScreen != null) return;
        if (active <= 0) {
            if (p.getHealth() > hp.v) return;
            var near = Targets.find(mc, enemy.v, true, false, true).stream().filter(e -> !(e instanceof net.minecraft.entity.player.PlayerEntity pe && AntiBot.isBot(pe))).findFirst();
            if (near.isEmpty()) return;
            float[] r = Targets.rot(p.getEyePos(), near.get().getEyePos());
            yaw = Targets.wrap(r[0] + 180f);
            active = 20;
        }
        active--;
        int slot = Inv.hotbar(s -> s.isOf(Items.ENDER_PEARL));
        if (slot < 0) { active = 0; return; }
        if (!Rot.faceAngles(yaw, -(float) loft.v)) return;   // turns over a few ticks, throws once facing away
        int prev = Inv.selected();
        Inv.select(slot);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        if (swapBack.b) Inv.select(prev);
        cd = 60; active = 0;
    }
}
