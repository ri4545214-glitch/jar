package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Marks the closest valid target with a box so you can see who your combat modules are about to pick. */
public class TargetRenderer extends Module {
    final Setting style = add(Setting.mode("Style", 1, Esp.STYLES));
    final Setting color = add(Setting.mode("Color", 0, Draw.NAMES));
    final Setting fill = add(Setting.bool("Fill", true));
    final Setting range = add(Setting.num("Range", 8, 3, 30, 1));

    public TargetRenderer() { super("Target Renderer"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        var list = Targets.find(mc, range.v, true, false, true);
        if (list.isEmpty()) return;
        LivingEntity e = list.get(0);
        Vec3d off = e.getLerpedPos(td).subtract(e.getEntityPos());
        Box b = e.getBoundingBox().offset(off);
        Esp.box(c, b, Draw.COLORS[color.idx], style.idx, fill.b, 1);
    }
}
