package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Lines from the screen to players (and optionally hostile mobs). */
public class Tracers extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Hostile Mobs", false));
    final Setting origin = add(Setting.mode("From", 0, Esp.ORIGINS));
    final Setting width = add(Setting.num("Line Width", 1, 1, 4, 1));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));
    final Setting color = add(Setting.mode("Color", 0, Draw.NAMES));

    public Tracers() { super("Tracers"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        for (Entity e : mc.world.getEntities()) {
            boolean p = e instanceof PlayerEntity && e != mc.getCameraEntity() && !AntiBot.isBot((PlayerEntity) e);
            boolean m = e instanceof HostileEntity;
            if (!((players.b && p) || (mobs.b && m)) || !e.isAlive()) continue;
            var lp = e.getLerpedPos(td);
            if (range.v > 0 && lp.distanceTo(Projector.cam) > range.v) continue;
            Esp.tracer(c, lp.add(0, e.getHeight() / 2, 0), m ? 0xFFFF8844 : Draw.COLORS[color.idx], origin.idx, width.i());
        }
    }
}
