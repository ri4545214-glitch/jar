package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Draw;
import com.goku.util.Esp;
import com.goku.util.Projector;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Lines from the screen to players (and optionally hostile mobs). Pure rendering, nothing is sent to the server. */
public class Tracers extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting hostile = add(Setting.bool("Hostile Mobs", false));
    final Setting origin = add(Setting.mode("From", 0, Esp.ORIGINS));
    final Setting width = add(Setting.num("Line Width", 1, 1, 4, 1));
    final Setting range = add(Setting.num("Range (0=inf)", 0, 0, 500, 10));
    final Setting distColor = add(Setting.bool("Color By Distance", true));
    final Setting color = add(Setting.color("Color", 0xFF4444));

    public Tracers() { super("Tracers"); }

    @Override public void onRender(DrawContext c, float td) {
        if (!Projector.ok) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.getCameraEntity() || e == mc.player) continue;
            boolean pl = e instanceof PlayerEntity;
            if (pl ? !players.b : !(hostile.b && e instanceof HostileEntity)) continue;
            if (pl && Modules.ANTIBOT.isBot((PlayerEntity) e)) continue;
            Vec3d lp = e.getLerpedPos(td);
            double d = lp.distanceTo(Projector.cam);
            if (range.v > 0 && d > range.v) continue;
            int col = color.argb();
            if (distColor.b) { double t = Math.max(0, Math.min(1, d / 60.0)); col = 0xFF000000 | ((int) (255 * (1 - t)) << 16) | ((int) (255 * t) << 8) | 0x20; }
            Esp.tracer(c, lp.add(0, e.getHeight() / 2, 0), col, origin.idx, width.i());
        }
    }
}
