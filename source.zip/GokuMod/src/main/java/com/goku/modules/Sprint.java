package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.effect.StatusEffects;

/** Keeps you sprinting. Legit = forward only (vanilla rules). Omni sprints in every direction (strict anti-cheats flag that; ignored while Legit Mode is on). */
public class Sprint extends Module {
    final Setting mode = add(Setting.mode("Mode", 0, "Legit", "Omni"));
    final Setting inGui = add(Setting.bool("Keep While Screen Open", false));

    public Sprint() { super("Sprint"); }

    @Override public void onPreTick() {
        var p = mc.player;
        if (mc.currentScreen != null && !inGui.b) return;
        if (p.isSneaking() || p.isUsingItem() || p.isTouchingWater() || p.hasStatusEffect(StatusEffects.BLINDNESS)) return;
        if (p.getHungerManager().getFoodLevel() <= 6 && !p.getAbilities().allowFlying) return;
        var o = mc.options;
        boolean omni = mode.idx == 1 && !LegitMode.on();
        boolean move = o.forwardKey.isPressed() || (omni && (o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed()));
        if (move && !p.horizontalCollision) p.setSprinting(true);
    }
}
