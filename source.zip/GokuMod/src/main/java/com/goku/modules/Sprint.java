package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;

/** Keeps you sprinting while you walk forward. */
public class Sprint extends Module {
    final Setting hunger = add(Setting.bool("Respect Hunger", true));
    final Setting sneak = add(Setting.bool("Not While Sneaking", true));

    public Sprint() { super("Sprint"); }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !mc.options.forwardKey.isPressed()) return;
        if (sneak.b && p.isSneaking()) return;
        if (hunger.b && p.getHungerManager().getFoodLevel() <= 6) return;
        if (p.horizontalCollision || p.isUsingItem()) return;
        p.setSprinting(true);
    }
}
