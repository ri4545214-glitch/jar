package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Picks the fastest hotbar tool for the block you start mining, and swaps back when you let go. */
public class AutoTool extends Module {
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    final Setting saveTools = add(Setting.bool("Skip Nearly Broken Tools", true));
    int restore = -1;

    public AutoTool() { super("Auto Tool"); }

    @Override public void onDisable() { restore = -1; }

    @Override public void onPreTick() {
        if (mc.currentScreen != null) return;
        boolean mining = mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK;
        if (!mining) {
            if (restore >= 0 && swapBack.b) Inv.select(restore);
            restore = -1;
            return;
        }
        var pos = ((BlockHitResult) mc.crosshairTarget).getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        if (st.isAir() || st.getHardness(mc.world, pos) < 0) return;
        float bestSpeed = mc.player.getMainHandStack().getMiningSpeedMultiplier(st);
        int best = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (saveTools.b && s.getMaxDamage() > 0 && s.getMaxDamage() - s.getDamage() <= 2) continue;
            float sp = s.getMiningSpeedMultiplier(st);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        if (best >= 0 && best != Inv.selected()) { if (restore < 0) restore = Inv.selected(); Inv.select(best); }
    }
}
