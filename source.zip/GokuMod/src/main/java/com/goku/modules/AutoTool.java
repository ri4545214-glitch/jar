package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While you mine a block it switches to the fastest tool in your hotbar, then back. */
public class AutoTool extends Module {
    final Setting swapBack = add(Setting.bool("Swap Back", true));
    int prev = -1;

    public AutoTool() { super("Auto Tool"); }

    @Override public void onDisable() { prev = -1; }

    @Override public void onTick() {
        boolean mining = mc.currentScreen == null && mc.options.attackKey.isPressed()
                && mc.crosshairTarget instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK;
        if (!mining) {
            if (prev >= 0) { if (swapBack.b) Inv.select(prev); prev = -1; }
            return;
        }
        var hit = (BlockHitResult) mc.crosshairTarget;
        var st = mc.world.getBlockState(hit.getBlockPos());
        if (st.getHardness(mc.world, hit.getBlockPos()) < 0) return;
        int best = Inv.selected(); float bs = mc.player.getInventory().getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float s = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (s > bs + 0.01f) { bs = s; best = i; }
        }
        if (best != Inv.selected()) { if (prev < 0) prev = Inv.selected(); Inv.select(best); }
    }
}
