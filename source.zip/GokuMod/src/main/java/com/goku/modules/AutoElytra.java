package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Gear;
import com.goku.util.Inv;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Sky dive: once you are high enough and a player is in range it equips the elytra, glides at them, takes the elytra off when close,
 * and hits them with your mace / sword / axe as you drop.
 */
public class AutoElytra extends Module {
    final Setting minHeight = add(Setting.num("Min Height", 20, 8, 200, 1));
    final Setting range = add(Setting.num("Target Range", 100, 20, 200, 5));
    final Setting swapDist = add(Setting.num("Swap Elytra Off At", 9, 4, 30, 1));
    final Setting boost = add(Setting.bool("Boost (Firework / Wind Charge)", true));
    final Setting weapon = add(Setting.mode("Hit With", 0, "Mace", "Sword", "Axe"));
    final Setting cooldown = add(Setting.num("Cooldown (ticks)", 60, 10, 400, 10));

    enum S { IDLE, EQUIP, GLIDE, SWAP, HIT }
    S state = S.IDLE;
    LivingEntity tgt;
    Vec3d prev = Vec3d.ZERO, vel = Vec3d.ZERO;
    int t, cd;

    public AutoElytra() { super("Auto Elytra"); }

    @Override public void onDisable() { state = S.IDLE; tgt = null; }

    void finish() { state = S.IDLE; tgt = null; cd = cooldown.i(); t = 0; }

    int weaponSlot() {
        return switch (weapon.idx) {
            case 1 -> Inv.hotbar(s -> s.isIn(ItemTags.SWORDS));
            case 2 -> Inv.hotbar(s -> s.isIn(ItemTags.AXES));
            default -> Inv.hotbar(s -> s.isOf(Items.MACE));
        };
    }

    void track() {
        if (tgt == null) return;
        Vec3d now = tgt.getEntityPos();
        vel = now.subtract(prev); prev = now;
    }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !p.isAlive()) return;
        if (cd > 0) { cd--; return; }
        t++;
        track();
        switch (state) {
            case IDLE -> {
                if (p.isOnGround() || p.isGliding() || Gear.height(minHeight.v + 2) < minHeight.v) return;
                if (!Gear.has(Gear.ELYTRA) && !Gear.worn(Gear.ELYTRA)) return;
                List<LivingEntity> l = Targets.find(mc, range.v, true, false, true);
                if (l.isEmpty()) return;
                tgt = l.get(0); prev = tgt.getEntityPos(); vel = Vec3d.ZERO;
                state = S.EQUIP; t = 0;
            }
            case EQUIP -> {
                if (!Gear.equipChest(Gear.ELYTRA)) { finish(); return; }
                if (Gear.worn(Gear.ELYTRA)) { Gear.startGlide(); if (p.isGliding() || t > 4) { state = S.GLIDE; t = 0; } }
                else if (t > 20) finish();
            }
            case GLIDE -> {
                if (tgt == null || !tgt.isAlive() || p.isOnGround()) { finish(); return; }
                if (!p.isGliding() && t > 2) Gear.startGlide();
                double d = p.distanceTo(tgt);
                Vec3d aim = tgt.getEyePos().add(vel.multiply(Math.min(8.0, d / 1.6)));
                Rot.face(aim);
                if (boost.b) Modules.ELYTRA_BOOST.boostNow();
                if (d <= swapDist.v) { state = S.SWAP; t = 0; }
            }
            case SWAP -> {
                if (Gear.has(Gear.CHESTPLATE)) Gear.equipChest(Gear.CHESTPLATE); else Gear.unequipChest();
                int w = weaponSlot();
                if (w >= 0) Inv.select(w);
                state = S.HIT; t = 0;
            }
            case HIT -> {
                if (tgt == null || !tgt.isAlive() || t > 100 || (p.isOnGround() && t > 6)) { finish(); return; }
                Rot.face(tgt.getEntityPos().add(0, tgt.getHeight() * 0.6, 0));
                int w = weaponSlot();
                if (w >= 0 && Inv.selected() != w) Inv.select(w);
                if (p.distanceTo(tgt) <= 3.4 && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
                    mc.interactionManager.attackEntity(p, tgt);
                    p.swingHand(Hand.MAIN_HAND);
                    if (t > 2) finish();
                }
            }
        }
    }
}
