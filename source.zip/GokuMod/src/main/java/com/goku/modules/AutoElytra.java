package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.ElyUtil;
import com.goku.util.Esp;
import com.goku.util.Inv;
import com.goku.util.Place;
import com.goku.util.Rot;
import com.goku.util.Targets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Auto Elytra - the full elytra attack:
 * wear elytra (on the ground when you take off, or in the air once you are high) -> take off (jump + firework, wind charge or pearl)
 * -> glide at the enemy with fireworks / wind charges keeping speed and height -> close in: put the chestplate back on, take out the mace or sword and hit.
 * The HUD line shows what it is doing and why it is waiting (no elytra, no firework in the hotbar, no target ...).
 */
public class AutoElytra extends Module {
    final Setting players = add(Setting.bool("Players", true));
    final Setting mobs = add(Setting.bool("Mobs", false));
    final Setting range = add(Setting.num("Target Within", 60, 10, 150, 5));
    final Setting takeoff = add(Setting.mode("Take Off From Ground", 0, "Jump + Firework", "Wind Charge", "Ender Pearl", "Off"));
    final Setting launchMin = add(Setting.num("Take Off If Farther Than", 12, 4, 60, 1));
    final Setting startH = add(Setting.num("Or Start When Higher Than", 8, 3, 60, 1));
    final Setting boost = add(Setting.mode("Boost With", 2, "Firework", "Wind Charge", "Both"));
    final Setting minSpeed = add(Setting.num("Firework Below Speed", 0.9, 0.3, 2.0, 0.1));
    final Setting strikeAt = add(Setting.mode("At The Enemy", 0, "Swap Chestplate & Hit", "Hit While Gliding"));
    final Setting strikeDist = add(Setting.num("Strike Distance", 9, 3, 25, 1));
    final Setting weapon = add(Setting.mode("Weapon", 0, "Mace Else Sword", "Mace", "Sword"));
    final Setting reach = add(Setting.num("Hit Reach", 3.5, 2.5, 6, 0.1));
    final Setting walls = add(Setting.bool("Through Walls", true));
    final Setting hud = add(Setting.bool("Status HUD", true));

    static final int IDLE = 0, WEAR = 1, TAKEOFF = 2, GLIDE = 3, STRIKE = 4;
    int state, cd, ticks, warnCd;
    boolean jumpOnce, jumpWant, jumpHeld, flip, homeKeys;
    Item prevChest;
    LivingEntity tgt, lastT;
    Vec3d lastPos = Vec3d.ZERO, vel = Vec3d.ZERO;
    String status = "off";

    public AutoElytra() { super("Auto Elytra"); }

    @Override public void onDisable() { releaseKeys(); state = 0; tgt = null; status = "off"; }

    void releaseKeys() {
        if (jumpHeld) { mc.options.jumpKey.setPressed(false); jumpHeld = false; }
        jumpOnce = jumpWant = false;
        if (homeKeys) { if (!Modules.AUTO_WALK.enabled) { mc.options.forwardKey.setPressed(false); mc.options.sprintKey.setPressed(false); } homeKeys = false; }
    }

    void warn(String s) { status = s; if (warnCd <= 0) { Place.msg("Auto Elytra: " + s); warnCd = 80; } }

    @Override public void onPreTick() {
        if (mc.player == null || mc.currentScreen != null) return;
        if (jumpOnce) { mc.options.jumpKey.setPressed(true); jumpHeld = true; jumpOnce = false; }
        else if (jumpWant) { flip = !flip; mc.options.jumpKey.setPressed(flip); jumpHeld = true; }
        else if (jumpHeld) { mc.options.jumpKey.setPressed(false); jumpHeld = false; }
        if (state == STRIKE && tgt != null && strikeAt.idx == 0 && !mc.player.isOnGround()) {   // steer the fall onto the target
            Rot.face(tgt.getEntityPos().add(vel.multiply(2)).add(0, tgt.getHeight() * 0.5, 0));
            mc.options.forwardKey.setPressed(true); homeKeys = true;
        } else if (homeKeys && state != STRIKE) {
            if (!Modules.AUTO_WALK.enabled) mc.options.forwardKey.setPressed(false);
            homeKeys = false;
        }
    }

    void pickTarget() {
        List<LivingEntity> l = Targets.find(mc, range.v, players.b, mobs.b, LegitMode.walls(walls.b));
        tgt = l.isEmpty() ? null : l.get(0);
        if (tgt != null) {
            Vec3d np = tgt.getEntityPos();
            vel = tgt == lastT ? np.subtract(lastPos) : Vec3d.ZERO;
            lastT = tgt; lastPos = np;
        } else lastT = null;
    }

    /** Uses the item in the given hotbar slot (optionally looking straight down), then goes back to the previous slot. */
    void use(int slot, boolean down) {
        int prev = Inv.selected();
        float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
        Inv.select(slot);
        if (down) mc.player.setPitch(90f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (down) { mc.player.setYaw(yaw); mc.player.setPitch(pitch); }
        Inv.select(prev);
    }

    @Override public void onTick() {
        if (warnCd > 0) warnCd--;
        if (cd > 0) cd--;
        if (mc.currentScreen != null || Modules.FREECAM.enabled || !mc.player.isAlive() || mc.player.hasVehicle()) { jumpWant = false; return; }
        pickTarget();
        var p = mc.player;
        boolean ground = p.isOnGround();
        switch (state) {
            case IDLE -> idle(p, ground);
            case WEAR -> wear(ground);
            case TAKEOFF -> takeOff(p, ground);
            case GLIDE -> glide(p, ground);
            case STRIKE -> strike(p, ground);
            default -> state = IDLE;
        }
    }

    void idle(net.minecraft.client.network.ClientPlayerEntity p, boolean ground) {
        jumpWant = false;
        if (tgt == null) { status = "waiting for a target (" + (int) range.v + " blocks)"; return; }
        if (cd > 0) return;
        boolean haveEly = ElyUtil.wearing() || ElyUtil.find(ElyUtil::goodElytra) >= 0;
        if (!haveEly) { warn("no usable elytra in your inventory"); return; }
        double dist = p.distanceTo(tgt);
        if (!ground && !p.isTouchingWater() && ElyUtil.heightAbove() >= startH.v) { status = "high enough - wearing elytra"; state = WEAR; ticks = 0; return; }
        if (ground && takeoff.idx != 3 && dist > launchMin.v) { status = "target " + (int) dist + "m away - taking off"; state = WEAR; ticks = 0; return; }
        status = ground ? "target close (" + (int) dist + "m) - not needed" : "in the air, below " + (int) startH.v + " blocks";
    }

    void wear(boolean ground) {
        if (tgt == null) { endFlight(); return; }
        if (ElyUtil.wearing()) { state = ground ? TAKEOFF : GLIDE; ticks = 0; return; }
        if (++ticks > 30) { warn("could not put the elytra on"); endFlight(); return; }
        if (cd > 0) return;
        int i = ElyUtil.find(ElyUtil::goodElytra);
        if (i < 0) { warn("no usable elytra"); endFlight(); return; }
        var chest = mc.player.getEquippedStack(EquipmentSlot.CHEST);
        prevChest = chest.isEmpty() ? null : chest.getItem();
        ElyUtil.swapChest(i);
        status = "wearing the elytra";
        cd = 3;
    }

    void takeOff(net.minecraft.client.network.ClientPlayerEntity p, boolean ground) {
        ticks++;
        if (tgt == null || ticks > 60) { endFlight(); return; }
        if (!ground) { state = GLIDE; ticks = 0; return; }
        if (cd > 0) return;
        switch (takeoff.idx) {
            case 0 -> { status = "jumping"; jumpOnce = true; cd = 8; }
            case 1 -> {
                int wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
                if (wind < 0) { warn("no wind charge in the hotbar"); endFlight(); return; }
                status = "wind charge launch"; use(wind, true); cd = 8;
            }
            case 2 -> {
                int pearl = Inv.hotbar(s -> s.isOf(Items.ENDER_PEARL));
                if (pearl < 0) { warn("no ender pearl in the hotbar"); endFlight(); return; }
                if (!Rot.face(tgt.getEyePos().add(0, p.distanceTo(tgt) * 0.12, 0))) return;
                status = "pearl throw"; use(pearl, false); endFlight(); cd = 40;
            }
            default -> endFlight();
        }
    }

    void glide(net.minecraft.client.network.ClientPlayerEntity p, boolean ground) {
        ticks++;
        if (tgt == null) { status = "target lost"; endFlight(); return; }
        if (ticks > 500) { endFlight(); return; }
        if (ground && ticks > 10) { status = "landed"; endFlight(); return; }
        double dist = p.distanceTo(tgt);
        if (dist <= strikeDist.v) { state = STRIKE; ticks = 0; jumpWant = false; return; }

        if (!ElyUtil.gliding()) {   // a jump press while falling starts the glide
            jumpWant = !ground && p.getVelocity().y < -0.05 && ElyUtil.wearing();
            status = jumpWant ? "starting glide" : "rising...";
            return;
        }
        jumpWant = false;
        double speed = p.getVelocity().length();
        Vec3d lead = tgt.getEntityPos().add(vel.multiply(Math.min(30, dist / Math.max(0.4, speed))));
        Rot.face(lead.add(0, tgt.getHeight() * 0.6, 0));
        status = String.format("gliding to target  %dm  speed %.1f", (int) dist, speed);
        if (cd > 0) return;
        if (boost.idx != 1 && speed < minSpeed.v) {
            int fw = Inv.hotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0) { use(fw, false); cd = 22; return; }
            if (boost.idx == 0) status += "  (no firework in hotbar)";
        }
        if (boost.idx != 0 && p.getY() < tgt.getY() - 2.5) {
            int wind = Inv.hotbar(s -> s.isOf(Items.WIND_CHARGE));
            if (wind >= 0) { use(wind, true); cd = 25; }
        }
    }

    int weaponSlot() {
        int mace = Inv.hotbar(s -> s.isOf(Items.MACE));
        if (weapon.idx != 2 && mace >= 0) return mace;
        if (weapon.idx == 1) return -1;
        return Inv.hotbar(s -> s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES));
    }

    void strike(net.minecraft.client.network.ClientPlayerEntity p, boolean ground) {
        ticks++;
        if (tgt == null || ticks > 200) { status = tgt == null ? "target gone" : "timed out"; endFlight(); return; }
        // chestplate back on (takes the elytra off)
        if (strikeAt.idx == 0 && ElyUtil.wearing() && prevChest != null) {
            if (cd <= 0) {
                final Item pc = prevChest;
                int i = ElyUtil.find(s -> s.isOf(pc));
                if (i >= 0) { ElyUtil.swapChest(i); cd = 2; status = "chestplate on - dropping in"; }
                else { prevChest = null; }
            }
            if (cd > 0) return;
        }
        double dist = p.distanceTo(tgt);
        if (dist > strikeDist.v * 3 && ground) { status = "too far"; endFlight(); return; }
        int w = weaponSlot();
        if (w >= 0 && Inv.selected() != w) Inv.select(w);
        if (ElyUtil.gliding()) Rot.face(tgt.getEntityPos().add(vel.multiply(2)).add(0, tgt.getHeight() * 0.5, 0));
        else Rot.face(tgt.getEyePos().add(0, -tgt.getHeight() * 0.3, 0));
        status = String.format("attacking  %.1fm", dist);
        if (dist <= LegitMode.reach(reach.v) && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
            mc.interactionManager.attackEntity(p, tgt);
            p.swingHand(Hand.MAIN_HAND);
            if (p.getMainHandStack().isOf(Items.MACE)) AutoMace.smashTick = mc.world.getTime();
        }
        if (ground && !tgt.isAlive()) endFlight();
    }

    void endFlight() {
        releaseKeys();
        state = IDLE; ticks = 0; cd = 20;
    }

    @Override public void onRender(DrawContext c, float td) {
        if (hud.b && mc.player != null && (state != IDLE || tgt != null)) Esp.hud(c, "Auto Elytra: " + status, Modules.accent());
    }
}
