package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.mixin.MinecraftClientAccessor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Items;

/** Shortens the right-click delay (vanilla 4 ticks) for blocks and/or XP bottles. Legit Mode adds random jitter. */
public class FastPlace extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 1, 0, 4, 1));
    final Setting blocks = add(Setting.bool("Blocks", true));
    final Setting xp = add(Setting.bool("XP Bottles", true));

    public FastPlace() { super("Fast Place"); }

    @Override public void onPreTick() {
        var h = mc.player.getMainHandStack();
        if (!((blocks.b && h.getItem() instanceof BlockItem) || (xp.b && h.isOf(Items.EXPERIENCE_BOTTLE)))) return;
        try {
            MinecraftClientAccessor a = (MinecraftClientAccessor) (Object) mc;
            int d = Math.min(4, LegitMode.delay(delay.i()));
            if (a.gokuUseCd() > d) a.gokuSetUseCd(d);
        } catch (Throwable t) { setEnabled(false); }
    }
}
