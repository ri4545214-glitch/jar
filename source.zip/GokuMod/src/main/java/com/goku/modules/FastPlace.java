package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** Hold right-click to place blocks faster than vanilla's 4-tick repeat. */
public class FastPlace extends Module {
    final Setting every = add(Setting.num("Place Every (ticks)", 2, 1, 4, 1));
    int t;

    public FastPlace() { super("Fast Place"); }

    @Override public void onTick() {
        if (mc.currentScreen != null || !mc.options.useKey.isPressed()) { t = 0; return; }
        if (++t < every.i() || t % every.i() != 0) return;
        if (!(mc.player.getMainHandStack().getItem() instanceof net.minecraft.item.BlockItem)) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        if (mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit).isAccepted()) mc.player.swingHand(Hand.MAIN_HAND);
    }
}
