package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Keys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Auto step-up: when you walk into a block you cannot step onto (stairs from behind, 1 block ledges) and there is room above, it jumps for you. */
public class AutoStairs extends Module {
    final Setting needForward = add(Setting.bool("Only While Walking Forward", true));
    boolean forced;

    public AutoStairs() { super("Auto Stairs"); }

    @Override public void onDisable() { release(); }

    void release() {
        if (forced && mc.options != null && !Keys.physical(mc.options.jumpKey)) mc.options.jumpKey.setPressed(false);
        forced = false;
    }

    boolean empty(BlockPos p) { return mc.world.getBlockState(p).getCollisionShape(mc.world, p).isEmpty(); }

    @Override public void onPreTick() {
        release();
        var p = mc.player;
        if (mc.currentScreen != null || !p.isOnGround() || p.isSneaking() || !p.horizontalCollision) return;
        if (needForward.b && !mc.options.forwardKey.isPressed()) return;
        Vec3d f = Vec3d.fromPolar(0f, p.getYaw());
        BlockPos ahead = BlockPos.ofFloored(p.getX() + f.x * 0.7, p.getY(), p.getZ() + f.z * 0.7);
        var shape = mc.world.getBlockState(ahead).getCollisionShape(mc.world, ahead);
        if (shape.isEmpty() || shape.getMax(Direction.Axis.Y) <= 0.6 || shape.getMax(Direction.Axis.Y) > 1.0) return;
        if (!empty(ahead.up()) || !empty(ahead.up(2)) || !empty(p.getBlockPos().up(2))) return;
        mc.options.jumpKey.setPressed(true);
        forced = true;
    }
}
