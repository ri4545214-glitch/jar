package com.goku.modules;

import com.goku.Module;
import net.minecraft.util.math.BlockPos;

/** Hops up one-block steps (stairs, slabs, ledges) automatically while you walk forward. */
public class AutoStairs extends Module {
    public AutoStairs() { super("Auto Stairs"); }

    @Override public void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !mc.options.forwardKey.isPressed() || !p.isOnGround() || p.isSneaking()) return;
        var d = p.getHorizontalFacing();
        BlockPos ahead = p.getBlockPos().offset(d);
        var w = mc.world;
        boolean wall = !w.getBlockState(ahead).getCollisionShape(w, ahead).isEmpty();
        boolean room = w.getBlockState(ahead.up()).getCollisionShape(w, ahead.up()).isEmpty()
                && w.getBlockState(ahead.up(2)).getCollisionShape(w, ahead.up(2)).isEmpty()
                && w.getBlockState(p.getBlockPos().up(2)).getCollisionShape(w, p.getBlockPos().up(2)).isEmpty();
        if (wall && room) p.jump();
    }
}
