package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Decides who combat modules may target (Silent Aura, Kill Aura, Triggerbot, Auto Aim, ...). */
public class TargetFilter extends Module {
    final Setting teammates = add(Setting.bool("Ignore Teammates", true));
    final Setting invisible = add(Setting.bool("Ignore Invisible", false));
    final Setting sleeping = add(Setting.bool("Ignore Sleeping", false));
    final Setting creative = add(Setting.bool("Ignore Creative", true));
    final Setting naked = add(Setting.bool("Ignore Unarmored", false));
    final Setting onlyLow = add(Setting.num("Only Below HP (0=off)", 0, 0, 40, 1));

    public TargetFilter() { super("Target Filter"); }

    /** True when the entity must NOT be targeted. */
    public boolean rejects(LivingEntity e) {
        if (!enabled) return false;
        if (teammates.b && e.isTeammate(mc.player)) return true;
        if (invisible.b && e.isInvisible()) return true;
        if (onlyLow.v > 0 && e.getHealth() >= onlyLow.v) return true;
        if (e instanceof PlayerEntity p) {
            if (creative.b && p.isCreative()) return true;
            if (sleeping.b && p.isSleeping()) return true;
            if (naked.b && p.getArmor() == 0) return true;
        }
        return false;
    }
}
