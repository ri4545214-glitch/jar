package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.DeathScreen;

public class AutoRespawn extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 6, 0, 40, 1));
    int t;

    public AutoRespawn() { super("Auto Respawn"); }

    @Override public void onTick() {
        if (!(mc.currentScreen instanceof DeathScreen)) { t = 0; return; }
        if (++t > delay.i()) { mc.player.requestRespawn(); mc.setScreen(null); t = 0; }
    }
}
