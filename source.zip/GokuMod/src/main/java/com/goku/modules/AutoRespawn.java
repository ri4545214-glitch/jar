package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.client.gui.screen.DeathScreen;

/** Clicks Respawn for you after a short (humanised) delay. */
public class AutoRespawn extends Module {
    final Setting delay = add(Setting.num("Delay (ticks)", 10, 0, 60, 1));
    int wait = -1;

    public AutoRespawn() { super("Auto Respawn"); }

    @Override public void onTick() {
        if (!(mc.currentScreen instanceof DeathScreen)) { wait = -1; return; }
        if (wait < 0) wait = LegitMode.delay(delay.i());
        if (--wait <= 0) { mc.player.requestRespawn(); wait = -1; }
    }
}
