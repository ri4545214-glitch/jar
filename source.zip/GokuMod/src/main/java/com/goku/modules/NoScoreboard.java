package com.goku.modules;

import com.goku.Module;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;

/** Hides the sidebar scoreboard (client side). It comes back when you turn this off and the server resends it or you rejoin. */
public class NoScoreboard extends Module {
    public NoScoreboard() { super("No Scoreboard"); }

    @Override public void onTick() {
        if (mc.world == null) return;
        var sb = mc.world.getScoreboard();
        if (sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR) != null) sb.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, null);
    }
}
