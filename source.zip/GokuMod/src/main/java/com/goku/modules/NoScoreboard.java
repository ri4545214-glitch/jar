package com.goku.modules;

import com.goku.Module;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;

/** Hides the sidebar scoreboard (client-side only, restored when you turn it off). */
public class NoScoreboard extends Module {
    ScoreboardObjective saved;

    public NoScoreboard() { super("No Scoreboard"); }

    void hide() {
        if (mc.world == null) return;
        var sb = mc.world.getScoreboard();
        ScoreboardObjective cur = sb.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
        if (cur != null) { saved = cur; sb.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, null); }
    }

    @Override public void onPreTick() { hide(); }
    @Override public void onTick() { hide(); }

    @Override public void onDisable() {
        if (saved != null && mc.world != null) mc.world.getScoreboard().setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, saved);
        saved = null;
    }
}
