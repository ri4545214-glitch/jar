package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import net.minecraft.entity.player.PlayerEntity;

/** Ignores fake players (NPCs, staff-check bots) in every targeting module, ESP and Tracers. */
public class AntiBot extends Module {
    final Setting tab = add(Setting.bool("Must Be In Tab List", true));
    final Setting uuid = add(Setting.bool("Skip NPC UUIDs (v2)", true));
    final Setting name = add(Setting.bool("Skip Invalid Names", true));

    public AntiBot() { super("Anti Bot"); }

    public boolean isBot(PlayerEntity e) {
        if (!enabled || e == mc.player || mc.getNetworkHandler() == null) return false;
        if (tab.b && mc.getNetworkHandler().getPlayerListEntry(e.getUuid()) == null) return true;
        if (uuid.b && e.getUuid().version() == 2) return true;
        return name.b && !e.getName().getString().matches("[.A-Za-z0-9_ ]{1,17}");
    }
}
