package com.goku.modules;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import net.minecraft.entity.player.PlayerEntity;

/** Makes the targeting modules ignore fake players (NPCs / bot entities that are not in the tab list). */
public class AntiBot extends Module {
    final Setting tab = add(Setting.bool("Must Be In Tab List", true));
    final Setting name = add(Setting.bool("Valid Name Only", true));

    public AntiBot() { super("Anti Bot"); }

    public static boolean isBot(PlayerEntity p) {
        if (!Modules.ANTI_BOT.enabled) return false;
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.getNetworkHandler() == null) return false;
        if (Modules.ANTI_BOT.tab.b && mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) == null) return true;
        if (Modules.ANTI_BOT.name.b && !p.getName().getString().matches("[A-Za-z0-9_]{1,16}")) return true;
        return false;
    }
}
