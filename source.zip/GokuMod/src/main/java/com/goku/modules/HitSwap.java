package com.goku.modules;

import com.goku.Module;
import com.goku.Setting;
import com.goku.util.Inv;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;

/** Puts the right weapon in your hand the moment you hit something, and optionally swaps back. */
public class HitSwap extends Module {
    final Setting weapon = add(Setting.mode("Weapon", 0, "Best", "Sword", "Axe", "Mace"));
    final Setting back = add(Setting.bool("Swap Back", false));
    final Setting backDelay = add(Setting.num("Swap Back After (ticks)", 6, 1, 40, 1));
    int restore = -1, timer;

    public HitSwap() { super("Hit Swap"); }

    @Override public void onDisable() { restore = -1; }

    int pick() {
        int sword = Inv.hotbar(s -> s.isIn(ItemTags.SWORDS)), axe = Inv.hotbar(s -> s.isIn(ItemTags.AXES)), mace = Inv.hotbar(s -> s.isOf(Items.MACE));
        return switch (weapon.idx) {
            case 1 -> sword; case 2 -> axe; case 3 -> mace;
            default -> (mace >= 0 && mc.player.fallDistance >= 1.5f) ? mace : (sword >= 0 ? sword : (axe >= 0 ? axe : mace));
        };
    }

    public void onAttack(Entity e) {
        if (!(e instanceof LivingEntity)) return;
        int s = pick();
        if (s < 0 || s == Inv.selected()) { timer = backDelay.i(); return; }
        if (restore < 0) restore = Inv.selected();
        Inv.select(s);
        timer = backDelay.i();
    }

    @Override public void onTick() {
        if (restore >= 0 && back.b && --timer <= 0) { Inv.select(restore); restore = -1; }
        else if (!back.b) restore = -1;
    }
}
