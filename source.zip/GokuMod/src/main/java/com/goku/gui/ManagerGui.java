package com.goku.gui;

import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.modules.SkinChanger;
import com.goku.modules.Waypoints;
import com.goku.util.Draw;
import com.goku.util.Sfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Manager: a second window for the "personal" features - Waypoints, Practice Bot, Skin and Cape.
 * Every section scrolls (mouse wheel or drag the scrollbar). Open it with Right Shift or the Manager button in the main menu.
 */
public class ManagerGui extends Screen {
    static final String[] TABS = {"Waypoints", "Practice Bot", "Skin", "Cape"};
    static final float[] SCROLL = new float[8];
    static int tab;
    static boolean allDims;
    static Waypoints.Wp selWp;

    static final class Pane {
        final int id; final int x1, y1, x2, y2; float maxScroll; int thumbY, thumbH;
        Pane(int id, int x1, int y1, int x2, int y2) { this.id = id; this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; }
        boolean has(double mx, double my) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }
    }

    static final class H {
        int x1, y1, x2, y2; Runnable left, right; Setting slider; Pane drag; boolean field;
    }

    final List<H> hits = new ArrayList<>();
    final List<Pane> panes = new ArrayList<>();
    final Map<Object, Float> hover = new HashMap<>();
    final ParticleField field = new ParticleField();

    // per-frame drawing state
    DrawContext g;
    int mx, my, cy, accent, accent2;
    float dt, e, open, time, tabAnim = -1;
    long lastNs = System.nanoTime();

    // interaction state
    H activeSlider;
    Pane dragPane;
    static final Map<String, StringBuilder> BUF = new HashMap<>();
    String focusId, botStatus = "";
    boolean focusSpace, focusBlurCommit;
    int focusMax;
    Consumer<String> focusCommit;
    float statusT;

    public ManagerGui() { super(Text.literal("Goku mod's Manager")); }

    // ---------------------------------------------------------------- small helpers
    static int ca(int argb, float f) { return ClickGui.ca(argb, f); }
    static int mix(int a, int b, float t) { return ClickGui.mix(a, b, t); }
    static void rr(DrawContext c, int x1, int y1, int x2, int y2, int col) { ClickGui.rr(c, x1, y1, x2, y2, col); }
    static float approach(float v, float to, float dt, float speed) { return ClickGui.approach(v, to, dt, speed); }

    boolean in(int x1, int y1, int x2, int y2) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }

    float hv(Object key, boolean on) {
        float v = approach(hover.getOrDefault(key, 0f), on ? 1 : 0, dt, 16);
        hover.put(key, v);
        return v;
    }

    void txt(String s, int x, int y, int col) { g.drawText(textRenderer, s, x, y, ca(col, e), false); }
    void txtS(String s, int x, int y, int col) { g.drawText(textRenderer, s, x, y, ca(col, e), true); }

    String fit(String s, int maxW) {
        if (textRenderer.getWidth(s) <= maxW) return s;
        while (s.length() > 1 && textRenderer.getWidth(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    void msg(String s) { if (client != null && client.player != null) client.player.sendMessage(Text.literal("[Goku] " + s), true); }

    // ---------------------------------------------------------------- bot bridge (reflection: the bot may be excluded from the build)
    static Class<?> botCfg() { try { return Class.forName("com.goku.bot.BotConfig"); } catch (Throwable t) { return null; } }

    static String botGet(String f) {
        try { return String.valueOf(botCfg().getField(f).get(null)); } catch (Throwable t) { return ""; }
    }

    static void botSet(String f, Object v) {
        try {
            Class<?> c = botCfg();
            c.getField(f).set(null, v);
            c.getMethod("save").invoke(null);
            c.getMethod("load").invoke(null);
        } catch (Throwable ignored) {}
    }

    static String botState() {
        try { return String.valueOf(Class.forName("com.goku.bot.BotBrain").getMethod("status").invoke(null)); } catch (Throwable t) { return ""; }
    }

    static Setting find(Module m, String name) {
        if (m != null) for (Setting s : m.settings) if (s.name.equals(name)) return s;
        return null;
    }

    void respawnBot() {
        Module bot = Modules.BOT;
        Setting rs = find(bot, "> Respawn Bot");
        if (bot != null && bot.enabled && rs != null) rs.b = true;
    }

    // ---------------------------------------------------------------- lifecycle
    @Override protected void init() {
        field.resize(width, height);
        open = 0;
        Sfx.play("open", 1f);
    }

    @Override public void removed() {
        blur(true);
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }

    // ---------------------------------------------------------------- scroll panes
    Pane pane(int id, int x1, int y1, int x2, int y2) { return new Pane(id, x1, y1, x2, y2); }

    void begin(Pane p) {
        panes.add(p);
        g.enableScissor(p.x1, p.y1, p.x2, p.y2);
        cy = p.y1 + 5 - (int) SCROLL[p.id];
    }

    void end(Pane p) {
        g.disableScissor();
        int view = p.y2 - p.y1;
        float content = cy - (p.y1 + 5 - SCROLL[p.id]) + 6;
        p.maxScroll = Math.max(0, content - view);
        SCROLL[p.id] = Math.max(0, Math.min(SCROLL[p.id], p.maxScroll));
        if (p.maxScroll > 0) {
            p.thumbH = Math.max(18, (int) (view * (view / content)));
            p.thumbY = p.y1 + (int) ((view - p.thumbH) * (SCROLL[p.id] / p.maxScroll));
            g.fill(p.x2 - 4, p.y1 + 1, p.x2 - 1, p.y2 - 1, ca(0xFF1A1A24, e));
            boolean hot = dragPane == p || in(p.x2 - 7, p.thumbY, p.x2, p.thumbY + p.thumbH);
            g.fill(p.x2 - 4, p.thumbY, p.x2 - 1, p.thumbY + p.thumbH, ca(hot ? accent : mix(0xFF3A3A4E, accent, 0.4f), e));
            H h = new H();
            h.x1 = p.x2 - 8; h.x2 = p.x2; h.y1 = p.thumbY; h.y2 = p.thumbY + p.thumbH; h.drag = p;
            hits.add(h);
        } else p.thumbH = 0;
    }

    /** Registers a click area, clipped to the pane so scrolled-out widgets can not be clicked. */
    H hit(Pane p, int x1, int y1, int x2, int y2, Runnable left) {
        H h = new H();
        h.x1 = x1; h.x2 = x2; h.y1 = Math.max(y1, p.y1); h.y2 = Math.min(y2, p.y2); h.left = left;
        if (h.y2 <= h.y1) return null;
        hits.add(h);
        return h;
    }

    boolean hover(Pane p, int x1, int y1, int x2, int y2) {
        return p.has(mx, my) && in(x1, y1, x2, y2);
    }

    // ---------------------------------------------------------------- widgets
    void button(Pane p, int x, int y, int w, int h, String label, boolean primary, Runnable r) {
        boolean hov = hover(p, x, y, x + w, y + h);
        float k = hv(p.id + label + x + "," + y, hov);
        int base = primary ? mix(0xFF262636, accent, 0.45f) : 0xFF1E1E2A;
        rr(g, x, y, x + w, y + h, ca(mix(base, accent, k * 0.5f), e));
        g.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, ca(0xFFFFFFFF, e), false);
        hit(p, x, y, x + w, y + h, () -> { Sfx.play("click", 1.1f); r.run(); });
    }

    void pill(int x, int y, float on) {
        int w = 22, h = 11;
        rr(g, x, y, x + w, y + h, ca(mix(0xFF2A2A38, accent, on), e));
        int kx = x + 1 + (int) ((w - h) * on);
        rr(g, kx, y + 1, kx + h - 2, y + h - 1, ca(0xFFFFFFFF, e));
    }

    void header(Pane p, int x, int w, String t) {
        cy += 4;
        txtS(t, x, cy, accent);
        g.fillGradient(x + textRenderer.getWidth(t) + 6, cy + 4, x + w, cy + 5, ca(accent, 0.5f * e), ca(accent2, 0.0f));
        cy += 14;
    }

    void moduleToggle(Pane p, int x, int w, Module m, String label) {
        boolean hov = hover(p, x, cy, x + w, cy + 20);
        float k = hv(m, m.enabled);
        rr(g, x, cy, x + w, cy + 20, ca(mix(0xFF181822, 0xFF22222F, hv("mt" + m.name, hov)), e));
        txt(label, x + 8, cy + 6, 0xFFE6E6F2);
        pill(x + w - 30, cy + 4, k);
        final int yy = cy;
        hit(p, x, yy, x + w, yy + 20, () -> { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); });
        cy += 24;
    }

    /** A text box. Enter commits; clicking elsewhere commits only when blurCommit is set; Esc cancels. */
    void textField(Pane p, String id, int x, int y, int w, String current, int max, boolean space, boolean blurCommit, Consumer<String> commit) {
        StringBuilder b = BUF.computeIfAbsent(id, k -> new StringBuilder());
        boolean foc = id.equals(focusId);
        if (!foc) { b.setLength(0); b.append(current); }
        rr(g, x, y, x + w, y + 18, ca(foc ? 0xFF262638 : 0xFF14141C, e));
        Draw.outline(g, x, y, x + w, y + 18, ca(foc ? accent : 0xFF2C2C3C, e));
        String s = b.toString() + (foc && (System.currentTimeMillis() / 450) % 2 == 0 ? "_" : "");
        while (s.length() > 1 && textRenderer.getWidth(s) > w - 10) s = s.substring(1);
        g.drawText(textRenderer, s, x + 5, y + 5, ca(foc ? 0xFFFFFFFF : 0xFFC8C8DC, e), false);
        H h = hit(p, x, y, x + w, y + 18, () -> setFocus(id, max, space, blurCommit, commit));
        if (h != null) h.field = true;
    }

    void setFocus(String id, int max, boolean space, boolean blurCommit, Consumer<String> commit) {
        if (id.equals(focusId)) return;
        blur(false);
        focusId = id; focusMax = max; focusSpace = space; focusBlurCommit = blurCommit; focusCommit = commit;
    }

    /** Leaves the focused text box; commits when enter is true or the box commits on blur. */
    void blur(boolean enter) {
        if (focusId == null) return;
        String id = focusId; Consumer<String> c = focusCommit; boolean bc = focusBlurCommit;
        focusId = null; focusCommit = null;
        if ((enter || bc) && c != null) { StringBuilder b = BUF.get(id); if (b != null) c.accept(b.toString()); }
    }

    void settingRow(Pane p, int x, int w, Setting s) {
        if (s.name.startsWith(">")) {
            button(p, x, cy, w, 18, s.name.substring(1).trim(), false, () -> s.b = true);
            cy += 22;
            return;
        }
        boolean hov = hover(p, x, cy, x + w, cy + (s.type == Setting.Type.NUM ? 28 : 20));
        float k = hv(s, hov);
        switch (s.type) {
            case BOOL -> {
                rr(g, x, cy, x + w, cy + 20, ca(mix(0xFF181822, 0xFF22222F, k), e));
                txt(fit(s.name, w - 44), x + 8, cy + 6, 0xFFDADAEA);
                float on = approach(s.anim < 0 ? (s.b ? 1 : 0) : s.anim, s.b ? 1 : 0, dt, 14);
                s.anim = on;
                pill(x + w - 30, cy + 4, on);
                hit(p, x, cy, x + w, cy + 20, () -> { s.b = !s.b; Sfx.play(s.b ? "on" : "off", 1f); });
                cy += 22;
            }
            case MODE -> {
                rr(g, x, cy, x + w, cy + 20, ca(mix(0xFF181822, 0xFF22222F, k), e));
                String v = "< " + s.modeName() + " >";
                int vw = textRenderer.getWidth(v);
                txt(fit(s.name, w - vw - 24), x + 8, cy + 6, 0xFFDADAEA);
                txt(v, x + w - vw - 8, cy + 6, accent);
                H h = hit(p, x, cy, x + w, cy + 20, () -> { s.cycle(); Sfx.play("click", 1.2f); });
                if (h != null) h.right = () -> { s.idx = (s.idx - 1 + s.modes.length) % s.modes.length; Sfx.play("click", 0.9f); };
                cy += 22;
            }
            case NUM -> {
                rr(g, x, cy, x + w, cy + 28, ca(mix(0xFF181822, 0xFF22222F, k), e));
                String val = s.step >= 1 ? String.valueOf((int) Math.round(s.v)) : String.format("%.2f", s.v);
                txt(fit(s.name, w - 50), x + 8, cy + 4, 0xFFDADAEA);
                txt(val, x + w - textRenderer.getWidth(val) - 8, cy + 4, accent);
                int sx1 = x + 8, sx2 = x + w - 8, sy = cy + 18;
                float t = (float) ((s.v - s.min) / (s.max - s.min));
                g.fill(sx1, sy, sx2, sy + 4, ca(0xFF0C0C12, e));
                int fx = sx1 + (int) ((sx2 - sx1) * Math.max(0, Math.min(1, t)));
                g.fillGradient(sx1, sy, Math.max(sx1 + 1, fx), sy + 4, ca(accent, e), ca(accent2, e));
                g.fill(fx - 1, sy - 2, fx + 2, sy + 6, ca(0xFFFFFFFF, e));
                H h = hit(p, sx1 - 4, cy + 12, sx2 + 4, cy + 27, null);
                if (h != null) { h.slider = s; h.x1 = sx1; h.x2 = sx2; }
                cy += 30;
            }
        }
    }

    // ---------------------------------------------------------------- render
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime(); dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        Modules.THEME.sync(); Modules.GUI_STYLE.sync();
        time += dt; open = Modules.GUI_STYLE.anims.b ? Math.min(1, open + dt * 3.4f) : 1;
        e = ClickGui.ease(open);
        g = ctx; mx = mouseX; my = mouseY;
        accent = Modules.accent(); accent2 = Modules.accent2();
        hits.clear(); panes.clear();

        float dimK = (float) (Modules.GUI_STYLE.dim.v / 100.0);
        ctx.fillGradient(0, 0, width, height, ClickGui.rgba(0x000000, dimK * e), ca(accent, 0.30f * (dimK / 0.66f) * e));
        if (Modules.GUI_STYLE.particles.b) field.render(ctx, dt, accent, mx, my);

        int ww = Math.min(width - 12, Math.max(520, Modules.GUI_STYLE.width.i() + 20)), wh = Math.min(height - 12, Math.max(320, Modules.GUI_STYLE.height.i() + 8));
        int wx = ClickGui.anchorX(width, ww), wy = (height - wh) / 2 + (int) ((1 - e) * 16);
        ClickGui.chrome(ctx, wx, wy, ww, wh, e, accent);

        drawTop(wx, wy, ww);
        int bx1 = wx + 1, bx2 = wx + ww - 1, by1 = wy + 46, by2 = wy + wh - 20;
        ctx.fill(bx1, by1, bx2, by2, ca(0xFF13131B, 0.98f * ClickGui.op() * e));
        switch (tab) {
            case 0 -> drawWaypoints(bx1, by1, bx2, by2);
            case 1 -> drawBot(bx1, by1, bx2, by2);
            case 2 -> drawLibrary(bx1, by1, bx2, by2, false);
            default -> drawLibrary(bx1, by1, bx2, by2, true);
        }
        drawFooter(wx, wy + wh - 20, ww);
        ClickGui.frame(ctx, wx, wy, ww, wh, e, accent, accent2);
    }

    void drawTop(int wx, int wy, int ww) {
        String t = "MANAGER"; int tx = wx + 10;
        for (int i = 0; i < t.length(); i++) {
            String ch = String.valueOf(t.charAt(i));
            float k = (float) (Math.sin(time * 3 + i * 0.7) * 0.5 + 0.5);
            g.drawText(textRenderer, ch, tx, wy + 7, ca(mix(accent, accent2, k), e), true);
            tx += textRenderer.getWidth(ch) + 1;
        }
        txt("waypoints  |  practice bot  |  skin  |  cape", tx + 10, wy + 7, 0xFF5E5E76);
        // close
        boolean ch = in(wx + ww - 22, wy + 3, wx + ww - 4, wy + 19);
        rr(g, wx + ww - 22, wy + 3, wx + ww - 4, wy + 19, ca(mix(0xFF22222E, 0xFFAA3344, hv("close", ch)), e));
        txt("x", wx + ww - 15, wy + 8, 0xFFFFFFFF);
        H x = new H(); x.x1 = wx + ww - 22; x.y1 = wy + 3; x.x2 = wx + ww - 4; x.y2 = wy + 19; x.left = this::close; hits.add(x);

        // tabs
        int tw = (ww - 16) / TABS.length, ty = wy + 25;
        if (tabAnim < 0) tabAnim = tab;
        tabAnim = approach(tabAnim, tab, dt, 14);
        for (int i = 0; i < TABS.length; i++) {
            int x1 = wx + 8 + i * tw;
            boolean hov = in(x1, ty, x1 + tw - 2, ty + 18);
            float k = hv("tab" + i, hov || i == tab);
            rr(g, x1, ty, x1 + tw - 2, ty + 18, ca(mix(0xFF16161F, 0xFF242434, k), e));
            String n = TABS[i];
            txt(n, x1 + (tw - 2 - textRenderer.getWidth(n)) / 2, ty + 5, i == tab ? 0xFFFFFFFF : 0xFFA0A0B8);
            final int idx = i;
            H h = new H(); h.x1 = x1; h.y1 = ty; h.x2 = x1 + tw - 2; h.y2 = ty + 18;
            h.left = () -> { blur(true); tab = idx; Sfx.play("click", 1.2f); };
            hits.add(h);
        }
        int ux = wx + 8 + (int) (tabAnim * tw);
        g.fillGradient(ux, ty + 17, ux + tw - 2, ty + 19, ca(accent, e), ca(accent2, e));
    }

    void drawFooter(int wx, int y, int ww) {
        g.fillGradient(wx + 1, y, wx + ww - 1, y + 1, ca(accent, 0.4f * e), ca(accent2, 0.4f * e));
        String hint = switch (tab) {
            case 0 -> "click a waypoint to edit it  |  scroll: mouse wheel";
            case 1 -> "singleplayer only  |  also: /gokubot help  |  scroll: mouse wheel";
            default -> "local only: only you see this  |  names come from Mojang";
        };
        txt(hint, wx + 8, y + 6, 0xFF6E6E86);
        String[] labels = {"Menu", "Close"};
        int bx = wx + ww - 8;
        for (int i = labels.length - 1; i >= 0; i--) {
            String l = labels[i];
            int bw = textRenderer.getWidth(l) + 12;
            bx -= bw;
            boolean hov = in(bx, y + 2, bx + bw, y + 18);
            rr(g, bx, y + 2, bx + bw, y + 18, ca(mix(0xFF22222E, accent, hv("fb" + i, hov) * 0.6f), e));
            txt(l, bx + 6, y + 6, 0xFFFFFFFF);
            H h = new H(); h.x1 = bx; h.y1 = y + 2; h.x2 = bx + bw; h.y2 = y + 18;
            final boolean menu = i == 0;
            h.left = () -> { Sfx.play("click", 1f); if (menu) client.setScreen(new ClickGui()); else close(); };
            hits.add(h);
            bx -= 4;
        }
    }

    // ---------------------------------------------------------------- tab: waypoints
    void addWaypoint() {
        if (client == null || client.player == null) return;
        Waypoints.Wp w = new Waypoints.Wp();
        w.dim = Modules.WAYPOINTS.currentDim();
        w.color = Draw.COLORS[4];
        w.x = client.player.getBlockX(); w.y = client.player.getBlockY(); w.z = client.player.getBlockZ();
        int n = 1;
        for (Waypoints.Wp o : Waypoints.list()) if (o.dim.equals(w.dim)) n++;
        w.name = "WP " + n;
        Waypoints.list().add(w);
        Waypoints.save();
        selWp = w;
        msg("Waypoint added");
    }

    void drawWaypoints(int bx1, int by1, int bx2, int by2) {
        boolean narrow = bx2 - bx1 < 400;
        int split = narrow ? bx2 - bx1 - 6 : (int) ((bx2 - bx1) * 0.52);
        Pane L = pane(0, bx1 + 6, by1 + 4, bx1 + split, by2 - 4);
        Pane R = narrow ? null : pane(1, bx1 + split + 6, by1 + 4, bx2 - 6, by2 - 4);
        if (selWp != null && !Waypoints.list().contains(selWp)) selWp = null;
        String dim = Modules.WAYPOINTS.currentDim();

        rr(g, L.x1, L.y1, L.x2, L.y2, ca(0xFF0F0F16, e));
        begin(L);
        int x = L.x1 + 6, w = L.x2 - L.x1 - 16;
        int bw = (w - 4) / 2;
        button(L, x, cy, bw, 18, "+ Add Here", true, this::addWaypoint);
        button(L, x + bw + 4, cy, bw, 18, allDims ? "Showing: All" : "Showing: Here", false, () -> allDims = !allDims);
        cy += 24;
        List<Waypoints.Wp> shown = new ArrayList<>();
        for (Waypoints.Wp wp : Waypoints.list()) if (allDims || wp.dim.equals(dim)) shown.add(wp);
        txt(shown.size() + " waypoint" + (shown.size() == 1 ? "" : "s"), x, cy, 0xFF7A7A92);
        cy += 14;
        if (shown.isEmpty()) {
            txt("None yet. Stand where you want a", x, cy + 4, 0xFF5E5E76);
            txt("marker and press \"+ Add Here\".", x, cy + 16, 0xFF5E5E76);
            cy += 34;
        }
        for (Waypoints.Wp wp : shown) {
            boolean sel = wp == selWp;
            boolean hov = hover(L, x, cy, x + w, cy + 28);
            rr(g, x, cy, x + w, cy + 28, ca(mix(0xFF181822, accent, sel ? 0.35f : hv(wp, hov) * 0.18f), e));
            g.fill(x, cy + 3, x + 3, cy + 25, ca(wp.color, e));
            txtS(fit(wp.name, w - 16), x + 9, cy + 4, 0xFFFFFFFF);
            String d = "";
            if (client != null && client.player != null && wp.dim.equals(dim)) d = "  " + (int) Math.sqrt(client.player.squaredDistanceTo(wp.x + 0.5, wp.y + 0.5, wp.z + 0.5)) + "m";
            String where = wp.dim.contains("|") ? wp.dim.substring(wp.dim.indexOf('|') + 1).replace("minecraft:", "") : wp.dim;
            txt(fit(wp.x + ", " + wp.y + ", " + wp.z + d + (allDims ? "  " + where : ""), w - 16), x + 9, cy + 16, 0xFF8A8AA2);
            hit(L, x, cy, x + w, cy + 28, () -> { selWp = wp; Sfx.play("click", 1.3f); });
            cy += 31;
        }
        if (narrow) waypointDetail(L, x, w);
        end(L);

        if (R != null) {
            rr(g, R.x1, R.y1, R.x2, R.y2, ca(0xFF0F0F16, e));
            begin(R);
            waypointDetail(R, R.x1 + 6, R.x2 - R.x1 - 16);
            end(R);
        }
    }

    void waypointDetail(Pane p, int x, int w) {
        Module wm = Modules.WAYPOINTS;
        if (p.id == 0) header(p, x, w, "Selected");   // narrow layout: details sit under the list
        moduleToggle(p, x, w, wm, "Show waypoints in the world");
        Waypoints.Wp s = selWp;
        if (s == null) {
            txt("Select a waypoint on the left", x, cy + 2, 0xFF5E5E76);
            cy += 20;
        } else {
            header(p, x, w, "Edit waypoint");
            txt("Name", x, cy, 0xFF8A8AA2); cy += 11;
            textField(p, "wp.name", x, cy, w, s.name, 24, true, true, v -> {
                v = v.trim();
                if (!v.isEmpty()) { s.name = v; Waypoints.save(); }
            });
            cy += 24;
            txt("Position", x, cy, 0xFF8A8AA2); cy += 11;
            txtS("X " + s.x + "   Y " + s.y + "   Z " + s.z, x + 2, cy, 0xFFFFFFFF); cy += 14;
            // nudge buttons
            int nb = (w - 8) / 3;
            String[] ax = {"X", "Y", "Z"};
            for (int i = 0; i < 3; i++) {
                final int a = i;
                int bx = x + i * (nb + 4);
                button(p, bx, cy, nb / 2 - 1, 16, ax[i] + "-", false, () -> nudge(s, a, -1));
                button(p, bx + nb / 2 + 1, cy, nb / 2 - 1, 16, ax[i] + "+", false, () -> nudge(s, a, 1));
            }
            cy += 22;
            txt("Color", x, cy, 0xFF8A8AA2); cy += 11;
            int sw = Math.min(18, (w - 7 * 4) / 8);
            for (int i = 0; i < Draw.COLORS.length; i++) {
                int sx = x + i * (sw + 4);
                boolean cur = s.color == Draw.COLORS[i];
                g.fill(sx - (cur ? 1 : 0), cy - (cur ? 1 : 0), sx + sw + (cur ? 1 : 0), cy + 14 + (cur ? 1 : 0), ca(cur ? 0xFFFFFFFF : 0xFF000000, e));
                g.fill(sx, cy, sx + sw, cy + 14, ca(Draw.COLORS[i], e));
                final int col = Draw.COLORS[i];
                hit(p, sx, cy, sx + sw, cy + 14, () -> { s.color = col; Waypoints.save(); Sfx.play("click", 1.4f); });
            }
            cy += 22;
            int hb = (w - 4) / 2;
            button(p, x, cy, hb, 18, "Set To Here", false, () -> {
                if (client != null && client.player != null) { s.x = client.player.getBlockX(); s.y = client.player.getBlockY(); s.z = client.player.getBlockZ(); s.dim = Modules.WAYPOINTS.currentDim(); Waypoints.save(); }
            });
            button(p, x + hb + 4, cy, hb, 18, "Copy Coords", false, () -> {
                if (client != null) client.keyboard.setClipboard(s.x + " " + s.y + " " + s.z);
                msg("Copied " + s.x + " " + s.y + " " + s.z);
            });
            cy += 22;
            button(p, x, cy, w, 18, "Delete Waypoint", false, () -> { Waypoints.list().remove(s); Waypoints.save(); selWp = null; msg("Deleted " + s.name); });
            cy += 24;
        }
        header(p, x, w, "Display");
        for (Setting st : wm.settings) if (!st.name.startsWith(">")) settingRow(p, x, w, st);
    }

    static void nudge(Waypoints.Wp s, int axis, int d) {
        int step = 1;
        if (axis == 0) s.x += d * step; else if (axis == 1) s.y += d * step; else s.z += d * step;
        Waypoints.save();
    }

    // ---------------------------------------------------------------- tab: practice bot
    void drawBot(int bx1, int by1, int bx2, int by2) {
        Pane P = pane(2, bx1 + 6, by1 + 4, bx2 - 6, by2 - 4);
        rr(g, P.x1, P.y1, P.x2, P.y2, ca(0xFF0F0F16, e));
        begin(P);
        int x = P.x1 + 8, w = P.x2 - P.x1 - 20;
        Module bot = Modules.BOT;
        if (bot == null) {
            txt("The Practice Bot is not part of this build.", x, cy + 6, 0xFF8A8AA2);
            txt("(build with enable_bot=true)", x, cy + 20, 0xFF5E5E76);
            cy += 40;
            end(P);
            return;
        }
        statusT -= dt;
        if (statusT <= 0) { statusT = 0.5f; botStatus = bot.enabled ? botState() : "off"; }

        header(P, x, w, "Bot");
        moduleToggle(P, x, w, bot, "Practice bot active");
        boolean sp = client != null && client.isInSingleplayer();
        txt(sp ? "Status: " + botStatus : "Open a singleplayer world to use the bot.", x, cy, sp ? 0xFF9A9AB4 : 0xFFE0A050);
        cy += 14;
        int b3 = (w - 8) / 3;
        button(P, x, cy, b3, 18, bot.enabled ? "Respawn" : "Spawn", true, () -> { if (!bot.enabled) bot.setEnabled(true); else respawnBot(); });
        button(P, x + b3 + 4, cy, b3, 18, "Remove", false, () -> bot.setEnabled(false));
        Setting rk = find(bot, "> Re-Kit Bot");
        button(P, x + 2 * (b3 + 4), cy, b3, 18, "Re-Kit", false, () -> { if (rk != null) rk.b = true; });
        cy += 24;

        Setting style = find(bot, "Fight Style");
        if (style != null) {
            header(P, x, w, "Fight style");
            int sb = (w - 8) / style.modes.length;
            for (int i = 0; i < style.modes.length; i++) {
                final int idx = i;
                boolean cur = style.idx == i;
                button(P, x + i * (sb + 4), cy, sb, 20, style.modes[i], cur, () -> { style.idx = idx; respawnBot(); });
            }
            cy += 26;
        }

        header(P, x, w, "Identity");
        int lw = 44, fx = x + lw, fw = w - lw;
        txt("Name", x, cy + 5, 0xFF8A8AA2);
        textField(P, "bot.name", fx, cy, fw, botGet("name"), 24, true, true, v -> botSet("name", v.trim()));
        cy += 22;
        txt("Skin", x, cy + 5, 0xFF8A8AA2);
        textField(P, "bot.skin", fx, cy, fw, botGet("skin"), 16, false, true, v -> botSet("skin", v.trim()));
        cy += 22;
        txt("Cape", x, cy + 5, 0xFF8A8AA2);
        String capeNow = botGet("cape");
        textField(P, "bot.cape", fx, cy, fw, capeNow.equals("null") ? "" : capeNow, 16, false, true, v -> botSet("cape", v.trim()));
        cy += 22;
        txt("Account names. Leave cape empty for none. Press Enter to save.", x, cy, 0xFF5E5E76);
        cy += 14;
        int h2 = (w - 4) / 2;
        boolean showName = !"false".equals(botGet("showName"));
        button(P, x, cy, h2, 18, "Apply & Respawn", true, () -> { blur(true); respawnBot(); });
        button(P, x + h2 + 4, cy, h2, 18, "Name Tag: " + (showName ? "On" : "Off"), false, () -> botSet("showName", !showName));
        cy += 24;

        Map<String, String> groups = Map.of("Difficulty", "Behaviour", "Armor Protection Lvl", "Kit", "Mace Density", "Style tuning", "Splash Pots", "Nethpot");
        for (Setting s : bot.settings) {
            if (s == style || s.name.startsWith(">")) continue;
            if (groups.containsKey(s.name)) header(P, x, w, groups.get(s.name));
            settingRow(P, x, w, s);
        }
        end(P);
    }

    // ---------------------------------------------------------------- tab: skin / cape library
    void drawLibrary(int bx1, int by1, int bx2, int by2, boolean cape) {
        Pane P = pane(cape ? 4 : 3, bx1 + 6, by1 + 4, bx2 - 6, by2 - 4);
        rr(g, P.x1, P.y1, P.x2, P.y2, ca(0xFF0F0F16, e));
        begin(P);
        int x = P.x1 + 8, w = P.x2 - P.x1 - 20;
        SkinChanger sc = Modules.SKIN;
        List<String> list = cape ? sc.capeList() : sc.skinList();
        String cur = cape ? sc.currentCape() : sc.currentSkin();
        String noun = cape ? "cape" : "skin";

        header(P, x, w, cape ? "Cape library" : "Skin library");
        moduleToggle(P, x, w, sc, "Skin & cape changer active");
        txt("Wearing " + noun + ": " + (cur == null ? "your own" : cur) + (sc.enabled ? "" : "  (changer is off)"), x, cy, 0xFF9A9AB4);
        cy += 16;

        txt("Add an account name to the library", x, cy, 0xFF8A8AA2); cy += 11;
        int aw = 46;
        textField(P, "lib.add" + cape, x, cy, w - aw - 4, "", 16, false, false, v -> addEntry(sc, cape, v));
        button(P, x + w - aw, cy, aw, 18, "Add", true, () -> {
            StringBuilder b = BUF.get("lib.add" + cape);
            if (b != null) addEntry(sc, cape, b.toString());
        });
        cy += 26;

        // "keep mine"
        libRow(P, x, w, sc, cape, null, cur == null);
        for (String n : new ArrayList<>(list)) libRow(P, x, w, sc, cape, n, n.equals(cur));
        end(P);
    }

    void addEntry(SkinChanger sc, boolean cape, String v) {
        String n = v == null ? "" : v.trim();
        if (sc.addEntry(cape, n)) { msg("Added " + n); BUF.remove("lib.add" + cape); }
        else msg("Enter a valid, new account name (max 16 letters/digits/_)");
    }

    void libRow(Pane p, int x, int w, SkinChanger sc, boolean cape, String name, boolean active) {
        boolean hov = hover(p, x, cy, x + w, cy + 24);
        float k = hv("lib" + cape + name, hov);
        rr(g, x, cy, x + w, cy + 24, ca(mix(0xFF181822, accent, active ? 0.30f : k * 0.15f), e));
        if (active) g.fill(x, cy + 3, x + 3, cy + 21, ca(accent, e));
        String label = name == null ? "(keep my own)" : name;
        final int rowY = cy;
        txtS(fit(label, w - 120), x + 9, rowY + 8, active ? 0xFFFFFFFF : 0xFFDADAEA);
        hit(p, x, rowY, x + w, rowY + 24, () -> { sc.use(cape, name); Sfx.play("click", 1.3f); });
        if (name != null) {
            int bx = x + w - 6;
            // remove
            bx -= 18;
            drawSmall(p, bx, rowY + 4, 18, 16, "x", () -> { sc.removeEntry(cape, name); Sfx.play("off", 1f); });
            if (Modules.BOT != null) {
                bx -= 40;
                drawSmall(p, bx, rowY + 4, 36, 16, "Bot", () -> {
                    botSet(cape ? "cape" : "skin", name);
                    respawnBot();
                    msg("Practice bot " + (cape ? "cape" : "skin") + ": " + name);
                });
            }
            bx -= 38;
            drawSmall(p, bx, rowY + 4, 34, 16, active ? "On" : "Use", () -> { sc.use(cape, name); Sfx.play("on", 1f); });
        }
        cy += 27;
    }

    void drawSmall(Pane p, int x, int y, int w, int h, String label, Runnable r) {
        boolean hov = hover(p, x, y, x + w, y + h);
        rr(g, x, y, x + w, y + h, ca(mix(0xFF242434, accent, hv(p.id + label + x + "," + y, hov) * 0.6f), e));
        g.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, ca(0xFFFFFFFF, e), false);
        hit(p, x, y, x + w, y + h, r);
    }

    // ---------------------------------------------------------------- input
    void setSlider(H h, double mouse) {
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (mouse - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round(v / s.step) * s.step));
    }

    void dragScroll(Pane p, double my) {
        int view = p.y2 - p.y1;
        if (p.maxScroll <= 0 || view - p.thumbH <= 0) return;
        double t = (my - p.y1 - p.thumbH / 2.0) / (view - p.thumbH);
        SCROLL[p.id] = (float) (Math.max(0, Math.min(1, t)) * p.maxScroll);
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double cx = click.x(), cyy = click.y(); int btn = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            H h = hits.get(i);
            if (cx < h.x1 || cx >= h.x2 || cyy < h.y1 || cyy >= h.y2) continue;
            if (!h.field) blur(true);
            if (h.drag != null) { if (btn == 0) { dragPane = h.drag; dragScroll(h.drag, cyy); } }
            else if (h.slider != null) { if (btn == 0) { activeSlider = h; setSlider(h, cx); Sfx.play("click", 1.4f); } }
            else if (btn == 0 && h.left != null) h.left.run();
            else if (btn == 1 && h.right != null) h.right.run();
            return true;
        }
        blur(true);
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragPane != null) { dragScroll(dragPane, click.y()); return true; }
        if (activeSlider != null) { setSlider(activeSlider, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        activeSlider = null; dragPane = null;
        return super.mouseReleased(click);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (Pane p : panes) {
            if (p.has(mouseX, mouseY)) {
                SCROLL[p.id] = Math.max(0, Math.min(p.maxScroll, SCROLL[p.id] - (float) verticalAmount * 22f));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    char keyChar(int k, int mods) {
        boolean sh = (mods & GLFW.GLFW_MOD_SHIFT) != 0;
        if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) return (char) ((sh ? 'A' : 'a') + (k - GLFW.GLFW_KEY_A));
        if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9 && !sh) return (char) ('0' + (k - GLFW.GLFW_KEY_0));
        if (k >= GLFW.GLFW_KEY_KP_0 && k <= GLFW.GLFW_KEY_KP_9) return (char) ('0' + (k - GLFW.GLFW_KEY_KP_0));
        if (k == GLFW.GLFW_KEY_MINUS) return sh ? '_' : '-';
        if (k == GLFW.GLFW_KEY_SPACE && focusSpace) return ' ';
        return 0;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (focusId != null) {
            StringBuilder b = BUF.computeIfAbsent(focusId, x -> new StringBuilder());
            if (k == GLFW.GLFW_KEY_ESCAPE) { focusId = null; focusCommit = null; return true; }
            if (k == GLFW.GLFW_KEY_ENTER || k == GLFW.GLFW_KEY_KP_ENTER) { blur(true); return true; }
            if (k == GLFW.GLFW_KEY_BACKSPACE) { if (b.length() > 0) b.setLength(b.length() - 1); return true; }
            char c = keyChar(k, input.modifiers());
            if (c != 0 && b.length() < focusMax) b.append(c);
            return true;
        }
        if (k == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(input);
    }
}
