package com.goku.gui;

import com.goku.Config;
import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Sfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Goku mod's control centre: a single centred window with a category sidebar, a searchable module list and a settings pane.
 * Left click a row = toggle, right click / gear = open its settings. Type to search. Works on small screens (icon-only sidebar,
 * settings open as a full page).
 */
public class ClickGui extends Screen {
    // ---- persistent state (survives closing/reopening)
    static int cat = 1;
    static Module sel;
    static float listScroll, setScroll;
    static String query = "";

    static final int ROW = 24, GAP = 3;

    static class Hit {
        int x1, y1, x2, y2; Runnable left, right; Setting slider;
        Hit(int x1, int y1, int x2, int y2) { this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2; }
    }

    final List<Hit> hits = new ArrayList<>();
    final Map<Object, Float> hover = new HashMap<>();
    final ParticleField field = new ParticleField();
    Hit activeSlider;
    boolean compactSettings;
    float open, time, listH, setH;
    long lastNs = System.nanoTime();
    // geometry of the scroll areas (set every frame)
    int listX1, listY1, listX2, listY2, setX1, setY1, setX2, setY2;

    public ClickGui() { super(Text.literal("Goku mod's")); }

    // ---------------------------------------------------------------- data
    static List<String> catNames() {
        List<String> l = new ArrayList<>(List.of("Active", "Base", "Combat", "Movement", "Automation", "Mods"));
        if (!Modules.BOTS.isEmpty()) l.add("Practice Bot");
        l.add("Settings");
        return l;
    }

    static List<Module> catMods(String n) {
        return switch (n) {
            case "Active" -> { List<Module> l = new ArrayList<>(); for (Module m : Modules.ALL) if (m.enabled && m.toggleable) l.add(m); yield l; }
            case "Base" -> Modules.BASE;
            case "Combat" -> Modules.COMBAT;
            case "Movement" -> Modules.MOVEMENT;
            case "Automation" -> Modules.AUTOMATION;
            case "Mods" -> Modules.MODS;
            case "Practice Bot" -> Modules.BOTS;
            default -> List.of(Modules.THEME, Modules.PARTICLES, Modules.SOUND, Modules.CONFIG);
        };
    }

    static List<Module> searchResults() {
        String q = query.toLowerCase();
        Set<Module> out = new LinkedHashSet<>();
        for (Module m : Modules.EVERY) {
            if (m.name.toLowerCase().contains(q)) out.add(m);
            else for (Setting s : m.settings) if (s.name.toLowerCase().contains(q)) { out.add(m); break; }
        }
        return new ArrayList<>(out);
    }

    List<Module> current() {
        if (!query.isEmpty()) return searchResults();
        List<String> n = catNames();
        cat = Math.max(0, Math.min(cat, n.size() - 1));
        return catMods(n.get(cat));
    }

    // ---------------------------------------------------------------- lifecycle
    @Override protected void init() {
        field.resize(width, height);
        open = 0;
        Sfx.play("open", 1f);
        Sfx.guiOpen = true;
    }

    @Override public void removed() {
        if (Modules.CONFIG.auto.b) Config.save(Modules.CONFIG.profile.modeName());
        Sfx.guiOpen = false;
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }

    // ---------------------------------------------------------------- helpers
    static int ca(int argb, float f) { return ((int) (((argb >>> 24) & 255) * Math.max(0, Math.min(1, f))) << 24) | (argb & 0xFFFFFF); }
    static int rgba(int rgb, float a) { return ((int) (255 * Math.max(0, Math.min(1, a))) << 24) | (rgb & 0xFFFFFF); }
    static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
    static float ease(float t) { t = Math.max(0, Math.min(1, t)); return 1 - (1 - t) * (1 - t) * (1 - t); }
    static float approach(float v, float to, float dt, float speed) { return v + (to - v) * Math.min(1f, dt * speed); }

    /** Rectangle with small cut corners (reads as rounded at normal GUI scales). */
    static void rr(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        if (x2 - x1 < 5 || y2 - y1 < 5) { c.fill(x1, y1, x2, y2, col); return; }
        c.fill(x1 + 2, y1, x2 - 2, y2, col);
        c.fill(x1 + 1, y1 + 1, x2 - 1, y2 - 1, col);
        c.fill(x1, y1 + 2, x2, y2 - 2, col);
    }

    float hv(Object key, boolean on, float dt) {
        float v = hover.getOrDefault(key, 0f);
        v = approach(v, on ? 1 : 0, dt, 16);
        hover.put(key, v);
        return v;
    }

    String fit(String s, int maxW) {
        if (textRenderer.getWidth(s) <= maxW) return s;
        while (s.length() > 1 && textRenderer.getWidth(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    boolean in(int mx, int my, int x1, int y1, int x2, int y2) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }

    void switchPill(DrawContext c, int x, int y, float on, int accent, int accent2, float e) {
        int w = 22, h = 11;
        rr(c, x, y, x + w, y + h, ca(mix(0xFF2A2A38, accent, on), e));
        int kx = x + 1 + (int) ((w - h) * on);
        rr(c, kx, y + 1, kx + h - 2, y + h - 1, ca(0xFFFFFFFF, e));
    }

    // ---------------------------------------------------------------- render
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime(); float dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        time += dt; open = Math.min(1, open + dt * 3.4f);
        float eo = ease(open);
        int accent = Modules.accent(), accent2 = Modules.accent2();
        hits.clear();

        // backdrop
        ctx.fillGradient(0, 0, width, height, rgba(0x000000, 0.66f * eo), ca(accent, 0.30f * eo));
        field.render(ctx, dt, accent, mx, my);

        // window geometry
        int ww = Math.min(width - 12, 620), wh = Math.min(height - 12, 372);
        int wx = (width - ww) / 2, wy = (height - wh) / 2 + (int) ((1 - eo) * 16);
        boolean compact = ww < 440;
        int sbW = compact ? 28 : 108, topH = 28, botH = 18;
        int bx = wx + sbW, by = wy + topH, bw = ww - sbW, bh = wh - topH - botH;
        int setW = compact ? 0 : Math.min(200, bw / 2 + 10);
        boolean overlay = compact && compactSettings && sel != null;

        // shadow + window
        for (int i = 5; i >= 1; i--) rr(ctx, wx - i, wy - i, wx + ww + i, wy + wh + i, ca(0xFF000000, 0.07f * eo));
        rr(ctx, wx, wy, wx + ww, wy + wh, ca(0xFF0E0E14, 0.97f * eo));
        ctx.fill(wx + sbW, wy + topH, wx + ww - 1, wy + wh - botH, ca(0xFF13131B, 0.98f * eo));
        ctx.fill(wx + 1, wy + 1, wx + sbW, wy + wh - 1, ca(0xFF0A0A10, 0.98f * eo));

        drawTop(ctx, wx, wy, ww, topH, accent, accent2, eo, mx, my, dt);
        drawSidebar(ctx, wx, wy + topH, sbW, wh - topH, compact, accent, accent2, eo, mx, my, dt);

        // list + settings
        List<Module> mods = current();
        if (!overlay) {
            listX1 = bx + 6; listY1 = by + 4; listX2 = bx + bw - setW - (compact ? 6 : 0); listY2 = by + bh - 2;
            drawList(ctx, mods, accent, accent2, eo, mx, my, dt, compact);
        }
        if (!compact || overlay) {
            setX1 = overlay ? bx + 6 : bx + bw - setW + 2; setX2 = bx + bw - 6; setY1 = by + 4; setY2 = by + bh - 2;
            drawSettings(ctx, accent, accent2, eo, mx, my, dt, overlay);
        }
        drawFooter(ctx, wx, wy + wh - botH, ww, botH, accent, accent2, eo, mx, my, dt);

        // accent frame
        ctx.fillGradient(wx, wy, wx + ww, wy + 1, ca(accent, eo), ca(accent2, eo));
    }

    void drawTop(DrawContext c, int wx, int wy, int ww, int h, int accent, int accent2, float e, int mx, int my, float dt) {
        String t = "GOKU"; int tx = wx + 10, ty = wy + 6;
        for (int i = 0; i < t.length(); i++) {
            String ch = String.valueOf(t.charAt(i));
            float k = (float) (Math.sin(time * 3 + i * 0.7) * 0.5 + 0.5);
            c.drawText(textRenderer, ch, tx, ty, ca(mix(accent, accent2, k), e), true);
            tx += textRenderer.getWidth(ch) + 1;
        }
        c.drawText(textRenderer, "mod's  control centre", tx + 3, ty, ca(0xFF8A8AA0, e), false);
        // search box
        int sw = Math.min(150, ww / 3), sx = wx + ww - sw - 10, sy = wy + 5;
        rr(c, sx, sy, sx + sw, sy + 17, ca(0xFF1A1A24, e));
        boolean has = !query.isEmpty();
        String shown = has ? query : "type to search...";
        String caret = ((int) (time * 2) % 2 == 0) ? "_" : " ";
        c.drawText(textRenderer, fit(shown, sw - 18) + (has ? caret : ""), sx + 6, sy + 5, ca(has ? 0xFFFFFFFF : 0xFF6A6A80, e), false);
        if (has) {
            c.drawText(textRenderer, "x", sx + sw - 10, sy + 5, ca(0xFFAAAAAA, e), false);
            Hit h2 = new Hit(sx + sw - 16, sy, sx + sw, sy + 17);
            h2.left = () -> { query = ""; listScroll = 0; Sfx.play("click", 0.9f); };
            hits.add(h2);
        }
        c.fillGradient(wx + 1, wy + h - 1, wx + ww - 1, wy + h, ca(accent, 0.55f * e), ca(accent2, 0.55f * e));
    }

    void drawSidebar(DrawContext c, int x, int y, int w, int h, boolean compact, int accent, int accent2, float e, int mx, int my, float dt) {
        List<String> names = catNames();
        int yy = y + 8;
        for (int i = 0; i < names.size(); i++) {
            String n = names.get(i);
            boolean selected = query.isEmpty() && i == cat;
            boolean hov = in(mx, my, x + 3, yy, x + w - 3, yy + 24);
            float hvv = hv("cat" + i, hov, dt), sv = hv("catsel" + i, selected, dt);
            rr(c, x + 4, yy, x + w - 4, yy + 24, ca(mix(0xFF0A0A10, 0xFF1C1C28, Math.max(hvv * 0.6f, sv)), e));
            if (sv > 0.02f) { c.fillGradient(x + 3, yy + 3, x + 5, yy + 21, ca(accent, e * sv), ca(accent2, e * sv)); }
            // icon tile
            int ix = x + 9, iy = yy + 5;
            if (selected) c.fillGradient(ix, iy, ix + 14, iy + 14, ca(accent, e), ca(accent2, e));
            else rr(c, ix, iy, ix + 14, iy + 14, ca(0xFF22222E, e));
            c.drawText(textRenderer, n.substring(0, 1), ix + 4, iy + 3, ca(0xFFFFFFFF, e), false);
            if (!compact) {
                c.drawText(textRenderer, n, x + 28, yy + 8, ca(selected ? 0xFFFFFFFF : mix(0xFFA0A0B8, 0xFFFFFFFF, hvv), e), selected);
                int cnt = 0;
                List<Module> ml = catMods(n);
                if (!n.equals("Settings")) for (Module m : ml) if (m.enabled && m.toggleable) cnt++;
                if (cnt > 0) {
                    String s = String.valueOf(cnt);
                    int bw = textRenderer.getWidth(s) + 8;
                    rr(c, x + w - bw - 8, yy + 6, x + w - 8, yy + 18, ca(accent, 0.85f * e));
                    c.drawText(textRenderer, s, x + w - bw - 4, yy + 8, ca(0xFFFFFFFF, e), false);
                }
            }
            final int ci = i;
            Hit hit = new Hit(x + 3, yy, x + w - 3, yy + 24);
            hit.left = () -> { cat = ci; query = ""; listScroll = 0; compactSettings = false; Sfx.play("click", 1.1f); };
            hits.add(hit);
            yy += 27;
        }
    }

    void drawList(DrawContext c, List<Module> mods, int accent, int accent2, float e, int mx, int my, float dt, boolean compact) {
        int x1 = listX1, x2 = listX2, y1 = listY1, y2 = listY2;
        c.enableScissor(x1 - 2, y1, x2 + 2, y2);
        int y = y1 + 2 - (int) listScroll;
        if (mods.isEmpty()) {
            Draw2.centered(c, textRenderer, query.isEmpty() ? "Nothing enabled yet" : "No matches", (x1 + x2) / 2, y1 + 30, ca(0xFF6A6A80, e));
        }
        for (Module m : mods) {
            m.anim = approach(m.anim, m.enabled ? 1 : 0, dt, 14);
            if (y + ROW > y1 && y < y2) {
                boolean hov = in(mx, my, x1, Math.max(y, y1), x2, Math.min(y + ROW, y2));
                float hvv = hv(m, hov, dt);
                boolean selected = m == sel;
                rr(c, x1, y, x2, y + ROW, ca(mix(0xFF181822, 0xFF21212E, hvv), e));
                if (m.anim > 0.01f) c.fillGradient(x1 + 2, y + 1, x1 + 2 + (int) ((x2 - x1 - 4) * 0.0f) + 3, y + ROW - 1, ca(accent, e * m.anim), ca(accent2, e * m.anim));
                if (m.anim > 0.01f) c.fillGradient(x1 + 4, y, x2 - 2, y + ROW, ca(accent, 0.10f * e * m.anim), ca(accent2, 0.04f * e * m.anim));
                if (selected) com.goku.util.Draw.outline(c, x1, y, x2, y + ROW, ca(accent, 0.8f * e));
                c.drawText(textRenderer, fit(m.name, x2 - x1 - 70), x1 + 10, y + 4, ca(m.enabled || !m.toggleable ? 0xFFFFFFFF : mix(0xFFC0C0D4, 0xFFFFFFFF, hvv), e), m.enabled);
                String sub = m.toggleable ? (m.enabled ? "enabled" : "disabled") + "  -  " + m.settings.size() + " settings" : m.settings.size() + " settings";
                c.drawText(textRenderer, fit(sub, x2 - x1 - 70), x1 + 10, y + 14, ca(m.enabled ? mix(0xFF8A8AA0, accent, 0.5f) : 0xFF6A6A80, e), false);
                int rx = x2 - 8;
                if (m.toggleable) { switchPill(c, rx - 22, y + 6, m.anim, accent, accent2, e); rx -= 34; }
                c.drawText(textRenderer, "...", rx - 10, y + 6, ca(selected ? accent : mix(0xFF7A7A90, 0xFFFFFFFF, hvv), e), false);

                int hy1 = Math.max(y, y1), hy2 = Math.min(y + ROW, y2);
                Hit gear = new Hit(rx - 16, hy1, x2, hy2);
                gear.left = () -> openSettings(m);
                gear.right = () -> openSettings(m);
                // gear sits left of the switch; the switch itself toggles
                Hit body = new Hit(x1, hy1, x2, hy2);
                body.left = () -> { if (m.toggleable) { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); } else openSettings(m); if (sel == null) sel = m; };
                body.right = () -> openSettings(m);
                hits.add(body);
                Hit g2 = new Hit(rx - 16, hy1, rx + 6, hy2);
                g2.left = () -> openSettings(m); g2.right = () -> openSettings(m);
                hits.add(g2);
            }
            y += ROW + GAP;
        }
        listH = y + (int) listScroll - y1 + 4;
        c.disableScissor();
        float maxScroll = Math.max(0, listH - (y2 - y1));
        listScroll = Math.max(0, Math.min(maxScroll, listScroll));
        if (maxScroll > 0) {
            int th = Math.max(16, (int) ((y2 - y1) * (y2 - y1) / listH));
            int ty = y1 + (int) ((y2 - y1 - th) * (listScroll / maxScroll));
            c.fill(x2 + 1, ty, x2 + 3, ty + th, ca(accent, 0.8f * e));
        }
    }

    void openSettings(Module m) {
        sel = m; setScroll = 0; compactSettings = true; Sfx.play("click", 1.2f);
    }

    void drawSettings(DrawContext c, int accent, int accent2, float e, int mx, int my, float dt, boolean overlay) {
        int x1 = setX1, x2 = setX2, y1 = setY1, y2 = setY2;
        rr(c, x1, y1, x2, y2, ca(0xFF0F0F16, e));
        if (sel == null) { Draw2.centered(c, textRenderer, "Select a module", (x1 + x2) / 2, y1 + 40, ca(0xFF6A6A80, e)); Draw2.centered(c, textRenderer, "right click or tap ...", (x1 + x2) / 2, y1 + 54, ca(0xFF55556A, e)); return; }
        Module m = sel;
        // header
        c.fillGradient(x1 + 1, y1 + 1, x2 - 1, y1 + 24, ca(accent, 0.28f * e), ca(accent2, 0.10f * e));
        int hx = x1 + 8;
        if (overlay) {
            c.drawText(textRenderer, "< Back", hx, y1 + 8, ca(0xFFFFFFFF, e), false);
            Hit back = new Hit(x1, y1, x1 + 50, y1 + 24);
            back.left = () -> { compactSettings = false; Sfx.play("click", 0.9f); };
            hits.add(back);
            hx += 50;
        }
        c.drawText(textRenderer, fit(m.name, x2 - hx - 40), hx, y1 + 8, ca(0xFFFFFFFF, e), true);
        if (m.toggleable) {
            switchPill(c, x2 - 30, y1 + 7, m.anim, accent, accent2, e);
            Hit th = new Hit(x2 - 34, y1, x2, y1 + 24);
            th.left = () -> { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); };
            hits.add(th);
        }
        int top = y1 + 28;
        c.enableScissor(x1, top, x2, y2 - 1);
        int y = top - (int) setScroll;
        int cx1 = x1 + 8, cx2 = x2 - 8;
        for (Setting s : m.settings) {
            switch (s.type) {
                case BOOL -> {
                    int h = 20;
                    boolean btn = s.name.startsWith(">");
                    if (btn) {
                        if (y + h > top && y < y2) {
                            boolean hov = in(mx, my, cx1, Math.max(y, top), cx2, Math.min(y + h, y2));
                            float hvv = hv(s, hov, dt);
                            float flash = hv("flash" + System.identityHashCode(s), s.b, dt);
                            rr(c, cx1, y + 1, cx2, y + h - 1, ca(mix(mix(0xFF22222E, accent, 0.35f), accent, Math.max(hvv * 0.5f, flash)), e));
                            Draw2.centered(c, textRenderer, fit(s.name.substring(1).trim(), cx2 - cx1 - 8), (cx1 + cx2) / 2, y + 6, ca(0xFFFFFFFF, e));
                            Hit b = new Hit(cx1, Math.max(y, top), cx2, Math.min(y + h, y2));
                            b.left = () -> { s.b = true; Sfx.play("on", 1.1f); };
                            hits.add(b);
                        }
                    } else if (y + h > top && y < y2) {
                        if (s.anim < 0) s.anim = s.b ? 1 : 0;
                        s.anim = approach(s.anim, s.b ? 1 : 0, dt, 18);
                        boolean hov = in(mx, my, cx1, Math.max(y, top), cx2, Math.min(y + h, y2));
                        if (hv(s, hov, dt) > 0.05f) rr(c, cx1 - 3, y, cx2 + 3, y + h, ca(0xFF191923, e * hv(s, hov, dt)));
                        c.drawText(textRenderer, fit(s.name, cx2 - cx1 - 32), cx1, y + 6, ca(0xFFD8D8E8, e), false);
                        switchPill(c, cx2 - 22, y + 4, s.anim, accent, accent2, e);
                        Hit b = new Hit(cx1 - 3, Math.max(y, top), cx2 + 3, Math.min(y + h, y2));
                        b.left = () -> { s.b = !s.b; Sfx.play("click", s.b ? 1.25f : 0.8f); };
                        hits.add(b);
                    }
                    y += h;
                }
                case MODE -> {
                    int h = 22;
                    if (y + h > top && y < y2) {
                        boolean hov = in(mx, my, cx1, Math.max(y, top), cx2, Math.min(y + h, y2));
                        float hvv = hv(s, hov, dt);
                        if (hvv > 0.05f) rr(c, cx1 - 3, y, cx2 + 3, y + h, ca(0xFF191923, e * hvv));
                        int vw = Math.min(textRenderer.getWidth(s.modeName()) + 22, (cx2 - cx1) / 2 + 10);
                        c.drawText(textRenderer, fit(s.name, cx2 - cx1 - vw - 6), cx1, y + 7, ca(0xFFD8D8E8, e), false);
                        rr(c, cx2 - vw, y + 3, cx2, y + h - 3, ca(mix(0xFF22222E, accent, 0.25f + 0.25f * hvv), e));
                        c.drawText(textRenderer, "<", cx2 - vw + 4, y + 7, ca(0xFFAAAAAA, e), false);
                        c.drawText(textRenderer, ">", cx2 - 9, y + 7, ca(0xFFAAAAAA, e), false);
                        Draw2.centered(c, textRenderer, fit(s.modeName(), vw - 22), cx2 - vw / 2, y + 7, ca(0xFFFFFFFF, e));
                        Hit b = new Hit(cx1 - 3, Math.max(y, top), cx2 + 3, Math.min(y + h, y2));
                        b.left = () -> { s.cycle(); Sfx.play("click", 1f + 0.06f * s.idx); };
                        b.right = () -> { s.idx = (s.idx - 1 + s.modes.length) % s.modes.length; Sfx.play("click", 0.9f); };
                        hits.add(b);
                    }
                    y += h;
                }
                case NUM -> {
                    int h = 28;
                    if (y + h > top && y < y2) {
                        float t = (float) ((s.v - s.min) / (s.max - s.min));
                        if (s.anim < 0) s.anim = t;
                        s.anim = approach(s.anim, t, dt, 22);
                        boolean hov = in(mx, my, cx1, Math.max(y, top), cx2, Math.min(y + h, y2)) || (activeSlider != null && activeSlider.slider == s);
                        float hvv = hv(s, hov, dt);
                        if (hvv > 0.05f) rr(c, cx1 - 3, y, cx2 + 3, y + h, ca(0xFF191923, e * hvv));
                        String v = s.step >= 1 ? String.valueOf((int) Math.round(s.v)) : s.step >= 0.1 ? String.format("%.1f", s.v) : String.format("%.2f", s.v);
                        c.drawText(textRenderer, fit(s.name, cx2 - cx1 - textRenderer.getWidth(v) - 8), cx1, y + 3, ca(0xFFD8D8E8, e), false);
                        c.drawText(textRenderer, v, cx2 - textRenderer.getWidth(v), y + 3, ca(0xFFFFFFFF, e), false);
                        int ty = y + 16, tw = cx2 - cx1;
                        rr(c, cx1, ty, cx2, ty + 5, ca(0xFF262634, e));
                        int fw = Math.max(0, (int) (tw * s.anim));
                        if (fw > 1) c.fillGradient(cx1, ty, cx1 + fw, ty + 5, ca(accent, e), ca(accent2, e));
                        int kx = cx1 + fw;
                        rr(c, kx - 3, ty - 2, kx + 3, ty + 7, ca(0xFFFFFFFF, e));
                        Hit sl = new Hit(cx1, Math.max(y, top), cx2, Math.min(y + h, y2));
                        sl.slider = s;
                        hits.add(sl);
                    }
                    y += h;
                }
            }
        }
        setH = y + (int) setScroll - top + 4;
        c.disableScissor();
        float maxScroll = Math.max(0, setH - (y2 - top));
        setScroll = Math.max(0, Math.min(maxScroll, setScroll));
        if (maxScroll > 0) {
            int th = Math.max(16, (int) ((y2 - top) * (y2 - top) / setH));
            int ty = top + (int) ((y2 - top - th) * (setScroll / maxScroll));
            c.fill(x2 - 3, ty, x2 - 1, ty + th, ca(accent, 0.8f * e));
        }
    }

    void drawFooter(DrawContext c, int x, int y, int w, int h, int accent, int accent2, float e, int mx, int my, float dt) {
        c.fillGradient(x + 1, y, x + w - 1, y + 1, ca(accent, 0.4f * e), ca(accent2, 0.4f * e));
        int active = 0;
        for (Module m : Modules.ALL) if (m.enabled && m.toggleable) active++;
        c.drawText(textRenderer, active + " active  |  click: toggle   right click: settings   type: search   Right Alt: close", x + 8, y + 5, ca(0xFF6E6E86, e), false);
        // save / load buttons
        String[] labels = {"Save", "Load"};
        int bx = x + w - 8;
        for (int i = labels.length - 1; i >= 0; i--) {
            String l = labels[i];
            int bw = textRenderer.getWidth(l) + 12;
            bx -= bw;
            boolean hov = in(mx, my, bx, y + 2, bx + bw, y + h - 2);
            rr(c, bx, y + 2, bx + bw, y + h - 2, ca(mix(0xFF22222E, accent, hv("f" + i, hov, dt) * 0.6f), e));
            c.drawText(textRenderer, l, bx + 6, y + 5, ca(0xFFFFFFFF, e), false);
            final boolean save = i == 0;
            Hit hit = new Hit(bx, y + 2, bx + bw, y + h - 2);
            hit.left = () -> {
                String p = Modules.CONFIG.profile.modeName();
                boolean ok = save ? Config.save(p) : Config.load(p);
                if (this.client != null && this.client.player != null)
                    this.client.player.sendMessage(Text.literal("[Goku] " + (save ? "Saved" : "Loaded") + " profile '" + p + "'" + (ok ? "" : " (failed)")), true);
                Sfx.play("on", 1f);
            };
            hits.add(hit);
            bx -= 4;
        }
    }

    // ---------------------------------------------------------------- input
    void setSlider(Hit h, double mx) {
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (mx - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round(v / s.step) * s.step));
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int btn = click.button();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mx < h.x1 || mx >= h.x2 || my < h.y1 || my >= h.y2) continue;
            if (h.slider != null) { if (btn == 0) { activeSlider = h; setSlider(h, mx); Sfx.play("click", 1.4f); } }
            else if (btn == 0 && h.left != null) h.left.run();
            else if (btn == 1 && h.right != null) h.right.run();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeSlider != null) { setSlider(activeSlider, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        activeSlider = null;
        return super.mouseReleased(click);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        float d = (float) verticalAmount * -20f;
        if (mouseX >= setX1 && mouseX < setX2 && mouseY >= setY1 && mouseY < setY2 && (setX1 > 0)) setScroll = Math.max(0, setScroll + d);
        else listScroll = Math.max(0, listScroll + d);
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_INSERT) { close(); return true; }
        if (k == GLFW.GLFW_KEY_ESCAPE && !query.isEmpty()) { query = ""; listScroll = 0; return true; }
        if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) { query = query.substring(0, query.length() - 1); listScroll = 0; } return true; }
        if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z && query.length() < 24) { query += (char) ('a' + (k - GLFW.GLFW_KEY_A)); listScroll = 0; return true; }
        if (k >= GLFW.GLFW_KEY_0 && k <= GLFW.GLFW_KEY_9 && query.length() < 24) { query += (char) ('0' + (k - GLFW.GLFW_KEY_0)); listScroll = 0; return true; }
        if (k == GLFW.GLFW_KEY_SPACE && !query.isEmpty() && query.length() < 24) { query += ' '; return true; }
        return super.keyPressed(input);
    }

    /** Tiny text helper kept local so the GUI has no extra dependencies. */
    static final class Draw2 {
        static void centered(DrawContext c, net.minecraft.client.font.TextRenderer tr, String s, int cx, int y, int col) {
            c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, col, false);
        }
    }
}
