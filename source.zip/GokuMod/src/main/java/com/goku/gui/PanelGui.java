package com.goku.gui;

import com.goku.Config;
import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Sfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Panel layout: one dark column per category (Combat / Misc / Movement / Visual / Mace / Menu), module rows that toggle on tap and
 * unfold their settings inline, drag a header to move a column, drag the background to pan, type anywhere to search.
 */
public class PanelGui extends Screen {
    static final class Panel {
        final String name; final List<Module> mods = new ArrayList<>();
        float x, y, scroll; boolean placed; int bx1, by1, bx2, by2;
        Panel(String n) { name = n; }
    }

    static final class H extends ClickGui.Hit {
        Panel drag, owner;
        H(int x1, int y1, int x2, int y2) { super(x1, y1, x2, y2); }
    }

    static final List<Panel> panels = new ArrayList<>();
    static final Set<Module> expanded = new HashSet<>();
    static final Map<Module, Float> anim = new HashMap<>();
    static float panX;
    static String query = "";
    static final int HEAD = 18, ROW = 14, WHEEL = 34;

    final List<H> hits = new ArrayList<>();
    H active, pending;
    int pendingBtn;
    double pressY; float pressScroll;
    Panel dragHead; boolean moved, panDrag;
    float open, dt = 0.016f; long lastNs = System.nanoTime();
    int accent, accent2, mx, my; float e;

    public PanelGui() { super(Text.literal("Goku mod's")); }

    // ---------------------------------------------------------------- data
    static List<Module> claim(Collection<Module> src, Set<Module> used) {
        List<Module> out = new ArrayList<>();
        for (Module m : src) if (m != null && used.add(m)) out.add(m);
        return out;
    }

    static void build() {
        if (!panels.isEmpty()) return;
        Set<Module> used = new HashSet<>();
        List<Module> menu = claim(List.of(Modules.THEME, Modules.GUI_STYLE, Modules.SOUND, Modules.CONFIG, Modules.LEGIT, Modules.PERF), used);
        List<Module> visual = claim(List.of(Modules.PLAYER_ESP, Modules.TRACERS, Modules.NAME_TAGS, Modules.TARGET_RENDERER, Modules.TRAJECTORIES,
                Modules.STORAGE, Modules.XRAY, Modules.SPAWNER, Modules.BASE_FINDER, Modules.ENTITY_FINDER, Modules.SUS, Modules.CHUNK_LOG, Modules.FREECAM,
                Modules.FULLBRIGHT, Modules.ZOOM, Modules.LOW_FIRE, Modules.NO_SCOREBOARD, Modules.MODULE_LIST, Modules.WAYPOINTS, Modules.FPS,
                Modules.KEYSTROKES, Modules.PARTICLES, Modules.SKIN), used);
        List<Module> mv = new ArrayList<>(Modules.MOVEMENT); mv.add(Modules.FAKE_LAG); mv.add(Modules.AUTO_WALK);
        List<Module> move = claim(mv, used);
        List<Module> mace = claim(Modules.MACE_SEC, used);
        List<Module> misc = claim(List.of(Modules.FRIENDS, Modules.TEAMS, Modules.MIDDLE_FRIEND), used);
        misc.addAll(claim(Modules.AUTOMATION, used)); misc.addAll(claim(Modules.MODS, used));
        List<Module> combat = new ArrayList<>();
        for (List<Module> l : List.of(Modules.COMBAT, Modules.CRYSTAL_SEC, Modules.CART_SEC, Modules.POT_SEC)) combat.addAll(claim(l, used));
        misc.addAll(claim(Modules.EVERY, used));
        String[] names = {"Combat", "Misc", "Movement", "Visual", "Mace", "Menu"};
        List<List<Module>> lists = List.of(combat, misc, move, visual, mace, menu);
        for (int i = 0; i < names.length; i++) {
            Panel p = new Panel(names[i]);
            p.mods.addAll(lists.get(i));
            p.mods.sort(Comparator.comparing(m -> m.name.toLowerCase()));
            panels.add(p);
        }
    }

    List<Module> shown(Panel p) {
        if (query.isEmpty()) return p.mods;
        String q = query.toLowerCase();
        List<Module> out = new ArrayList<>();
        for (Module m : p.mods) {
            boolean hit = m.name.toLowerCase().contains(q);
            if (!hit) for (Setting s : m.settings) if (s.name.toLowerCase().contains(q)) { hit = true; break; }
            if (hit) out.add(m);
        }
        return out;
    }

    // ---------------------------------------------------------------- lifecycle
    @Override protected void init() { build(); open = 0; Sfx.play("open", 1f); Sfx.guiOpen = true; }

    @Override public void removed() {
        if (Modules.CONFIG.auto.b) Config.save(Modules.CONFIG.profile.modeName());
        Sfx.guiOpen = false;
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }

    // ---------------------------------------------------------------- helpers
    static int ca(int argb, float f) { return ClickGui.ca(argb, f); }

    boolean in(int x, int y, int x1, int y1, int x2, int y2) { return x >= x1 && x < x2 && y >= y1 && y < y2; }

    String fit(String s, int px) {
        if (textRenderer.getWidth(s) <= px) return s;
        while (s.length() > 1 && textRenderer.getWidth(s + "..") > px) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    H hit(Panel owner, int x1, int y1, int x2, int y2, int top, int bot) {
        H h = new H(x1, Math.max(y1, top), x2, Math.min(y2, bot));
        h.owner = owner;
        if (h.y2 > h.y1) hits.add(h);
        return h;
    }

    static int settingH(Setting s) {
        return switch (s.type) {
            case NUM -> 22;
            case COLOR -> 13 + (s.open ? 4 + 2 * WHEEL + 6 + 12 + 6 : 0);
            default -> 13;
        };
    }

    static int rowH(Module m) {
        int h = ROW;
        if (expanded.contains(m)) for (Setting s : m.settings) h += settingH(s);
        return h;
    }

    // ---------------------------------------------------------------- render
    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime(); dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        Modules.THEME.sync(); Modules.GUI_STYLE.sync();
        open = Math.min(1f, open + dt * 4f); e = ClickGui.ease(open);
        mx = mouseX; my = mouseY;
        accent = Modules.accent(); accent2 = Modules.accent2();
        hits.clear();
        c.fillGradient(0, 0, width, height, ClickGui.rgba(0x000000, 0.45f * e), ca(accent, 0.12f * e));

        int n = panels.size();
        int pw = Math.max(96, Math.min(122, (width - 12 - 4 * (n - 1)) / n));
        int total = 6 + n * (pw + 4);
        panX = Math.max(Math.min(0, width - total - 2), Math.min(0, panX));
        int maxH = height - 52;
        for (int i = 0; i < n; i++) {
            Panel p = panels.get(i);
            if (!p.placed) { p.x = 6 + i * (pw + 4); p.y = 10; p.placed = true; }
            drawPanel(c, p, pw, maxH);
        }
        drawBottom(c);
    }

    void drawPanel(DrawContext c, Panel p, int pw, int maxH) {
        List<Module> list = shown(p);
        p.bx1 = p.bx2 = -1;
        if (list.isEmpty()) return;
        int x = (int) (p.x + panX), y = (int) p.y + (int) ((1 - e) * 12);
        int ch = 0;
        for (Module m : list) ch += rowH(m);
        int bodyMax = Math.max(40, maxH - HEAD - (int) Math.max(0, p.y - 10));
        int bodyH = Math.min(ch, bodyMax), h = HEAD + bodyH;
        float maxScroll = Math.max(0, ch - bodyH);
        p.scroll = Math.max(0, Math.min(maxScroll, p.scroll));
        p.bx1 = x; p.by1 = y; p.bx2 = x + pw; p.by2 = y + h;

        ClickGui.rr(c, x - 1, y - 1, x + pw + 1, y + h + 1, ca(0xFF000000, 0.35f * e));
        ClickGui.rr(c, x, y, x + pw, y + h, ca(0xFF0E0E16, 0.95f * e));
        c.fillGradient(x, y, x + pw, y + HEAD, ca(0xFF1A1A27, e), ca(0xFF12121B, e));
        c.fill(x, y + HEAD - 1, x + pw, y + HEAD, ca(accent, 0.9f * e));
        c.fill(x + 4, y + 5, x + 6, y + HEAD - 6, ca(accent2, e));
        c.drawText(textRenderer, p.name, x + 10, y + 5, ca(0xFFFFFFFF, e), true);
        String cnt = String.valueOf(list.size());
        c.drawText(textRenderer, cnt, x + pw - 6 - textRenderer.getWidth(cnt), y + 5, ca(0xFF6A6A82, e), false);
        H hd = new H(x, y, x + pw, y + HEAD); hd.drag = p; hits.add(hd);

        int top = y + HEAD, bot = y + h;
        c.enableScissor(x, top, x + pw, bot);
        int ry = top - (int) p.scroll;
        for (Module m : list) ry = drawModule(c, p, m, x, ry, pw, top, bot);
        c.disableScissor();
        if (maxScroll > 0) {
            int th = Math.max(12, (int) (bodyH * (float) bodyH / ch));
            int ty = top + (int) ((bodyH - th) * (p.scroll / maxScroll));
            c.fill(x + pw - 2, ty, x + pw - 1, ty + th, ca(accent, 0.8f * e));
        }
    }

    int drawModule(DrawContext c, Panel p, Module m, int x, int ry, int pw, int top, int bot) {
        boolean on = m.enabled && m.toggleable;
        float a = anim.getOrDefault(m, on ? 1f : 0f);
        a += ((on ? 1f : 0f) - a) * Math.min(1f, dt * 14f);
        anim.put(m, a);
        boolean exp = expanded.contains(m);
        if (ry + ROW > top && ry < bot) {
            boolean hov = in(mx, my, x, Math.max(ry, top), x + pw, Math.min(ry + ROW, bot));
            if (a > 0.02f) c.fillGradient(x + 1, ry, x + pw - 1, ry + ROW, ca(accent, 0.62f * a * e), ca(accent2, 0.62f * a * e));
            else if (hov) c.fill(x + 1, ry, x + pw - 1, ry + ROW, ca(0xFFFFFFFF, 0.06f * e));
            int col = ClickGui.mix(0xFF8E8EA6, 0xFFFFFFFF, Math.max(a, hov ? 0.5f : 0f));
            c.drawText(textRenderer, fit(m.name, pw - 24), x + 6, ry + 3, ca(col, e), false);
            c.drawText(textRenderer, exp ? "v" : ">", x + pw - 11, ry + 3, ca(0xFFB0B0C8, e), false);
            H chev = hit(p, x + pw - 18, ry, x + pw, ry + ROW, top, bot);
            chev.left = () -> { toggleExpand(m); };
            H main = hit(p, x, ry, x + pw - 18, ry + ROW, top, bot);
            main.left = () -> { if (m.toggleable) { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); } else toggleExpand(m); };
            main.right = () -> toggleExpand(m);
        }
        ry += ROW;
        if (exp) for (Setting s : m.settings) ry = drawSetting(c, p, s, x, ry, pw, top, bot);
        return ry;
    }

    void toggleExpand(Module m) { if (!expanded.remove(m)) expanded.add(m); Sfx.play("click", 1.1f); }

    int drawSetting(DrawContext c, Panel p, Setting s, int x, int ry, int pw, int top, int bot) {
        int h = settingH(s);
        boolean vis = ry + h > top && ry < bot;
        if (vis) {
            c.fill(x + 1, Math.max(ry, top), x + pw - 1, Math.min(ry + h, bot), ca(0xFF08080D, 0.7f * e));
            int tx = x + 8, rx = x + pw - 7;
            switch (s.type) {
                case BOOL -> {
                    if (s.name.startsWith(">")) {
                        ClickGui.rr(c, x + 5, ry + 1, x + pw - 5, ry + h - 1, ca(ClickGui.mix(0xFF22222E, accent, 0.4f), e));
                        String t = s.name.substring(1).trim();
                        c.drawText(textRenderer, fit(t, pw - 16), x + (pw - textRenderer.getWidth(fit(t, pw - 16))) / 2, ry + 3, ca(0xFFFFFFFF, e), false);
                        hit(p, x, ry, x + pw, ry + h, top, bot).left = () -> { s.b = true; Sfx.play("on", 1.1f); };
                    } else {
                        if (s.anim < 0) s.anim = s.b ? 1 : 0;
                        s.anim += ((s.b ? 1f : 0f) - s.anim) * Math.min(1f, dt * 16f);
                        c.drawText(textRenderer, fit(s.name, pw - 34), tx, ry + 3, ca(0xFFC8C8DA, e), false);
                        c.fill(rx - 14, ry + 3, rx, ry + 10, ca(ClickGui.mix(0xFF2A2A38, accent, s.anim), e));
                        int kx = rx - 13 + (int) (7 * s.anim);
                        c.fill(kx, ry + 4, kx + 5, ry + 9, ca(0xFFFFFFFF, e));
                        hit(p, x, ry, x + pw, ry + h, top, bot).left = () -> { s.b = !s.b; Sfx.play("click", s.b ? 1.25f : 0.8f); };
                    }
                }
                case MODE -> {
                    String v = s.modeName();
                    int vw = Math.min(textRenderer.getWidth(v), pw / 2);
                    c.drawText(textRenderer, fit(s.name, pw - vw - 20), tx, ry + 3, ca(0xFFC8C8DA, e), false);
                    c.drawText(textRenderer, fit(v, pw / 2), rx - vw, ry + 3, ca(accent, e), false);
                    H b = hit(p, x, ry, x + pw, ry + h, top, bot);
                    b.left = () -> { s.cycle(); Sfx.play("click", 1f + 0.06f * s.idx); };
                    b.right = () -> { s.idx = (s.idx - 1 + s.modes.length) % s.modes.length; Sfx.play("click", 0.9f); };
                }
                case NUM -> {
                    String v = s.step >= 1 ? String.valueOf((int) Math.round(s.v)) : s.step >= 0.1 ? String.format("%.1f", s.v) : String.format("%.2f", s.v);
                    c.drawText(textRenderer, fit(s.name, pw - textRenderer.getWidth(v) - 20), tx, ry + 2, ca(0xFFC8C8DA, e), false);
                    c.drawText(textRenderer, v, rx - textRenderer.getWidth(v), ry + 2, ca(0xFFFFFFFF, e), false);
                    int sx1 = x + 8, sx2 = x + pw - 8, sy = ry + 14;
                    float t = (float) ((s.v - s.min) / (s.max - s.min));
                    c.fill(sx1, sy, sx2, sy + 3, ca(0xFF262634, e));
                    int fw = (int) ((sx2 - sx1) * Math.max(0, Math.min(1, t)));
                    if (fw > 0) c.fillGradient(sx1, sy, sx1 + fw, sy + 3, ca(accent, e), ca(accent2, e));
                    c.fill(sx1 + fw - 1, sy - 2, sx1 + fw + 2, sy + 5, ca(0xFFFFFFFF, e));
                    H sl = hit(p, sx1 - 4, ry + 9, sx2 + 4, ry + h, top, bot);
                    sl.slider = s; sl.x1 = sx1; sl.x2 = sx2;
                }
                case COLOR -> {
                    c.drawText(textRenderer, fit(s.name, pw - 34), tx, ry + 3, ca(0xFFC8C8DA, e), false);
                    c.fill(rx - 16, ry + 2, rx, ry + 11, ca(0xFFFFFFFF, 0.85f * e));
                    c.fill(rx - 15, ry + 3, rx - 1, ry + 10, ca(s.argb(), e));
                    hit(p, x, ry, x + pw, ry + 13, top, bot).left = () -> { s.open = !s.open; Sfx.play("click", 1.1f); };
                    if (s.open) {
                        int wx = x + pw / 2, wy = ry + 13 + 4 + WHEEL;
                        for (int px = -WHEEL; px <= WHEEL; px += 3) for (int py = -WHEEL; py <= WHEEL; py += 3) {
                            double r2 = Math.sqrt((px + 1.5) * (px + 1.5) + (py + 1.5) * (py + 1.5));
                            if (r2 > WHEEL) continue;
                            float hu = (float) ((Math.atan2(py + 1.5, px + 1.5) / (2 * Math.PI) + 1) % 1);
                            c.fill(wx + px, wy + py, wx + px + 3, wy + py + 3, ca(0xFF000000 | Setting.hsvToRgb(hu, (float) (r2 / WHEEL), s.val), e));
                        }
                        int kx = wx + (int) (Math.cos(s.hue * 2 * Math.PI) * s.sat * WHEEL), ky = wy + (int) (Math.sin(s.hue * 2 * Math.PI) * s.sat * WHEEL);
                        c.fill(kx - 3, ky - 3, kx + 4, ky + 4, ca(0xFFFFFFFF, e));
                        c.fill(kx - 2, ky - 2, kx + 3, ky + 3, ca(s.argb(), e));
                        H wh = hit(p, wx - WHEEL, wy - WHEEL, wx + WHEEL, wy + WHEEL, top, bot);
                        wh.pickS = s; wh.pick = 1; wh.pcx = wx; wh.pcy = wy; wh.pr = WHEEL;
                        int by = wy + WHEEL + 6, bx1 = x + 8, bx2 = x + pw - 8, segs = 20;
                        for (int i = 0; i < segs; i++)
                            c.fill(bx1 + (bx2 - bx1) * i / segs, by, bx1 + (bx2 - bx1) * (i + 1) / segs, by + 10, ca(0xFF000000 | Setting.hsvToRgb(s.hue, s.sat, (i + 0.5f) / segs), e));
                        int bk = bx1 + (int) ((bx2 - bx1) * s.val);
                        c.fill(bk - 2, by - 2, bk + 3, by + 12, ca(0xFFFFFFFF, e));
                        H bh = hit(p, bx1, by - 3, bx2, by + 13, top, bot);
                        bh.pickS = s; bh.pick = 2; bh.x1 = bx1; bh.x2 = bx2;
                    }
                }
            }
        }
        return ry + h;
    }

    void drawBottom(DrawContext c) {
        int bw = 150, bx = (width - bw) / 2, by = height - 22;
        ClickGui.rr(c, bx - 1, by - 1, bx + bw + 1, by + 15, ca(0xFF000000, 0.4f * e));
        ClickGui.rr(c, bx, by, bx + bw, by + 14, ca(0xFF12121C, 0.96f * e));
        String t = query.isEmpty() ? "Search" : query + "_";
        c.drawText(textRenderer, fit(t, bw - 24), bx + 6, by + 3, ca(query.isEmpty() ? 0xFF6A6A82 : 0xFFFFFFFF, e), false);
        c.fillGradient(bx + bw - 16, by + 2, bx + bw - 3, by + 12, ca(accent, e), ca(accent2, e));
        String[] names = {"Hub", "Save", "Classic"};
        int bwid = 44, gap = 4, tx = (width - (3 * bwid + 2 * gap)) / 2, ty = by - 17;
        for (int i = 0; i < 3; i++) {
            int x1 = tx + i * (bwid + gap);
            boolean hov = in(mx, my, x1, ty, x1 + bwid, ty + 13);
            ClickGui.rr(c, x1, ty, x1 + bwid, ty + 13, ca(ClickGui.mix(0xFF1A1A27, accent, hov ? 0.5f : 0.22f), e));
            c.drawText(textRenderer, names[i], x1 + (bwid - textRenderer.getWidth(names[i])) / 2, ty + 3, ca(0xFFFFFFFF, e), false);
            H h = new H(x1, ty, x1 + bwid, ty + 13);
            final int idx = i;
            h.left = () -> {
                if (idx == 0) client.setScreen(new ManagerGui());
                else if (idx == 1) { Config.save(Modules.CONFIG.profile.modeName()); Sfx.play("on", 1f); }
                else { Modules.GUI_STYLE.panels.b = false; client.setScreen(new ClickGui()); }
            };
            hits.add(h);
        }
    }

    // ---------------------------------------------------------------- input
    void setSlider(ClickGui.Hit h, double x, double y) {
        if (h.pickS != null) {
            Setting c = h.pickS;
            if (h.pick == 1) {
                double dx = x - h.pcx, dy = y - h.pcy, r = Math.sqrt(dx * dx + dy * dy);
                c.setHsv((float) ((Math.atan2(dy, dx) / (2 * Math.PI) + 1) % 1), (float) Math.min(1, r / h.pr), c.val);
            } else c.setHsv(c.hue, c.sat, (float) Math.max(0, Math.min(1, (x - h.x1) / (double) (h.x2 - h.x1))));
            return;
        }
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (x - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round(v / s.step) * s.step));
    }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double cx = click.x(), cy = click.y(); int btn = click.button();
        ClickGui.ripples.add(new float[]{(float) cx, (float) cy, 0});
        pending = null; active = null; dragHead = null; moved = false; panDrag = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            H h = hits.get(i);
            if (cx < h.x1 || cx >= h.x2 || cy < h.y1 || cy >= h.y2) continue;
            if (h.drag != null) { if (btn == 0) dragHead = h.drag; return true; }
            if (h.slider != null || h.pickS != null) { if (btn == 0) { active = h; setSlider(h, cx, cy); Sfx.play("click", 1.4f); } return true; }
            pending = h; pendingBtn = btn; pressY = cy; pressScroll = h.owner != null ? h.owner.scroll : 0;
            return true;
        }
        panDrag = true;
        return true;
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (active != null) { setSlider(active, click.x(), click.y()); return true; }
        if (dragHead != null) { dragHead.x += (float) dx; dragHead.y = Math.max(0, dragHead.y + (float) dy); moved = true; return true; }
        if (pending != null) {
            if (Math.abs(click.y() - pressY) > 4) moved = true;
            if (moved && pending.owner != null) pending.owner.scroll = Math.max(0, pressScroll - (float) (click.y() - pressY));
            return true;
        }
        if (panDrag) { panX += (float) dx; return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        H p = pending;
        pending = null; active = null; dragHead = null; panDrag = false;
        if (p != null && !moved) {
            if (pendingBtn == 0 && p.left != null) p.left.run();
            else if (pendingBtn == 1 && p.right != null) p.right.run();
        }
        moved = false;
        return super.mouseReleased(click);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (Panel p : panels) {
            if (p.bx1 >= 0 && mouseX >= p.bx1 && mouseX < p.bx2 && mouseY >= p.by1 && mouseY < p.by2) { p.scroll = Math.max(0, p.scroll - (float) verticalAmount * 24f); return true; }
        }
        panX += (float) (verticalAmount * 30);
        return true;
    }

    @Override public boolean charTyped(CharInput input) {
        int cp = input.codepoint();
        if (cp == 8 || cp == 127) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
        if (cp < 32 || !input.isValidChar()) return false;
        char ch = (char) cp;
        if (!(Character.isLetterOrDigit(ch) || ch == ' ' || ch == '_' || ch == '-' || ch == '.' || ch == '&') || query.length() >= 24) return true;
        if (ch == ' ' && query.isEmpty()) return true;
        query += Character.toLowerCase(ch);
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_INSERT || k == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        if (k == GLFW.GLFW_KEY_ESCAPE && !query.isEmpty()) { query = ""; return true; }
        if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
        return super.keyPressed(input);
    }
}
