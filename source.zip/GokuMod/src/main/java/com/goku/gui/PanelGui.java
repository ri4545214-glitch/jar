package com.goku.gui;

import com.goku.Config;
import com.goku.Module;
import com.goku.Modules;
import com.goku.Setting;
import com.goku.util.Sfx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * "Panels" layout: one draggable panel per category side by side (Combat, Crystal PvP, Mace PvP, ...), each a list of modules.
 * Left click toggles a module, the [+] button (or right click) opens its settings. Drag a panel header to move it, tap it to fold it,
 * drag empty space to pan sideways, drag inside a panel (or use the wheel) to scroll it. Type anywhere to search.
 */
public class PanelGui extends Screen {
    static final int PW = 104, HDR = 18, ROW = 13, GAP = 6;

    static final class P {
        final String title, tag; final List<Module> mods;
        int ox, oy, slot; float scroll, goal, max; boolean collapsed;
        int x, y, vis;   // set every frame
        P(String t, String g, List<Module> m) { title = t; tag = g; mods = m; }
    }

    static final class H {
        int x1, y1, x2, y2; Runnable left, right; Setting slider; P header, body;
        H(int a, int b, int c, int d) { x1 = a; y1 = b; x2 = c; y2 = d; }
    }

    static final Map<String, int[]> POS = new HashMap<>();   // remembered panel offsets
    static String query = "";
    static float panX;

    final ParticleField field = new ParticleField();
    final List<P> panels = new ArrayList<>();
    final List<H> hits = new ArrayList<>();
    final Map<Object, Float> hov = new HashMap<>();
    final Map<Module, Float> exp = new HashMap<>();
    float open, time, panGoal;
    long lastNs = System.nanoTime();
    int mx, my, accent, accent2;
    float dt, e;
    H activeSlider, pending; int pendingBtn, mode;   // mode: 1 move panel, 2 scroll panel, 3 pan, 4 scrollbar-less drag
    P dragP; double pressX, pressY; float pressScroll, pressPan; boolean moved;

    public PanelGui() { super(Text.literal("Goku mod's")); }

    // ------------------------------------------------------------ data
    void build() {
        panels.clear();
        for (var e : Modules.SECTIONS.entrySet()) add(e.getKey(), Modules.TAGS.get(e.getKey()), e.getValue());
    }

    void add(String t, String g, List<Module> m) {
        P p = new P(t, g, m);
        p.slot = panels.size();
        int[] o = POS.get(t);
        if (o != null) { p.ox = o[0]; p.oy = o[1]; }
        panels.add(p);
    }

    List<Module> search() {
        String q = query.toLowerCase();
        Set<Module> out = new LinkedHashSet<>();
        for (Module m : Modules.EVERY) {
            if (m.name.toLowerCase().contains(q)) out.add(m);
            else for (Setting s : m.settings) if (s.name.toLowerCase().contains(q)) { out.add(m); break; }
        }
        return new ArrayList<>(out);
    }

    // ------------------------------------------------------------ lifecycle
    @Override protected void init() {
        field.resize(width, height);
        if (Modules.GUI_STYLE.style.idx == 4) AnimeArt.reload();
        build();
        open = 0;
        Sfx.play("open", 1f);
        Sfx.guiOpen = true;
    }

    @Override public void removed() {
        for (P p : panels) POS.put(p.title, new int[]{p.ox, p.oy});
        if (Modules.CONFIG.auto.b) Config.save(Modules.CONFIG.profile.modeName());
        Sfx.guiOpen = false;
        super.removed();
    }

    @Override public boolean shouldPause() { return false; }

    // ------------------------------------------------------------ helpers
    boolean in(int x1, int y1, int x2, int y2) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }

    float hv(Object k, boolean on) {
        float v = hov.getOrDefault(k, 0f);
        v = ClickGui.approach(v, on ? 1 : 0, dt, 16);
        hov.put(k, v);
        return v;
    }

    String fit(String s, int w) {
        if (textRenderer.getWidth(s) <= w) return s;
        while (s.length() > 1 && textRenderer.getWidth(s + "..") > w) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    static int ca(int c, float f) { return ClickGui.ca(c, f); }

    int setH(Setting s) { return s.type == Setting.Type.NUM ? 17 : 13; }

    int settingsH(Module m) { int h = 0; for (Setting s : m.settings) h += setH(s); return h + (m.settings.isEmpty() ? 0 : 3); }

    float content(P p, List<Module> mods) {
        float h = 2;
        for (Module m : mods) h += ROW + settingsH(m) * ClickGui.ease(exp.getOrDefault(m, 0f));
        return h;
    }

    // ------------------------------------------------------------ render
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime(); dt = Math.min((now - lastNs) / 1e9f, 0.1f); lastNs = now;
        Modules.THEME.sync(); Modules.GUI_STYLE.sync();
        time += dt; ClickGui.clock = time;
        open = Modules.GUI_STYLE.anims.b ? Math.min(1, open + dt * 3.4f) : 1;
        e = ClickGui.ease(open);
        mx = mouseX; my = mouseY;
        accent = Modules.accent(); accent2 = Modules.accent2();
        hits.clear();

        float dimK = (float) (Modules.GUI_STYLE.dim.v / 100.0);
        ctx.fillGradient(0, 0, width, height, ClickGui.rgba(0x000000, dimK * e), ca(accent, 0.28f * (dimK / 0.66f) * e));
        if (Modules.GUI_STYLE.particles.b) field.render(ctx, dt, accent, mx, my);
        if (Modules.GUI_STYLE.style.idx == 4) {   // anime picture in the corner behind the panels
            int ah = height, aw = Math.min(width / 2, (int) (ah * AnimeArt.aspect()));
            ctx.enableScissor(width - aw, 0, width, height);
            AnimeArt.draw(ctx, width - aw, 0, aw, ah, 0.55f * e);
            ctx.disableScissor();
            ClickGui.petals(ctx, 0, 0, width, height, e * 0.8f);
        }

        boolean searching = !query.isEmpty();
        List<P> draw = panels;
        if (searching) {
            P sp = new P("Search: " + query, "?", search());
            sp.ox = 0; sp.oy = 0;
            int bodyMax = Math.max(60, height - HDR - 70);
            sp.x = Math.max(6, width / 2 - PW); sp.y = 10;
            draw = new ArrayList<>(); draw.add(sp);
            searchPanel = sp;
        }

        panX = ClickGui.approach(panX, panGoal, dt, 14);
        float total = panels.size() * (PW + GAP) + GAP;
        float maxPan = Math.max(0, total - width);
        panGoal = Math.max(0, Math.min(maxPan, panGoal)); panX = Math.max(0, Math.min(maxPan, panX));

        for (P p : draw) {
            if (!searching) { p.x = GAP + p.slot * (PW + GAP) - (int) panX + p.ox; p.y = 10 + p.oy; }
            if (p.x + PW < 0 || p.x > width) continue;
            drawPanel(ctx, p, (int) ((1 - e) * 14));
        }
        drawBottom(ctx);
        ClickGui.drawRipples(ctx, 0, 0, width, height, dt, e, accent);
    }

    P searchPanel;

    void drawPanel(DrawContext c, P p, int slide) {
        int x = p.x, y = p.y + slide;
        List<Module> mods = p.mods;
        float cont = content(p, mods);
        int bodyMax = Math.max(50, Math.min(250, height - y - HDR - 52));
        p.vis = p.collapsed ? 0 : (int) Math.min(cont, bodyMax);
        p.max = Math.max(0, cont - p.vis);
        p.scroll = ClickGui.approach(p.scroll, p.goal, dt, 16);
        p.goal = Math.max(0, Math.min(p.max, p.goal)); p.scroll = Math.max(0, Math.min(p.max, p.scroll));

        // shadow + body
        for (int i = 3; i >= 1; i--) ClickGui.rr(c, x - i, y - i, x + PW + i, y + HDR + p.vis + i, ca(0xFF000000, 0.08f * e));
        c.fill(x, y, x + PW, y + HDR + p.vis, ca(0xFF0C0C12, (Modules.GUI_STYLE.style.idx == 4 ? 0.62f : 0.93f) * e));
        // header
        c.fill(x, y, x + PW, y + HDR, ca(0xFF16161F, e));
        int seg = 10;
        for (int i = 0; i < seg; i++) {
            float k = (float) (Math.sin(time * 2.0 + i * 0.5 + x * 0.01) * 0.5 + 0.5);
            c.fill(x + PW * i / seg, y + HDR - 1, x + PW * (i + 1) / seg + 1, y + HDR, ca(ClickGui.mix(accent, accent2, k), e));
        }
        ClickGui.rr(c, x + 4, y + 3, x + 16, y + 15, ca(accent, 0.9f * e));
        ClickGui.Draw2.centered(c, textRenderer, p.tag, x + 10, y + 5, ca(0xFFFFFFFF, e));
        c.drawText(textRenderer, fit(p.title, PW - 44), x + 21, y + 5, ca(0xFFFFFFFF, e), false);
        int on = 0; for (Module m : mods) if (m.enabled && m.toggleable) on++;
        String cnt = p.collapsed ? "+" : on > 0 ? String.valueOf(on) : "-";
        c.drawText(textRenderer, cnt, x + PW - 4 - textRenderer.getWidth(cnt), y + 5, ca(on > 0 ? accent : 0xFF77778C, e), false);
        H hh = new H(x, y, x + PW, y + HDR); hh.header = p; hits.add(hh);
        if (p.vis <= 0) return;

        int top = y + HDR, bot = top + p.vis;
        c.enableScissor(x, top, x + PW, bot);
        int yy = top + 1 - (int) p.scroll;
        for (Module m : mods) {
            // --- module row
            m.anim = ClickGui.approach(m.anim, m.enabled && m.toggleable ? 1 : 0, dt, 14);
            boolean rowVis = yy + ROW > top && yy < bot;
            float ea = ClickGui.ease(exp.getOrDefault(m, 0f));
            if (rowVis) {
                boolean h = in(x, Math.max(yy, top), x + PW, Math.min(yy + ROW, bot)) && mx >= x && mx < x + PW;
                float hvv = hv(m, h);
                int bg = ClickGui.mix(0xFF0C0C12, 0xFF1C1C28, hvv);
                c.fill(x + 1, yy, x + PW - 1, yy + ROW, ca(bg, e));
                if (m.anim > 0.01f) {
                    c.fillGradient(x + 1, yy, x + PW - 1, yy + ROW, ca(accent, 0.80f * m.anim * e), ca(accent2, 0.80f * m.anim * e));
                }
                int tc = ClickGui.mix(m.toggleable ? 0xFF9A9AB0 : 0xFFD8D8E8, 0xFFFFFFFF, Math.max(m.anim, hvv * 0.7f));
                c.drawText(textRenderer, fit(m.name, PW - (m.settings.isEmpty() ? 8 : 22)), x + 5, yy + 3, ca(tc, e), false);
                if (!m.settings.isEmpty()) {
                    String g = ea > 0.5f ? "-" : "+";
                    c.drawText(textRenderer, g, x + PW - 9, yy + 3, ca(m.anim > 0.5f ? 0xFFFFFFFF : accent, e), false);
                    H eb = new H(x + PW - 16, Math.max(yy, top), x + PW - 1, Math.min(yy + ROW, bot)); eb.body = p;
                    eb.left = () -> { m.open = !m.open; Sfx.play("click", m.open ? 1.3f : 1.0f); };
                    eb.right = eb.left;
                    hits.add(eb);
                }
                H rh = new H(x + 1, Math.max(yy, top), x + PW - 16, Math.min(yy + ROW, bot)); rh.body = p;
                if (m.settings.isEmpty()) rh.x2 = x + PW - 1;
                rh.left = () -> {
                    if (m.toggleable) { m.toggle(); Sfx.play(m.enabled ? "on" : "off", 1f); }
                    else if (!m.settings.isEmpty()) m.open = !m.open;
                };
                rh.right = () -> { if (!m.settings.isEmpty()) { m.open = !m.open; Sfx.play("click", 1.2f); } };
                hits.add(rh);
            }
            yy += ROW;
            // --- settings (animated open)
            float tgt = m.open ? 1 : 0;
            exp.put(m, ClickGui.approach(exp.getOrDefault(m, 0f), tgt, dt, 14));
            int sh = (int) (settingsH(m) * ea);
            if (sh > 1) {
                int sy = yy + 1;
                c.fill(x + 1, yy, x + PW - 1, yy + sh, ca(0xFF101018, e));
                c.fill(x + 1, yy, x + 2, yy + sh, ca(accent, 0.7f * e));
                for (Setting s : m.settings) {
                    int rh2 = setH(s);
                    if (sy + rh2 > top && sy < bot && sy + rh2 <= yy + sh + 2) drawSetting(c, p, s, x, sy, top, bot, ea);
                    sy += rh2;
                }
            }
            yy += sh;
        }
        c.disableScissor();
        if (p.max > 0) {   // scrollbar
            int th = Math.max(14, (int) (p.vis * (p.vis / (p.vis + p.max))));
            int ty = top + (int) ((p.vis - th) * (p.scroll / p.max));
            c.fill(x + PW - 2, top, x + PW, bot, ca(0xFF14141C, e));
            c.fill(x + PW - 2, ty, x + PW, ty + th, ca(accent, 0.9f * e));
        }
    }

    void drawSetting(DrawContext c, P p, Setting s, int x, int sy, int top, int bot, float ea) {
        float a = e * ea;
        int rh = setH(s);
        int x1 = x + 5, x2 = x + PW - 5;
        int cy1 = Math.max(sy, top), cy2 = Math.min(sy + rh, bot);
        boolean h = cy1 < cy2 && in(x1 - 2, cy1, x2 + 2, cy2);
        float hvv = hv(s, h);
        if (hvv > 0.02f) c.fill(x + 3, sy, x + PW - 3, sy + rh - 1, ca(0xFF1A1A26, a * hvv));
        switch (s.type) {
            case BOOL -> {
                s.anim = ClickGui.approach(s.anim < 0 ? (s.b ? 1 : 0) : s.anim, s.b ? 1 : 0, dt, 18);
                c.drawText(textRenderer, fit(s.name, PW - 30), x1, sy + 2, ca(ClickGui.mix(0xFF8E8EA4, 0xFFFFFFFF, hvv), a), false);
                int bx = x2 - 9;
                ClickGui.rr(c, bx, sy + 2, bx + 9, sy + 11, ca(0xFF262634, a));
                if (s.anim > 0.02f) ClickGui.rr(c, bx + 1, sy + 3, bx + 8, sy + 10, ca(ClickGui.mix(accent, accent2, 0.5f), a * s.anim));
                if (cy1 < cy2) { H b = new H(x + 3, cy1, x + PW - 3, cy2); b.body = p; b.left = () -> { s.b = !s.b; Sfx.play("click", s.b ? 1.4f : 1f); }; hits.add(b); }
            }
            case MODE -> {
                c.drawText(textRenderer, fit(s.name, 48), x1, sy + 2, ca(ClickGui.mix(0xFF8E8EA4, 0xFFFFFFFF, hvv), a), false);
                String v = s.modeName();
                int w = Math.min(PW - 24 - Math.min(48, textRenderer.getWidth(s.name)), PW - 24);
                v = fit(v, Math.max(20, PW - 14 - Math.min(48, textRenderer.getWidth(s.name)) - 6));
                c.drawText(textRenderer, v, x2 - textRenderer.getWidth(v), sy + 2, ca(accent, a), false);
                if (cy1 < cy2) {
                    H b = new H(x + 3, cy1, x + PW - 3, cy2); b.body = p;
                    b.left = () -> { s.cycle(); Sfx.play("click", 1.2f); };
                    b.right = () -> { s.idx = (s.idx - 1 + s.modes.length) % s.modes.length; Sfx.play("click", 0.9f); };
                    hits.add(b);
                }
            }
            case NUM -> {
                double t = (s.v - s.min) / Math.max(1e-9, s.max - s.min);
                s.anim = ClickGui.approach(s.anim < 0 ? (float) t : s.anim, (float) t, dt, 22);
                String val = s.step >= 1 ? String.valueOf(s.i()) : String.format("%.1f", s.v);
                c.drawText(textRenderer, fit(s.name, PW - 14 - textRenderer.getWidth(val) - 4), x1, sy + 2, ca(ClickGui.mix(0xFF8E8EA4, 0xFFFFFFFF, hvv), a), false);
                c.drawText(textRenderer, val, x2 - textRenderer.getWidth(val), sy + 2, ca(accent, a), false);
                int by = sy + 12;
                c.fill(x1, by, x2, by + 3, ca(0xFF262634, a));
                int fw = (int) ((x2 - x1) * Math.max(0, Math.min(1, s.anim)));
                if (fw > 0) c.fillGradient(x1, by, x1 + fw, by + 3, ca(accent, a), ca(accent2, a));
                c.fill(x1 + fw - 1, by - 1, x1 + fw + 1, by + 4, ca(0xFFFFFFFF, a));
                if (cy1 < cy2) { H b = new H(x1, cy1, x2, cy2); b.body = p; b.slider = s; hits.add(b); }
            }
        }
    }

    void drawBottom(DrawContext c) {
        int bw = 220, bx = width / 2 - bw / 2, by = height - 26;
        ClickGui.rr(c, bx - 4, by - 4, bx + bw + 4, height - 4, ca(0xFF0C0C12, 0.9f * e));
        c.fill(bx - 4, by - 4, bx + bw + 4, by - 3, ca(accent, 0.6f * e));
        String[] labels = {"Manager", "Save", "Load", "Window"};
        int x = bx;
        int each = (bw - 3 * 4) / 4;
        for (int i = 0; i < labels.length; i++) {
            boolean h = in(x, by, x + each, by + 12);
            float hvv = hv("b" + i, h);
            ClickGui.rr(c, x, by, x + each, by + 12, ca(ClickGui.mix(0xFF22222E, accent, hvv * 0.7f), e));
            ClickGui.Draw2.centered(c, textRenderer, labels[i], x + each / 2, by + 2, ca(0xFFFFFFFF, e));
            final int id = i;
            H b = new H(x, by, x + each, by + 12);
            b.left = () -> {
                Sfx.play("click", 1f);
                if (id == 0) client.setScreen(new ManagerGui());
                else if (id == 3) { Modules.GUI_STYLE.layout.idx = 0; client.setScreen(new ClickGui()); }
                else {
                    String pr = Modules.CONFIG.profile.modeName();
                    boolean ok = id == 1 ? Config.save(pr) : Config.load(pr);
                    if (client != null && client.player != null)
                        client.player.sendMessage(Text.literal("[Goku] " + (id == 1 ? "Saved" : "Loaded") + " profile '" + pr + "'" + (ok ? "" : " (failed)")), true);
                }
            };
            hits.add(b);
            x += each + 4;
        }
        // search box
        int sy = by + 15;
        ClickGui.rr(c, bx, sy, bx + bw, sy + 11 > height - 2 ? height - 2 : sy + 11, ca(0xFF16161F, e));
        boolean blink = ((int) (time * 2)) % 2 == 0;
        String shown = query.isEmpty() ? "type to search modules..." : query + (blink ? "_" : "");
        c.drawText(textRenderer, fit(shown, bw - 22), bx + 5, sy + 2, ca(query.isEmpty() ? 0xFF6E6E86 : 0xFFFFFFFF, e), false);
        if (!query.isEmpty()) {
            c.drawText(textRenderer, "x", bx + bw - 9, sy + 2, ca(accent, e), false);
            H cl = new H(bx + bw - 16, sy, bx + bw, sy + 11);
            cl.left = () -> { query = ""; panGoal = 0; };
            hits.add(cl);
        }
        int act = 0; for (Module m : Modules.ALL) if (m.enabled && m.toggleable) act++;
        String info = act + " active";
        c.drawText(textRenderer, info, 6, height - 12, ca(0xFF8E8EA4, e), false);
    }

    // ------------------------------------------------------------ input
    void setSlider(H h, double x) {
        Setting s = h.slider;
        double t = Math.max(0, Math.min(1, (x - h.x1) / (double) (h.x2 - h.x1)));
        double v = s.min + t * (s.max - s.min);
        s.v = Math.max(s.min, Math.min(s.max, Math.round((v - s.min) / s.step) * s.step + s.min));
    }

    List<P> shown() { return !query.isEmpty() && searchPanel != null ? List.of(searchPanel) : panels; }

    @Override public boolean mouseClicked(Click click, boolean doubled) {
        double cx = click.x(), cy = click.y(); int btn = click.button();
        ClickGui.ripples.add(new float[]{(float) cx, (float) cy, 0});
        pending = null; dragP = null; mode = 0; moved = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            H h = hits.get(i);
            if (cx < h.x1 || cx >= h.x2 || cy < h.y1 || cy >= h.y2) continue;
            if (h.slider != null) { if (btn == 0) { activeSlider = h; setSlider(h, cx); Sfx.play("click", 1.4f); } return true; }
            if (h.header != null) {
                P p = h.header;
                if (panels.remove(p)) panels.add(p);   // bring to front (drawn last = on top; hits then come last)
                dragP = p; mode = 1; pressX = cx; pressY = cy;
                return true;
            }
            if (h.body != null) { pending = h; pendingBtn = btn; pressY = cy; pressScroll = h.body.scroll; dragP = h.body; mode = 2; return true; }
            if (btn == 0 && h.left != null) h.left.run(); else if (btn == 1 && h.right != null) h.right.run();
            return true;
        }
        mode = 3; pressX = cx; pressPan = panGoal;   // empty space: pan sideways
        return true;
    }

    @Override public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeSlider != null) { setSlider(activeSlider, click.x()); return true; }
        if (mode == 1 && dragP != null) {
            if (Math.abs(click.x() - pressX) + Math.abs(click.y() - pressY) > 4) moved = true;
            if (moved) { dragP.ox += (int) dx; dragP.oy += (int) dy; }
            return true;
        }
        if (mode == 2 && dragP != null) {
            if (Math.abs(click.y() - pressY) > 4) moved = true;
            if (moved) { float ns = Math.max(0, Math.min(dragP.max, pressScroll - (float) (click.y() - pressY))); dragP.goal = ns; dragP.scroll = ns; }
            return true;
        }
        if (mode == 3) { panGoal = Math.max(0, pressPan - (float) (click.x() - pressX)); panX = panGoal; return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override public boolean mouseReleased(Click click) {
        if (mode == 1 && dragP != null && !moved) { dragP.collapsed = !dragP.collapsed; Sfx.play("click", 1.1f); }
        H p = pending; pending = null;
        if (p != null && !moved) {
            if (pendingBtn == 0 && p.left != null) p.left.run();
            else if (pendingBtn == 1 && p.right != null) p.right.run();
        }
        activeSlider = null; dragP = null; mode = 0; moved = false;
        return super.mouseReleased(click);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            P p = panels.get(i);
            if (!query.isEmpty()) p = searchPanel;
            if (p != null && mouseX >= p.x && mouseX < p.x + PW && mouseY >= p.y + HDR && mouseY < p.y + HDR + p.vis) {
                p.goal = Math.max(0, Math.min(p.max, p.goal - (float) verticalAmount * 30f));
                return true;
            }
            if (!query.isEmpty()) break;
        }
        panGoal -= (float) (verticalAmount + horizontalAmount) * 50f;
        return true;
    }

    @Override public boolean charTyped(CharInput input) {
        int cp = input.codepoint();
        if (cp == 8 || cp == 127) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
        if (cp < 32 || !input.isValidChar()) return false;
        char ch = (char) cp;
        if (!(Character.isLetterOrDigit(ch) || ch == ' ' || ch == '_' || ch == '-' || ch == '.' || ch == '&') || query.length() >= 24) return true;
        if (ch == ' ' && query.isEmpty()) return true;
        query += Character.toLowerCase(ch);
        return true;
    }

    @Override public boolean keyPressed(KeyInput input) {
        int k = input.key();
        if (k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_INSERT) { close(); return true; }
        if (k == GLFW.GLFW_KEY_ESCAPE && !query.isEmpty()) { query = ""; return true; }
        if (k == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
        if (k == GLFW.GLFW_KEY_RIGHT) { panGoal += 80; return true; }
        if (k == GLFW.GLFW_KEY_LEFT) { panGoal -= 80; return true; }
        return super.keyPressed(input);
    }
}
