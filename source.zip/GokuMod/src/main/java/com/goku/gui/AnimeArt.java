package com.goku.gui;

import com.goku.Config;
import net.minecraft.client.gui.DrawContext;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Background art for the Anime window style. Uses config/gokumod/anime.png if you put your own picture there,
 * otherwise the bundled illustration. The picture is turned into a small set of coloured rectangles (flat-colour merge),
 * so it is drawn with plain fills and works on every Minecraft version.
 */
public final class AnimeArt {
    static int[] rects;          // x1,y1,x2,y2,argb ...
    static int cw = 1, ch = 1;
    static boolean loaded;

    private AnimeArt() {}

    public static void reload() { loaded = false; geo = null; }

    public static float aspect() { ensure(); return cw / (float) ch; }

    static void ensure() {
        if (loaded) return;
        loaded = true; rects = null;
        BufferedImage img = null;
        boolean custom = false;
        try {
            Path f = Config.dir().resolve("anime.png");
            if (Files.exists(f)) { img = ImageIO.read(f.toFile()); custom = img != null; }
        } catch (Throwable ignored) {}
        if (img == null) {
            try (InputStream in = AnimeArt.class.getResourceAsStream("/assets/gokumod/anime/girl.png")) { if (in != null) img = ImageIO.read(in); } catch (Throwable ignored) {}
        }
        if (img == null) return;
        int tw = img.getWidth(), th = img.getHeight();
        if (custom) {   // user picture: shrink to a drawable size
            tw = 56; th = Math.max(1, Math.min(90, Math.round(img.getHeight() * 56f / img.getWidth())));
            BufferedImage s = new BufferedImage(tw, th, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = s.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(img, 0, 0, tw, th, null);
            g.dispose();
            img = s;
        }
        cw = tw; ch = th;
        List<int[]> out = new ArrayList<>();
        Map<Long, int[]> open = new HashMap<>();
        for (int y = 0; y < th; y++) {
            Map<Long, int[]> now = new HashMap<>();
            int x = 0;
            while (x < tw) {
                int c = px(img, x, y, custom);
                int x2 = x + 1;
                while (x2 < tw && px(img, x2, y, custom) == c) x2++;
                if (c != 0) {
                    long key = ((long) c & 0xFFFFFFFFL) | ((long) x << 32) | ((long) x2 << 44);
                    int[] r = open.get(key);
                    if (r == null) { r = new int[]{x, y, x2, y + 1, c}; out.add(r); } else r[3] = y + 1;
                    now.put(key, r);
                }
                x = x2;
            }
            open = now;
        }
        rects = new int[out.size() * 5];
        for (int i = 0; i < out.size(); i++) System.arraycopy(out.get(i), 0, rects, i * 5, 5);
    }

    static int px(BufferedImage img, int x, int y, boolean quant) {
        int a = img.getRGB(x, y);
        if ((a >>> 24) < 24) return 0;
        int rgb = a & 0xFFFFFF;
        if (quant) rgb = (rgb & 0xC0C0C0) | 0x202020;
        return 0xFF000000 | rgb;
    }

    static int[] geo; static int gx, gy, gw, gh = -1;

    /** Draws the picture stretched into the given box. Geometry is cached, so a frame is only ~1000 plain fills. */
    public static void draw(DrawContext c, int x, int y, int w, int h, float alpha) {
        ensure();
        if (rects == null) return;
        if (geo == null || gx != x || gy != y || gw != w || gh != h) {
            gx = x; gy = y; gw = w; gh = h;
            float sx = w / (float) cw, sy = h / (float) ch;
            geo = new int[rects.length];
            for (int i = 0; i < rects.length; i += 5) {
                geo[i] = x + Math.round(rects[i] * sx); geo[i + 1] = y + Math.round(rects[i + 1] * sy);
                geo[i + 2] = x + Math.round(rects[i + 2] * sx); geo[i + 3] = y + Math.round(rects[i + 3] * sy);
                geo[i + 4] = rects[i + 4];
            }
        }
        int a = Math.max(0, Math.min(255, (int) (alpha * 255))) << 24;
        for (int i = 0; i < geo.length; i += 5) {
            if (geo[i + 2] <= geo[i] || geo[i + 3] <= geo[i + 1]) continue;
            c.fill(geo[i], geo[i + 1], geo[i + 2], geo[i + 3], a | (geo[i + 4] & 0xFFFFFF));
        }
    }
}
