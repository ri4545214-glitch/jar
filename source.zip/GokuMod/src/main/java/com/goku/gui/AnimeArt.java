package com.goku.gui;

import com.goku.Config;
import net.minecraft.client.gui.DrawContext;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Background art for the Anime window style. Uses config/gokumod/anime.png if you put your own picture there,
 * otherwise the bundled illustration. The picture is turned into a small set of coloured rectangles (flat-colour merge),
 * so it is drawn with plain fills and works on every Minecraft version.
 */
public final class AnimeArt {
    static int[] rects;          // x1,y1,x2,y2,argb ...
    static int cw = 1, ch = 1;
    static boolean loaded;

    private AnimeArt() {}

    public static void reload() { loaded = false; cacheW = -1; }

    public static float aspect() { ensure(); return cw / (float) ch; }

    static void ensure() {
        if (loaded) return;
        loaded = true; rects = null;
        BufferedImage img = null;
        boolean custom = false;
        try {
            Path f = Config.dir().resolve("anime.png");
            if (Files.exists(f)) { img = ImageIO.read(f.toFile()); custom = img != null; }
        } catch (Throwable ignored) {}
        if (img == null) {
            try (InputStream in = AnimeArt.class.getResourceAsStream("/assets/gokumod/anime/girl.png")) { if (in != null) img = ImageIO.read(in); } catch (Throwable ignored) {}
        }
        if (img == null) return;
        // Always work on a small copy: the number of rectangles (= fill calls per frame) is what makes this style lag.
        int tw = Math.min(img.getWidth(), 120), th = Math.max(1, Math.min(180, Math.round(img.getHeight() * (float) tw / img.getWidth())));
        if (tw != img.getWidth() || th != img.getHeight()) {
            BufferedImage s = new BufferedImage(tw, th, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = s.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(img, 0, 0, tw, th, null);
            g.dispose();
            img = s;
        }
        cw = tw; ch = th;
        // merge flat colours; coarsen the palette until the rectangle count is small enough to draw cheaply
        int[] masks = {0xF0, 0xE0, 0xC0, 0xA0, 0x80};
        List<int[]> out = new ArrayList<>();
        for (int mask : masks) {
            out = build(img, mask * 0x010101);
            if (out.size() <= 900) break;
        }
        rects = new int[out.size() * 5];
        for (int i = 0; i < out.size(); i++) System.arraycopy(out.get(i), 0, rects, i * 5, 5);
        cacheW = -1;
    }

    static List<int[]> build(BufferedImage img, int mask) {
        int tw = img.getWidth(), th = img.getHeight();
        List<int[]> out = new ArrayList<>();
        Map<Long, int[]> open = new HashMap<>();
        for (int y = 0; y < th; y++) {
            Map<Long, int[]> now = new HashMap<>();
            int x = 0;
            while (x < tw) {
                int c = px(img, x, y, mask);
                int x2 = x + 1;
                while (x2 < tw && px(img, x2, y, mask) == c) x2++;
                if (c != 0) {
                    long key = ((long) c & 0xFFFFFFFFL) | ((long) x << 32) | ((long) x2 << 44);
                    int[] r = open.get(key);
                    if (r == null) { r = new int[]{x, y, x2, y + 1, c}; out.add(r); } else r[3] = y + 1;
                    now.put(key, r);
                }
                x = x2;
            }
            open = now;
        }
        return out;
    }

    static int px(BufferedImage img, int x, int y, int mask) {
        int a = img.getRGB(x, y);
        if ((a >>> 24) < 24) return 0;
        return 0xFF000000 | ((a & mask) | 0x080808);
    }

    // screen-space cache so drawing is just N fills with no per-frame maths allocation
    static int cacheX, cacheY, cacheW = -1, cacheH;
    static int[] cache;

    /** Draws the picture stretched into the given box. */
    public static void draw(DrawContext c, int x, int y, int w, int h, float alpha) {
        ensure();
        if (rects == null) return;
        if (cacheW != w || cacheH != h || cacheX != x || cacheY != y || cache == null) {
            cacheX = x; cacheY = y; cacheW = w; cacheH = h;
            float sx = w / (float) cw, sy = h / (float) ch;
            cache = new int[rects.length];
            for (int i = 0; i < rects.length; i += 5) {
                cache[i] = x + Math.round(rects[i] * sx); cache[i + 1] = y + Math.round(rects[i + 1] * sy);
                cache[i + 2] = x + Math.round(rects[i + 2] * sx); cache[i + 3] = y + Math.round(rects[i + 3] * sy);
                cache[i + 4] = rects[i + 4];
            }
        }
        int a8 = Math.max(0, Math.min(255, (int) (alpha * 255)));
        if (a8 < 4) return;
        for (int i = 0; i < cache.length; i += 5) {
            if (cache[i + 2] <= cache[i] || cache[i + 3] <= cache[i + 1]) continue;
            c.fill(cache[i], cache[i + 1], cache[i + 2], cache[i + 3], (a8 << 24) | (cache[i + 4] & 0xFFFFFF));
        }
    }
}
